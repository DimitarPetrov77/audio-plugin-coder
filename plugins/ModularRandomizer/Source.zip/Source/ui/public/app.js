/*
 * Modular Randomizer - app.js
 * Complete UI logic for the two-panel rack interface
 * Phase 1: Mock data (plugin library simulation)
 * Phase 2+: Will use JUCE native functions for real plugin hosting
 */

// ============================================================
// CONSTANTS
// ============================================================
var BCOLORS = ['#FF5500', '#22AAFF', '#33CC33', '#CC33CC', '#CCAA00', '#CC5533', '#3388CC', '#88AA33'];
function bColor(i) { return BCOLORS[i % BCOLORS.length]; }

// Mock plugin library — Phase 2 will replace with real VST3 scan
var PLUGIN_LIB = [
    { name: 'Serum', vendor: 'Xfer Records', cat: 'synth', params: ['Osc A Wave', 'Osc A Semi', 'Osc A Fine', 'Osc A Level', 'Osc B Wave', 'Osc B Semi', 'Osc B Fine', 'Osc B Level', 'Filter Cutoff', 'Filter Resonance', 'Filter Drive', 'Filter Type', 'Amp Attack', 'Amp Decay', 'Amp Sustain', 'Amp Release', 'LFO 1 Rate', 'LFO 1 Shape', 'Reverb Mix', 'Delay Time', 'Unison Voices', 'Unison Detune', 'Macro 1', 'Macro 2', 'Master Volume', 'Master Pan'] },
    { name: 'Vital', vendor: 'Matt Tytel', cat: 'synth', params: ['Osc 1 Position', 'Osc 1 Level', 'Osc 1 Pan', 'Osc 2 Position', 'Osc 2 Level', 'Osc 2 Pan', 'Filter 1 Cutoff', 'Filter 1 Resonance', 'Filter 1 Blend', 'Filter 2 Cutoff', 'Filter 2 Resonance', 'Env 1 Attack', 'Env 1 Decay', 'Env 1 Sustain', 'Env 1 Release', 'LFO 1 Freq', 'LFO 1 Phase', 'Chorus Amount', 'Delay Mix', 'Reverb Size', 'Reverb Mix', 'Macro 1', 'Macro 2', 'Macro 3', 'Macro 4'] },
    { name: 'Diva', vendor: 'u-he', cat: 'synth', params: ['VCO 1 Shape', 'VCO 1 PW', 'VCO 2 Shape', 'VCO 2 Tune', 'VCF Cutoff', 'VCF Resonance', 'VCF Env Amount', 'VCA Attack', 'VCA Decay', 'VCA Sustain', 'VCA Release', 'Mod Attack', 'Mod Decay', 'Mod Sustain', 'Mod Release', 'LFO Rate', 'LFO Depth', 'Chorus', 'Delay Mix', 'Plate Size'] },
    { name: 'Pigments', vendor: 'Arturia', cat: 'synth', params: ['Engine A Type', 'Engine A Position', 'Engine A Morph', 'Engine B Type', 'Engine B Position', 'Filter 1 Cutoff', 'Filter 1 Reso', 'Env 1 Attack', 'Env 1 Decay', 'Env 1 Sustain', 'Env 1 Release', 'LFO 1 Rate', 'FX 1 Mix', 'FX 2 Mix', 'Macro 1', 'Macro 2', 'Macro 3', 'Macro 4', 'Master Volume'] },
    { name: 'Phase Plant', vendor: 'Kilohearts', cat: 'synth', params: ['Gen 1 Pitch', 'Gen 1 Level', 'Gen 2 Pitch', 'Gen 2 Level', 'Filter Cutoff', 'Filter Resonance', 'Env Attack', 'Env Decay', 'Env Sustain', 'Env Release', 'LFO 1 Rate', 'Macro 1', 'Macro 2', 'Master Volume'] },
    { name: 'Massive X', vendor: 'Native Instruments', cat: 'synth', params: ['Osc 1 Position', 'Osc 1 Intensity', 'Osc 2 Position', 'Osc 2 Intensity', 'Filter Cutoff', 'Filter Resonance', 'Performer 1', 'Performer 2', 'Macro 1', 'Macro 2', 'Macro 3', 'Macro 4', 'Master Volume'] },
    { name: 'Zebra2', vendor: 'u-he', cat: 'synth', params: ['Osc 1 Wave', 'Osc 1 Tune', 'Osc 2 Wave', 'Osc 2 Tune', 'Filter 1 Cutoff', 'Filter 1 Reso', 'VCA Env A', 'VCA Env D', 'VCA Env S', 'VCA Env R', 'LFO 1 Rate', 'Master Volume'] },
    { name: 'Analog Lab', vendor: 'Arturia', cat: 'synth', params: ['Macro 1', 'Macro 2', 'Macro 3', 'Macro 4', 'Filter Cutoff', 'Filter Reso', 'Attack', 'Decay', 'Sustain', 'Release', 'Chorus', 'Delay', 'Reverb', 'Volume'] },
    { name: 'Valhalla Room', vendor: 'Valhalla DSP', cat: 'fx', params: ['Mix', 'Predelay', 'Decay', 'High Cut', 'Low Cut', 'Early Size', 'Late Size', 'Depth', 'Modulation', 'Master Volume'] },
    { name: 'FabFilter Pro-Q 3', vendor: 'FabFilter', cat: 'fx', params: ['Band 1 Freq', 'Band 1 Gain', 'Band 1 Q', 'Band 2 Freq', 'Band 2 Gain', 'Band 2 Q', 'Band 3 Freq', 'Band 3 Gain', 'Band 3 Q', 'Output Gain'] },
    { name: 'Soundtoys Decapitator', vendor: 'Soundtoys', cat: 'fx', params: ['Drive', 'Tone', 'Mix', 'Output', 'Low Cut', 'Style', 'Punish', 'Master Volume'] },
    { name: 'OTT', vendor: 'Xfer Records', cat: 'fx', params: ['Depth', 'Time', 'In Gain', 'Out Gain', 'Low Band', 'Mid Band', 'High Band'] },
    { name: 'Valhalla Delay', vendor: 'Valhalla DSP', cat: 'fx', params: ['Mix', 'Delay Time', 'Feedback', 'Age', 'Diffusion', 'Mod Rate', 'Mod Depth', 'Era', 'Width', 'Master Volume'] },
    { name: 'Replika XT', vendor: 'Native Instruments', cat: 'fx', params: ['Mix', 'Time', 'Feedback', 'Modulation', 'Saturation', 'Filter', 'Diffusion', 'Width', 'Volume'] },
    { name: 'Trash 2', vendor: 'iZotope', cat: 'fx', params: ['Drive', 'Mix', 'Filter Cutoff', 'Filter Reso', 'Convolver Mix', 'Gate Thresh', 'Compressor', 'Output'] },
    { name: 'Kontakt 7', vendor: 'Native Instruments', cat: 'sampler', params: ['Volume', 'Pan', 'Tune', 'Attack', 'Decay', 'Sustain', 'Release', 'Filter Cutoff', 'Filter Reso', 'FX 1 Send', 'FX 2 Send', 'Master Volume'] },
    { name: 'Omnisphere', vendor: 'Spectrasonics', cat: 'sampler', params: ['Layer A Level', 'Layer A Pan', 'Layer B Level', 'Layer B Pan', 'Filter Cutoff', 'Filter Reso', 'Env Attack', 'Env Decay', 'Env Sustain', 'Env Release', 'Aux 1', 'Aux 2', 'Master Volume'] },
    { name: 'Battery 4', vendor: 'Native Instruments', cat: 'sampler', params: ['Volume', 'Pan', 'Tune', 'Attack', 'Hold', 'Decay', 'Comp Amount', 'Sat Drive', 'Filter Cutoff', 'Filter Reso', 'Send 1', 'Send 2'] },
    { name: 'SPAN', vendor: 'Voxengo', cat: 'utility', params: ['Range', 'Offset', 'Speed', 'Channel', 'Block Size'] },
    { name: 'Youlean Loudness Meter', vendor: 'Youlean', cat: 'utility', params: ['Target', 'Range', 'Speed'] },
    { name: 'MeldaProduction MAnalyzer', vendor: 'MeldaProduction', cat: 'utility', params: ['Smoothing', 'Speed', 'Range', 'Analysis Type', 'Channel'] }
];

var scanPaths = [
    'C:\\Program Files\\Common Files\\VST3',
    'C:\\Program Files\\VSTPlugins'
];

// ============================================================
// STATE
// ============================================================
var PMap = {}, pluginBlocks = [], plugBC = 0;
var blocks = [], bc = 0, actId = null, assignMode = null, ctxP = null, envValue = 0;
var NN = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];

function midiName(n) { return NN[n % 12] + (Math.floor(n / 12) - 1); }
function findBlock(id) { for (var i = 0; i < blocks.length; i++) { if (blocks[i].id === id) return blocks[i]; } return null; }
function allParams() { var a = []; pluginBlocks.forEach(function (pb) { a = a.concat(pb.params); }); return a; }
function paramPluginName(pid) { var pi = parseInt(pid.split(':')[0]); for (var i = 0; i < pluginBlocks.length; i++) { if (pluginBlocks[i].id === pi) return pluginBlocks[i].name; } return '?'; }

// ============================================================
// PLUGIN MANAGEMENT
// ============================================================
function addPlugin(name) {
    var id = ++plugBC;
    var lib = PLUGIN_LIB.filter(function (p) { return p.name === name; })[0];
    var tpl = lib ? lib.params : ['Param 1', 'Param 2', 'Param 3', 'Param 4', 'Param 5', 'Volume'];
    var params = tpl.map(function (n, i) {
        var fid = id + ':' + i;
        var p = { id: fid, name: n, v: +(Math.random() * 0.8 + 0.1).toFixed(2), lk: false, alk: false };
        if (n === 'Master Volume' || n === 'Master Pan') { p.lk = true; p.alk = true; }
        PMap[fid] = p; return p;
    });
    pluginBlocks.push({ id: id, name: name, params: params, expanded: true, searchFilter: '' });
    renderAllPlugins(); updCounts();
}

function removePlugin(pid) {
    var pb; for (var i = 0; i < pluginBlocks.length; i++) { if (pluginBlocks[i].id === pid) { pb = pluginBlocks[i]; break; } }
    if (!pb) return;
    pb.params.forEach(function (p) { delete PMap[p.id]; blocks.forEach(function (b) { b.targets.delete(p.id); }); });
    pluginBlocks = pluginBlocks.filter(function (p) { return p.id !== pid; });
    renderAllPlugins(); renderBlocks(); updCounts();
}

// ============================================================
// PLUGIN CARDS RENDERING
// ============================================================
function renderAllPlugins() {
    var c = document.getElementById('pluginScroll'); c.innerHTML = '';
    var isA = assignMode !== null, aBlk = isA ? findBlock(assignMode) : null, aCol = isA && aBlk ? bColor(aBlk.colorIdx) : '';
    for (var pi = 0; pi < pluginBlocks.length; pi++) {
        var pb = pluginBlocks[pi], card = document.createElement('div'); card.className = 'pcard';
        card.setAttribute('draggable', 'true');
        card.setAttribute('data-plugidx', pi);
        card.setAttribute('data-plugid', pb.id);
        card.innerHTML = '<div class="pcard-head" data-plugid="' + pb.id + '"><span class="lchev ' + (pb.expanded ? 'open' : '') + '">&#9654;</span><span class="pcard-name">' + pb.name + '</span><span class="pcard-info">' + pb.params.length + ' params</span><button class="sm-btn" style="font-size:8px;padding:1px 5px" data-pluged="' + pb.id + '">Ed</button><button class="pcard-close" data-plugrm="' + pb.id + '">x</button></div><div class="pcard-body ' + (pb.expanded ? '' : 'hide') + '"><div class="pcard-search"><input type="text" placeholder="Filter..." data-plugsearch="' + pb.id + '" value="' + (pb.searchFilter || '') + '"></div><div class="pcard-params" data-plugparams="' + pb.id + '"></div></div>';
        c.appendChild(card);
        var paramC = card.querySelector('[data-plugparams="' + pb.id + '"]');
        var filter = (pb.searchFilter || '').toLowerCase();
        for (var i = 0; i < pb.params.length; i++) {
            var p = pb.params[i];
            if (filter && p.name.toLowerCase().indexOf(filter) === -1) continue;
            var isTgt = isA && aBlk && aBlk.targets.has(p.id);
            var row = document.createElement('div');
            row.className = 'pr' + (p.lk ? ' locked' : '') + (isA && !p.lk ? ' assign-highlight' : '');
            row.setAttribute('data-pid', p.id);
            if (isTgt) { row.style.background = aCol + '18'; row.style.borderColor = aCol + '66'; }
            var dots = ''; for (var bi = 0; bi < blocks.length; bi++) { if (blocks[bi].targets.has(p.id)) dots += '<span class="pr-dot" style="background:' + bColor(blocks[bi].colorIdx) + '"></span>'; }
            row.innerHTML = '<span class="pr-name">' + p.name + '</span><div class="pr-dots">' + dots + '</div><span class="pr-val">' + (p.v * 100).toFixed(0) + '%</span><div class="pr-bar"><div class="pr-bar-f" style="width:' + (p.v * 100) + '%"></div></div>' + (p.lk ? '<span class="pr-lock">' + (p.alk ? '&#9888;' : '&#128274;') + '</span>' : '');
            paramC.appendChild(row);
        }
    }
    wirePluginCards(); updateAssignBanner();
}

function wirePluginCards() {
    document.querySelectorAll('.pcard-head').forEach(function (h) {
        h.onclick = function (e) {
            if (e.target.closest('[data-plugrm]') || e.target.closest('[data-pluged]')) return;
            var id = parseInt(h.dataset.plugid);
            for (var i = 0; i < pluginBlocks.length; i++) { if (pluginBlocks[i].id === id) { pluginBlocks[i].expanded = !pluginBlocks[i].expanded; break; } }
            renderAllPlugins();
        };
    });
    document.querySelectorAll('[data-plugrm]').forEach(function (b) { b.onclick = function (e) { e.stopPropagation(); removePlugin(parseInt(b.dataset.plugrm)); }; });
    document.querySelectorAll('[data-plugsearch]').forEach(function (inp) {
        inp.onclick = function (e) { e.stopPropagation(); };
        inp.oninput = function () {
            var id = parseInt(inp.dataset.plugsearch);
            for (var i = 0; i < pluginBlocks.length; i++) { if (pluginBlocks[i].id === id) { pluginBlocks[i].searchFilter = inp.value; break; } }
            renderAllPlugins();
            var ni = document.querySelector('[data-plugsearch="' + id + '"]');
            if (ni) { ni.focus(); ni.selectionStart = ni.selectionEnd = ni.value.length; }
        };
    });
    // Drag and drop reordering
    var dragSrcIdx = null;
    document.querySelectorAll('.pcard').forEach(function (card) {
        card.addEventListener('dragstart', function (e) {
            dragSrcIdx = parseInt(card.dataset.plugidx);
            card.classList.add('dragging');
            e.dataTransfer.effectAllowed = 'move';
            e.dataTransfer.setData('text/plain', dragSrcIdx);
        });
        card.addEventListener('dragend', function () {
            card.classList.remove('dragging');
            dragSrcIdx = null;
            document.querySelectorAll('.pcard').forEach(function (c) {
                c.classList.remove('drag-over-top', 'drag-over-bottom');
            });
        });
        card.addEventListener('dragover', function (e) {
            e.preventDefault();
            e.dataTransfer.dropEffect = 'move';
            var rect = card.getBoundingClientRect();
            var midY = rect.top + rect.height / 2;
            document.querySelectorAll('.pcard').forEach(function (c) {
                c.classList.remove('drag-over-top', 'drag-over-bottom');
            });
            if (e.clientY < midY) card.classList.add('drag-over-top');
            else card.classList.add('drag-over-bottom');
        });
        card.addEventListener('dragleave', function () {
            card.classList.remove('drag-over-top', 'drag-over-bottom');
        });
        card.addEventListener('drop', function (e) {
            e.preventDefault();
            var fromIdx = parseInt(e.dataTransfer.getData('text/plain'));
            var toIdx = parseInt(card.dataset.plugidx);
            if (isNaN(fromIdx) || isNaN(toIdx) || fromIdx === toIdx) return;
            var rect = card.getBoundingClientRect();
            var midY = rect.top + rect.height / 2;
            if (e.clientY > midY && toIdx < fromIdx) toIdx++;
            if (e.clientY < midY && toIdx > fromIdx) toIdx--;
            var moved = pluginBlocks.splice(fromIdx, 1)[0];
            pluginBlocks.splice(toIdx, 0, moved);
            renderAllPlugins();
        });
    });
}

// ============================================================
// PARAM CLICK & CONTEXT MENU DELEGATION
// ============================================================
var pse = document.getElementById('pluginScroll');
pse.addEventListener('click', function (e) {
    var row = e.target.closest('.pr'); if (!row) return;
    var pid = row.getAttribute('data-pid'); if (!pid) return;
    var pp = PMap[pid]; if (!pp || pp.lk) return; if (!assignMode) return;
    var b = findBlock(assignMode);
    if (b) { if (b.targets.has(pid)) b.targets.delete(pid); else b.targets.add(pid); }
    renderAllPlugins();
    clearTimeout(renderAllPlugins._bt);
    renderAllPlugins._bt = setTimeout(function () { renderBlocks(); }, 80);
});
pse.addEventListener('contextmenu', function (e) {
    var row = e.target.closest('.pr'); if (!row) return;
    var pid = row.getAttribute('data-pid'); if (!pid) return;
    var pp = PMap[pid]; if (!pp) return; e.preventDefault(); ctxP = pp; showCtx(e.clientX, e.clientY, pp);
});

// Context menu
function showCtx(x, y, p) { var m = document.getElementById('ctx'); m.style.left = Math.min(x, 900) + 'px'; m.style.top = Math.min(y, 580) + 'px'; m.classList.add('vis'); document.getElementById('cL').style.display = (p.lk || p.alk) ? 'none' : ''; document.getElementById('cU').style.display = (p.lk && !p.alk) ? '' : 'none'; }
document.addEventListener('click', function () { document.getElementById('ctx').classList.remove('vis'); });
document.getElementById('cL').onclick = function () { if (ctxP) { ctxP.lk = true; blocks.forEach(function (b) { b.targets.delete(ctxP.id); }); renderAllPlugins(); renderBlocks(); } };
document.getElementById('cU').onclick = function () { if (ctxP && !ctxP.alk) { ctxP.lk = false; renderAllPlugins(); } };

// ============================================================
// LOGIC BLOCKS
// ============================================================
function addBlock(mode) {
    if (!mode) mode = 'randomize'; var id = ++bc;
    blocks.push({ id: id, mode: mode, targets: new Set(), colorIdx: bc - 1, trigger: 'manual', beatDiv: '1/4', midiMode: 'any_note', midiNote: 60, midiCC: 1, velScale: false, threshold: -12, rMin: 0, rMax: 100, rangeMode: 'absolute', quantize: false, qSteps: 12, movement: 'instant', glideMs: 200, envAtk: 10, envRel: 100, envSens: 50, envInvert: false, expanded: true });
    actId = id; assignMode = null; renderBlocks(); renderAllPlugins(); updCounts();
}

function renderBlocks() {
    var c = document.getElementById('lpScroll'); c.innerHTML = '';
    for (var bi = 0; bi < blocks.length; bi++) {
        var b = blocks[bi], col = bColor(b.colorIdx), isAct = b.id === actId, isAs = assignMode === b.id;
        var card = document.createElement('div');
        card.className = 'lcard' + (isAct ? ' active' : '') + (b.mode === 'envelope' && isAct ? ' env-active' : '');
        var sum = ''; if (b.mode === 'envelope') sum = 'Atk ' + b.envAtk + 'ms / Rel ' + b.envRel + 'ms';
        else { sum = ({ manual: 'Manual', tempo: 'Tempo', midi: 'MIDI', audio: 'Audio' }[b.trigger]) + ' / ' + (b.movement === 'instant' ? 'Instant' : 'Smooth'); }
        var tc = b.targets.size, tH = '';
        if (tc === 0) tH = '<span class="tg-empty">No params assigned</span>';
        else { var ta = Array.from(b.targets).slice(0, 6); for (var ti = 0; ti < ta.length; ti++) { var tp = PMap[ta[ti]]; if (!tp) continue; var pn = paramPluginName(ta[ti]); tH += '<span class="tg" style="background:' + col + '22;border:1px solid ' + col + '66;color:' + col + '">' + pn + ': ' + tp.name + '<span class="tx" data-b="' + b.id + '" data-p="' + ta[ti] + '">x</span></span>'; } if (tc > 6) tH += '<span class="tg" style="background:#eee;border:1px solid #ccc;color:#999">+' + (tc - 6) + '</span>'; }
        var abS = isAs ? 'background:' + col + ';color:white;border-color:' + col : '', abT = isAs ? 'Done' : 'Assign';
        var bH = ''; bH += '<div class="brow"><span class="blbl">Mode</span><div class="seg" data-b="' + b.id + '" data-f="mode"><button class="' + (b.mode === 'randomize' ? 'on' : '') + '" data-v="randomize">Randomize</button><button class="' + (b.mode === 'envelope' ? 'env-on' : '') + '" data-v="envelope">Envelope</button></div></div>';
        if (b.mode === 'randomize') bH += renderRndBody(b); else bH += renderEnvBody(b);
        bH += '<div class="brow"><span class="blbl">Targets (' + tc + ')</span><div class="tgt-box">' + tH + '</div></div>';
        if (b.mode === 'randomize') bH += '<button class="fire" data-b="' + b.id + '">FIRE</button>';
        var ch = '<span class="lchev ' + (b.expanded ? 'open' : '') + '">&#9654;</span>';
        card.innerHTML = '<div class="lhead" data-id="' + b.id + '"><div style="display:flex;align-items:center">' + ch + '<span class="block-color" style="background:' + col + '"></span><span class="ltitle">Block ' + (bi + 1) + '</span><span class="lsum">' + sum + ' / ' + tc + ' params</span></div><div style="display:flex;gap:4px;align-items:center"><button class="sm-btn assign-btn" data-id="' + b.id + '" style="' + abS + '">' + abT + '</button><button class="lclose" data-id="' + b.id + '">x</button></div></div><div class="lbody ' + (b.expanded ? '' : 'hide') + '">' + bH + '</div>';
        c.appendChild(card);
    }
    wireBlocks(); updateAssignBanner();
}

function renderRndBody(b) {
    var h = '<div class="brow"><span class="blbl">Trigger</span><div class="seg" data-b="' + b.id + '" data-f="trigger">';
    ['manual', 'tempo', 'midi', 'audio'].forEach(function (t) { h += '<button class="' + (b.trigger === t ? 'on' : '') + '" data-v="' + t + '">' + { manual: 'Manual', tempo: 'Tempo', midi: 'MIDI', audio: 'Audio' }[t] + '</button>'; });
    h += '</div><div class="sub ' + (b.trigger === 'tempo' ? 'vis' : '') + '"><div class="sub-row"><span class="sub-lbl">Division</span><select class="sub-sel" data-b="' + b.id + '" data-f="beatDiv">';
    ['1/1', '1/2', '1/4', '1/8', '1/16', '1/32'].forEach(function (d) { h += '<option' + (b.beatDiv === d ? ' selected' : '') + '>' + d + '</option>'; });
    h += '</select></div></div><div class="sub ' + (b.trigger === 'midi' ? 'vis' : '') + '"><div class="sub-row"><span class="sub-lbl">Mode</span><select class="sub-sel" data-b="' + b.id + '" data-f="midiMode"><option value="any_note"' + (b.midiMode === 'any_note' ? ' selected' : '') + '>Any Note</option><option value="specific_note"' + (b.midiMode === 'specific_note' ? ' selected' : '') + '>Note</option><option value="cc"' + (b.midiMode === 'cc' ? ' selected' : '') + '>CC</option></select></div></div>';
    h += '<div class="sub ' + (b.trigger === 'audio' ? 'vis' : '') + '"><div class="sl-row"><span class="sl-lbl">Thresh</span><input type="range" min="-60" max="0" value="' + b.threshold + '" data-b="' + b.id + '" data-f="threshold"><span class="sl-val">' + b.threshold + ' dB</span></div></div></div>';
    h += '<div class="brow"><span class="blbl">Range</span><div class="seg" data-b="' + b.id + '" data-f="rangeMode"><button class="' + (b.rangeMode === 'absolute' ? 'on' : '') + '" data-v="absolute">Absolute</button><button class="' + (b.rangeMode === 'relative' ? 'on' : '') + '" data-v="relative">Relative</button></div>';
    if (b.rangeMode === 'absolute') { h += '<div class="sl-row"><span class="sl-lbl">Min</span><input type="range" min="0" max="100" value="' + b.rMin + '" data-b="' + b.id + '" data-f="rMin"><span class="sl-val">' + b.rMin + '%</span></div><div class="sl-row"><span class="sl-lbl">Max</span><input type="range" min="0" max="100" value="' + b.rMax + '" data-b="' + b.id + '" data-f="rMax"><span class="sl-val">' + b.rMax + '%</span></div>'; }
    else { h += '<div class="sl-row"><span class="sl-lbl">\u00b1</span><input type="range" min="1" max="100" value="' + b.rMax + '" data-b="' + b.id + '" data-f="rMax"><span class="sl-val">' + b.rMax + '%</span></div>'; }
    h += '</div><div class="brow"><div class="tgl-row"><div class="tgl ' + (b.quantize ? 'on' : '') + '" data-b="' + b.id + '" data-f="quantize"></div><span class="tgl-lbl">Quantize</span><input class="sub-input" type="number" value="' + b.qSteps + '" min="2" max="128" data-b="' + b.id + '" data-f="qSteps"' + (b.quantize ? '' : ' disabled') + '><span class="sub-lbl" style="min-width:auto">steps</span></div></div>';
    h += '<div class="brow"><span class="blbl">Movement</span><div class="seg" data-b="' + b.id + '" data-f="movement"><button class="' + (b.movement === 'instant' ? 'on' : '') + '" data-v="instant">Instant</button><button class="' + (b.movement === 'glide' ? 'on' : '') + '" data-v="glide">Smooth</button></div>';
    if (b.movement === 'glide') h += '<div class="sl-row" style="margin-top:3px"><span class="sl-lbl">Time</span><input type="range" min="1" max="2000" value="' + b.glideMs + '" data-b="' + b.id + '" data-f="glideMs"><span class="sl-val">' + b.glideMs + 'ms</span></div>';
    h += '</div>'; return h;
}

function renderEnvBody(b) {
    var h = '<div class="brow"><span class="blbl"><span class="env-active-dot"></span>Envelope Follower</span><div class="env-meter" id="envMeter-' + b.id + '"><div class="env-meter-fill" id="envFill-' + b.id + '" style="height:0%"></div><span class="env-label" id="envLbl-' + b.id + '">0%</span></div></div>';
    h += '<div class="brow"><span class="blbl">Response</span><div class="sl-row"><span class="sl-lbl">Attack</span><input type="range" min="1" max="500" value="' + b.envAtk + '" data-b="' + b.id + '" data-f="envAtk"><span class="sl-val">' + b.envAtk + 'ms</span></div><div class="sl-row"><span class="sl-lbl">Release</span><input type="range" min="1" max="2000" value="' + b.envRel + '" data-b="' + b.id + '" data-f="envRel"><span class="sl-val">' + b.envRel + 'ms</span></div></div>';
    h += '<div class="brow"><span class="blbl">Mapping</span><div class="sl-row"><span class="sl-lbl">Gain</span><input type="range" min="0" max="100" value="' + b.envSens + '" data-b="' + b.id + '" data-f="envSens"><span class="sl-val">' + b.envSens + '%</span></div><div class="sl-row"><span class="sl-lbl">Min</span><input type="range" min="0" max="100" value="' + b.rMin + '" data-b="' + b.id + '" data-f="rMin"><span class="sl-val">' + b.rMin + '%</span></div><div class="sl-row"><span class="sl-lbl">Max</span><input type="range" min="0" max="100" value="' + b.rMax + '" data-b="' + b.id + '" data-f="rMax"><span class="sl-val">' + b.rMax + '%</span></div><div class="tgl-row"><div class="tgl ' + (b.envInvert ? 'on' : '') + '" data-b="' + b.id + '" data-f="envInvert"></div><span class="tgl-lbl">Invert</span></div></div>';
    return h;
}

function wireBlocks() {
    document.querySelectorAll('.lbody').forEach(function (b) { b.onclick = function (e) { e.stopPropagation(); }; });
    document.querySelectorAll('.lhead').forEach(function (h) { h.onclick = function (e) { if (e.target.closest('.assign-btn') || e.target.closest('.lclose')) return; var id = parseInt(h.dataset.id); var b = findBlock(id); if (b) { b.expanded = !b.expanded; renderBlocks(); } }; });
    document.querySelectorAll('.assign-btn').forEach(function (btn) { btn.onclick = function (e) { e.stopPropagation(); var id = parseInt(btn.dataset.id); if (assignMode === id) assignMode = null; else { assignMode = id; actId = id; var b = findBlock(id); if (b && !b.expanded) b.expanded = true; } renderBlocks(); renderAllPlugins(); }; });
    document.querySelectorAll('.lclose').forEach(function (btn) { btn.onclick = function (e) { e.stopPropagation(); var id = parseInt(btn.dataset.id); blocks = blocks.filter(function (b) { return b.id !== id; }); if (actId === id) actId = blocks.length ? blocks[0].id : null; if (assignMode === id) assignMode = null; renderBlocks(); renderAllPlugins(); updCounts(); }; });
    document.querySelectorAll('.seg').forEach(function (seg) { seg.querySelectorAll('button').forEach(function (btn) { btn.onclick = function (e) { e.stopPropagation(); var b = findBlock(parseInt(seg.dataset.b)); if (b) { b[seg.dataset.f] = btn.dataset.v; renderBlocks(); } }; }); });
    document.querySelectorAll('.tgl').forEach(function (t) { t.onclick = function (e) { e.stopPropagation(); var b = findBlock(parseInt(t.dataset.b)); if (b) { b[t.dataset.f] = !b[t.dataset.f]; renderBlocks(); } }; });
    document.querySelectorAll('.sub-sel').forEach(function (s) { s.onchange = function () { var b = findBlock(parseInt(s.dataset.b)); if (b) { b[s.dataset.f] = s.value; renderBlocks(); } }; });
    document.querySelectorAll('.lbody input[type="range"]').forEach(function (sl) { if (!sl.dataset.b) return; sl.oninput = function () { var b = findBlock(parseInt(sl.dataset.b)); if (!b) return; b[sl.dataset.f] = parseFloat(sl.value); var row = sl.closest('.sl-row,.sub-row'); if (row) { var v = row.querySelector('.sl-val'); if (v) { var f = sl.dataset.f; if (f === 'threshold') v.textContent = sl.value + ' dB'; else if (f === 'glideMs' || f === 'envAtk' || f === 'envRel') v.textContent = sl.value + 'ms'; else v.textContent = sl.value + '%'; } } }; });
    document.querySelectorAll('.sub-input').forEach(function (inp) { if (!inp.dataset.b) return; inp.onchange = function () { var b = findBlock(parseInt(inp.dataset.b)); if (b) b[inp.dataset.f] = Math.max(0, Math.min(128, parseInt(inp.value) || 0)); }; });
    document.querySelectorAll('.fire').forEach(function (btn) { btn.onclick = function (e) { e.stopPropagation(); btn.classList.add('flash'); setTimeout(function () { btn.classList.remove('flash'); }, 250); randomize(parseInt(btn.dataset.b)); flashDot('midiD'); }; });
    document.querySelectorAll('.tx').forEach(function (x) { x.onclick = function (e) { e.stopPropagation(); var b = findBlock(parseInt(x.dataset.b)); if (b) b.targets.delete(x.dataset.p); renderBlocks(); renderAllPlugins(); }; });
}

function updateAssignBanner() {
    var bn = document.getElementById('assignBanner'), lb = document.getElementById('assignTarget');
    if (assignMode) { var b = findBlock(assignMode); if (!b) { bn.classList.remove('vis'); return; } bn.classList.add('vis'); var col = bColor(b.colorIdx); bn.style.background = col + '22'; bn.style.borderColor = col + '66'; bn.style.color = col; lb.textContent = 'Block ' + (blocks.indexOf(b) + 1) + ' (' + b.mode + ')'; }
    else { bn.classList.remove('vis'); }
}

// ============================================================
// RANDOMIZATION ENGINE
// ============================================================
function randomize(bId) {
    var b = findBlock(bId); if (!b) return;
    b.targets.forEach(function (id) {
        var p = PMap[id]; if (!p || p.lk) return; var val;
        if (b.rangeMode === 'relative') { val = p.v + (Math.random() * 2 - 1) * (b.rMax / 100); }
        else { var mn = b.rMin / 100, mx = b.rMax / 100; val = mn + Math.random() * (mx - mn); }
        if (b.quantize && b.qSteps > 1) { var step = 1 / b.qSteps; val = Math.round(val / step) * step; }
        p.v = Math.max(0, Math.min(1, val));
    });
    renderAllPlugins();
}

// ============================================================
// ENVELOPE SIMULATION
// ============================================================
var simTime = 0;
function simEnvelope() {
    simTime += 30; var ph = (simTime % 500) / 500, raw;
    if (ph < 0.02) raw = 1; else if (ph < 0.15) raw = Math.exp(-(ph - 0.02) * 20); else raw = Math.exp(-(ph - 0.15) * 3) * 0.1;
    var nu = false;
    blocks.forEach(function (b) {
        if (b.mode !== 'envelope') return;
        var ac = Math.exp(-1 / (b.envAtk * 0.03)), rc = Math.exp(-1 / (b.envRel * 0.03));
        var tgt = raw * (b.envSens / 50); envValue = tgt > envValue ? envValue * ac + tgt * (1 - ac) : envValue * rc + tgt * (1 - rc);
        var cl = Math.max(0, Math.min(1, envValue)), mp = b.envInvert ? (1 - cl) : cl;
        var fl = document.getElementById('envFill-' + b.id), lb = document.getElementById('envLbl-' + b.id);
        if (fl) fl.style.height = (cl * 100) + '%'; if (lb) lb.textContent = (cl * 100).toFixed(0) + '%';
        var mn = b.rMin / 100, mx = b.rMax / 100;
        b.targets.forEach(function (id) { var p = PMap[id]; if (!p || p.lk) return; p.v = mn + mp * (mx - mn); nu = true; });
        var dot = document.getElementById('envD'); if (dot) dot.className = 'sd' + (cl > 0.05 ? ' env' : '');
    });
    if (nu) { document.querySelectorAll('.pcard-params .pr').forEach(function (row) { var pid = row.getAttribute('data-pid'); if (!pid) return; var p = PMap[pid]; if (!p) return; var ve = row.querySelector('.pr-val'), be = row.querySelector('.pr-bar-f'); if (ve) ve.textContent = (p.v * 100).toFixed(0) + '%'; if (be) be.style.width = (p.v * 100) + '%'; }); }
    requestAnimationFrame(function () { setTimeout(simEnvelope, 30); });
}

// ============================================================
// HEADER CONTROLS
// ============================================================
document.getElementById('bypassBtn').onclick = function () { this.classList.toggle('on'); };
document.getElementById('mixSlider').oninput = function () { document.getElementById('mixVal').textContent = this.value + '%'; };
document.getElementById('addRnd').onclick = function () { addBlock('randomize'); };
document.getElementById('addEnv').onclick = function () { addBlock('envelope'); };
document.getElementById('addPluginBtn').onclick = function () { openPluginBrowser(); };

// ============================================================
// PLUGIN BROWSER MODAL
// ============================================================
var modalCat = 'all', modalQuery = '';
function openPluginBrowser() {
    modalCat = 'all'; modalQuery = '';
    document.getElementById('modalSearch').value = '';
    document.getElementById('scanPaths').classList.remove('vis');
    renderModalTabs(); renderModalList();
    document.getElementById('pluginModal').classList.add('vis');
    document.getElementById('modalSearch').focus();
}
function closePluginBrowser() { document.getElementById('pluginModal').classList.remove('vis'); }
document.getElementById('modalClose').onclick = closePluginBrowser;
document.getElementById('pluginModal').onclick = function (e) { if (e.target === this) closePluginBrowser(); };
document.getElementById('modalSearch').oninput = function () { modalQuery = this.value; renderModalList(); };
document.getElementById('modalTabs').onclick = function (e) {
    var tab = e.target.closest('.modal-tab'); if (!tab) return;
    modalCat = tab.dataset.cat; renderModalTabs(); renderModalList();
};
function renderModalTabs() {
    document.querySelectorAll('.modal-tab').forEach(function (t) {
        t.className = 'modal-tab' + (t.dataset.cat === modalCat ? ' on' : '');
    });
}
function renderModalList() {
    var body = document.getElementById('modalBody');
    var q = modalQuery.toLowerCase();
    var filtered = PLUGIN_LIB.filter(function (p) {
        if (modalCat !== 'all' && p.cat !== modalCat) return false;
        if (q && p.name.toLowerCase().indexOf(q) === -1 && p.vendor.toLowerCase().indexOf(q) === -1) return false;
        return true;
    });
    document.getElementById('modalInfo').textContent = filtered.length + ' plugin' + (filtered.length !== 1 ? 's' : '') + ' found';
    if (filtered.length === 0) { body.innerHTML = '<div class="no-results">No plugins match your search</div>'; return; }
    var h = '';
    filtered.forEach(function (p) {
        var initials = p.name.split(' ').map(function (w) { return w[0]; }).join('').substring(0, 2);
        h += '<div class="plug-row" data-pname="' + p.name + '">';
        h += '<div class="plug-icon">' + initials + '</div>';
        h += '<div class="plug-info"><div class="plug-name">' + p.name + '</div><div class="plug-meta">' + p.vendor + ' &middot; ' + p.params.length + ' params</div></div>';
        h += '<span class="plug-type ' + p.cat + '">' + p.cat + '</span>';
        h += '</div>';
    });
    body.innerHTML = h;
    body.querySelectorAll('.plug-row').forEach(function (row) {
        row.onclick = function () {
            var pname = row.dataset.pname;
            var lib = PLUGIN_LIB.filter(function (p) { return p.name === pname; })[0];
            if (lib) addPlugin(lib.name);
            closePluginBrowser();
        };
    });
}

// Scan paths toggle
document.getElementById('scanToggle').onclick = function () {
    var sp = document.getElementById('scanPaths');
    sp.classList.toggle('vis'); renderScanPaths();
};
document.getElementById('addScanPath').onclick = function () {
    scanPaths.push(''); renderScanPaths();
};
function renderScanPaths() {
    var c = document.getElementById('scanPathList'); c.innerHTML = '';
    scanPaths.forEach(function (p, i) {
        var row = document.createElement('div'); row.className = 'scan-path-row';
        row.innerHTML = '<input type="text" value="' + p + '" data-spi="' + i + '"><button class="scan-path-rm" data-sprm="' + i + '">&times;</button>';
        c.appendChild(row);
    });
    c.querySelectorAll('input').forEach(function (inp) {
        inp.onchange = function () { scanPaths[parseInt(inp.dataset.spi)] = inp.value; };
    });
    c.querySelectorAll('[data-sprm]').forEach(function (btn) {
        btn.onclick = function () { scanPaths.splice(parseInt(btn.dataset.sprm), 1); renderScanPaths(); };
    });
}

// ============================================================
// UTILITIES
// ============================================================
function flashDot(id) { var d = document.getElementById(id); d.classList.add('on'); setTimeout(function () { d.classList.remove('on'); }, 150); }
function updCounts() { var ap = allParams(); document.getElementById('stP').textContent = ap.length; document.getElementById('stL').textContent = ap.filter(function (p) { return p.lk || p.alk; }).length; document.getElementById('stB').textContent = blocks.length; document.getElementById('blockInfo').textContent = blocks.length + ' blocks'; }

// ============================================================
// INIT
// ============================================================
addPlugin('Serum');
addBlock('randomize');
simEnvelope();
