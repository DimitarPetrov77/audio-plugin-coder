// ============================================================
// LOGIC BLOCKS
// Block creation, rendering, wiring, randomize, sync to host
// ============================================================
var internalBpm = 120; // Internal tempo (set in Settings)
// Build SVG arc knob for logic block params. mode: 'rand','env','smp','morph','shapes'
function buildBlockKnob(val, min, max, size, mode, field, blockId, label, unit, fmtFn, disabled, laneIdx) {
    var norm = (val - min) / (max - min);
    var r = size / 2, cx = r, cy = r, ir = r - 3;
    var startAngle = 135 * Math.PI / 180, endAngle = 405 * Math.PI / 180;
    var span = endAngle - startAngle;
    var tPath = describeArc(cx, cy, ir, startAngle, endAngle);
    var va = startAngle + norm * span;
    var vPath = norm > 0.005 ? describeArc(cx, cy, ir, startAngle, va) : '';
    var dx = cx + ir * Math.cos(va), dy = cy + ir * Math.sin(va);
    var tVar = 'var(--lk-' + mode + '-track, var(--knob-track))';
    var vVar = 'var(--lk-' + mode + '-value, var(--knob-value))';
    var dVar = 'var(--lk-' + mode + '-dot, var(--knob-dot))';
    var svg = '<svg width="' + size + '" height="' + size + '" viewBox="0 0 ' + size + ' ' + size + '">';
    svg += '<path d="' + tPath + '" fill="none" stroke="' + tVar + '" stroke-width="2.5" stroke-linecap="round"/>';
    if (vPath) svg += '<path d="' + vPath + '" fill="none" stroke="' + vVar + '" stroke-width="2.5" stroke-linecap="round"/>';
    svg += '<circle cx="' + dx.toFixed(1) + '" cy="' + dy.toFixed(1) + '" r="2.5" fill="' + dVar + '"/>';
    svg += '</svg>';
    var dispVal = fmtFn ? fmtFn(val) : (unit === 'ms' ? Math.round(val) + 'ms' : unit === 'dB' ? Math.round(val) + 'dB' : unit === '%' ? Math.round(val) + '%' : unit === '±%' ? '±' + Math.round(val) + '%' : unit === '±' ? (val > 0 ? '+' : '') + Math.round(val) + '%' : Math.round(val) + (unit || ''));
    var liAttr = (laneIdx != null) ? ' data-li="' + laneIdx + '"' : '';
    var h = '<div class="bk' + (disabled ? ' sync-disabled' : '') + '" data-b="' + blockId + '" data-f="' + field + '" data-min="' + min + '" data-max="' + max + '"' + liAttr + (disabled ? ' data-disabled="1"' : '') + '>';
    h += '<div class="bk-svg">' + svg + '</div>';
    h += '<div class="bk-val">' + dispVal + '</div>';
    h += '<div class="bk-lbl">' + label + '</div>';
    h += '</div>';
    return h;
}
function buildKnobRow(knobs) { return '<div class="knob-row">' + knobs + '</div>'; }

function clampToCircle(x, y) {
    var dx = x - 0.5, dy = y - 0.5;
    var dist = Math.sqrt(dx * dx + dy * dy);
    var r = 0.45; // slightly inside the circle edge so dots don't overflow
    if (dist > r) { var s = r / dist; dx *= s; dy *= s; }
    return { x: 0.5 + dx, y: 0.5 + dy };
}
// Get the fixed sector position for a snapshot by index (12 sectors like a clock)
function getSnapSectorPos(index) {
    var angle = -Math.PI / 2 + (2 * Math.PI * index / 12); // 12 fixed sectors, start from top
    var radius = 0.35;
    return { x: 0.5 + radius * Math.cos(angle), y: 0.5 + radius * Math.sin(angle) };
}
// Find plugin name by hostId
function getPluginName(hostId) {
    for (var i = 0; i < pluginBlocks.length; i++) {
        if (pluginBlocks[i].hostId === hostId || pluginBlocks[i].id === hostId) return pluginBlocks[i].name;
    }
    return '';
}
// Shared beat division lists
var BEAT_DIVS = [
    { v: '1/1', label: '1/1' },
    { v: '1/2', label: '1/2' }, { v: '1/2.', label: '1/2.' }, { v: '1/2T', label: '1/2T' },
    { v: '1/4', label: '1/4' }, { v: '1/4.', label: '1/4.' }, { v: '1/4T', label: '1/4T' },
    { v: '1/8', label: '1/8' }, { v: '1/8.', label: '1/8.' }, { v: '1/8T', label: '1/8T' },
    { v: '1/16', label: '1/16' }, { v: '1/16.', label: '1/16.' }, { v: '1/16T', label: '1/16T' },
    { v: '1/32', label: '1/32' },
    { v: '1/64', label: '1/64' }
];
var LANE_LOOP_OPTS = [
    { v: '1/16', label: '1/16' }, { v: '1/8', label: '1/8' }, { v: '1/4', label: '1/4' },
    { v: '1/2', label: '1/2' }, { v: '1/1', label: '1/1' }, { v: '2/1', label: '2 bars' },
    { v: '4/1', label: '4 bars' }, { v: 'free', label: 'Free' }
];
var LANE_COLORS = ['#6088CC', '#CC8050', '#50CC80', '#CC5078', '#70BBCC', '#CCB850', '#A070CC', '#50CCB0'];
var MORPH_DIVS = [
    { v: '8', label: '8 Bars' }, { v: '4', label: '4 Bars' }, { v: '2', label: '2 Bars' }
].concat(BEAT_DIVS);
// Render a <select> with beat divisions
function renderBeatDivSelect(blockId, field, currentVal, divList) {
    if (!divList) divList = BEAT_DIVS;
    var h = '<select class="sub-sel" data-b="' + blockId + '" data-f="' + field + '">';
    divList.forEach(function (d) {
        h += '<option value="' + d.v + '"' + (currentVal === d.v ? ' selected' : '') + '>' + d.label + '</option>';
    });
    h += '</select>';
    return h;
}
// Convert morphSpeed (0-100) to display string
function morphSpeedDisplay(sp) {
    return Math.round(sp) + '%';
}
// Logic blocks
function addBlock(mode) {
    if (!mode) mode = 'randomize'; var id = ++bc;
    var blk = {
        id: id, mode: mode, enabled: true, targets: new Set(), targetBases: {}, targetRanges: {}, targetRangeBases: {}, colorIdx: bc - 1, trigger: 'manual', beatDiv: '1/4', midiMode: 'any_note', midiNote: 60, midiCC: 1, midiCh: 0, velScale: false, threshold: -12, audioSrc: 'main', rMin: 0, rMax: 100, rangeMode: 'absolute', polarity: 'bipolar', quantize: false, qSteps: 12, movement: 'instant', glideMs: 200, envAtk: 10, envRel: 100, envSens: 50, envInvert: false, loopMode: 'loop', sampleSpeed: 1.0, sampleReverse: false, jumpMode: 'restart', sampleName: '', sampleWaveform: null, expanded: true, clockSource: 'daw',
        snapshots: [], playheadX: 0.5, playheadY: 0.5, morphMode: 'manual', exploreMode: 'wander', lfoShape: 'circle', lfoDepth: 80, lfoRotation: 0, morphSpeed: 50, morphAction: 'jump', stepOrder: 'cycle', morphSource: 'midi', jitter: 0, morphGlide: 200, morphTempoSync: false, morphSyncDiv: '1/4', snapRadius: 100,
        shapeType: 'circle', shapeTracking: 'horizontal', shapeSize: 80, shapeSpin: 0, shapeSpeed: 50, shapeDepth: 50, shapeRange: 'relative', shapePolarity: 'bipolar', shapeTempoSync: false, shapeSyncDiv: '1/4', shapeTrigger: 'free',
        laneTool: 'draw', laneGrid: '1/8', lanes: []
    };
    blocks.push(blk);
    // shapes_range defaults to unipolar (drag direction) — most intuitive for per-param ranges
    if (mode === 'shapes_range') blk.shapePolarity = 'unipolar';
    actId = id; assignMode = null; renderBlocks(); renderAllPlugins(); updCounts(); syncBlocksToHost();
}
// Assign a param to a block, capturing its current value as the relative base
function assignTarget(block, pid) {
    if (!block || !pid) return;
    var p = PMap[pid];
    if (!p || p.lk) return;
    block.targets.add(pid);
    // Capture value at assignment time if not already stored
    if (!block.targetBases) block.targetBases = {};
    if (block.targetBases[pid] === undefined) {
        block.targetBases[pid] = p.v;
    }
}
// Build a single logic block card DOM element
function buildBlockCard(b, bi) {
    var col = bColor(b.colorIdx), isAct = b.id === actId, isAs = assignMode === b.id;
    var card = document.createElement('div');
    var modeClass = b.mode === 'randomize' ? ' mode-rand' : (b.mode === 'envelope' ? ' mode-env' : (b.mode === 'morph_pad' ? ' mode-morph' : (b.mode === 'shapes' || b.mode === 'shapes_range' ? ' mode-shapes' : (b.mode === 'lane' ? ' mode-lane' : ' mode-smp'))));
    card.className = 'lcard' + modeClass + (isAct ? ' active' : '') + (b.mode === 'envelope' && isAct ? ' env-active' : '') + (b.mode === 'sample' && isAct ? ' smp-active' : '') + (b.mode === 'morph_pad' && isAct ? ' morph-active' : '') + ((b.mode === 'shapes' || b.mode === 'shapes_range') && isAct ? ' shapes-active' : '') + (b.mode === 'lane' && isAct ? ' lane-active' : '') + (!b.enabled ? ' disabled' : '');
    card.setAttribute('data-blockid', b.id);
    var sum = ''; if (b.mode === 'envelope') sum = 'Atk ' + b.envAtk + 'ms / Rel ' + b.envRel + 'ms';
    else if (b.mode === 'sample') sum = (b.sampleName || 'No sample') + ' / ' + b.loopMode;
    else if (b.mode === 'morph_pad') { var ml = { manual: 'Manual', auto: 'Auto', trigger: 'Trigger' }[b.morphMode] || 'Manual'; sum = 'Morph / ' + ml + ' / ' + (b.snapshots ? b.snapshots.length : 0) + ' snaps'; }
    else if (b.mode === 'shapes') { sum = (b.shapeType || 'circle') + ' / ' + (b.shapeTracking || 'horizontal') + ' / ' + (b.shapeRange === 'relative' ? 'Rel' : 'Abs'); }
    else if (b.mode === 'shapes_range') { var rc = 0; if (b.targetRanges) { for (var k in b.targetRanges) rc++; } sum = (b.shapeType || 'circle') + ' / ' + (b.shapeTracking || 'horizontal') + ' / ' + rc + ' ranges'; }
    else if (b.mode === 'lane') { var lc = b.lanes ? b.lanes.length : 0; sum = 'Lane / ' + lc + ' lane' + (lc !== 1 ? 's' : '') + ' / ' + (b.laneGrid || '1/8'); }
    else { sum = ({ manual: 'Manual', tempo: 'Tempo', midi: 'MIDI', audio: 'Audio' }[b.trigger]) + ' / ' + (b.movement === 'instant' ? 'Instant' : 'Smooth'); }
    var tc = b.targets.size, tH = '';
    if (tc === 0) tH = '<span class="tg-empty">No params assigned</span>';
    else { var ta = Array.from(b.targets).slice(0, 6); for (var ti = 0; ti < ta.length; ti++) { var tp = PMap[ta[ti]]; if (!tp) continue; var pn = paramPluginName(ta[ti]); tH += '<span class="tg" style="background:' + col + '22;border:1px solid ' + col + '66;color:' + col + '">' + pn + ': ' + tp.name + '<span class="tx" data-b="' + b.id + '" data-p="' + ta[ti] + '">x</span></span>'; } if (tc > 6) tH += '<span class="tg" style="background:var(--bg-inset);border:1px solid var(--border);color:var(--text-muted)">+' + (tc - 6) + '</span>'; }
    var abS = isAs ? 'background:' + col + ';color:white;border-color:' + col : '', abT = isAs ? 'Done' : 'Assign';
    var pwrCls = b.enabled ? 'pwr-btn on' : 'pwr-btn';
    var bH = '';
    // ── MODE — top section ──
    bH += '<div class="block-section"><span class="block-section-label">Mode</span><div class="seg" data-b="' + b.id + '" data-f="mode"><button class="' + (b.mode === 'randomize' ? 'on' : '') + '" data-v="randomize">Randomize</button><button class="' + (b.mode === 'envelope' ? 'on' : '') + '" data-v="envelope">Envelope</button><button class="' + (b.mode === 'sample' ? 'on' : '') + '" data-v="sample">Sample</button><button class="' + (b.mode === 'morph_pad' ? 'on' : '') + '" data-v="morph_pad">Morph Pad</button><button class="' + (b.mode === 'shapes' ? 'on' : '') + '" data-v="shapes">Shapes</button><button class="' + (b.mode === 'shapes_range' ? 'on' : '') + '" data-v="shapes_range">Shapes Range</button><button class="' + (b.mode === 'lane' ? 'on' : '') + '" data-v="lane">Lane</button></div></div>';
    // ── MODE BODY ──
    if (b.mode === 'randomize') bH += renderRndBody(b); else if (b.mode === 'sample') bH += renderSampleBody(b); else if (b.mode === 'morph_pad') bH += renderMorphBody(b); else if (b.mode === 'shapes') bH += renderShapesBody(b); else if (b.mode === 'shapes_range') bH += renderShapesRangeBody(b); else if (b.mode === 'lane') bH += renderLaneBody(b); else bH += renderEnvBody(b);
    // ── TARGETS ──
    bH += '<div class="block-section"><span class="block-section-label">Targets (' + tc + ')</span><div class="tgt-box">' + tH + '</div></div>';
    // ── FIRE (randomize only) ──
    if (b.mode === 'randomize') bH += '<div class="block-section" style="border-bottom:none;padding-bottom:0"><button class="fire" data-b="' + b.id + '">FIRE</button></div>';
    var ch = '<span class="lchev ' + (b.expanded ? 'open' : '') + '">&#9654;</span>';
    card.innerHTML = '<div class="lhead" data-id="' + b.id + '"><div style="display:flex;align-items:center">' + ch + '<span class="block-color" style="background:' + col + '"></span><span class="ltitle">Block ' + (bi + 1) + '</span><span class="lsum">' + sum + ' / ' + tc + ' params</span></div><div style="display:flex;gap:4px;align-items:center"><div class="' + pwrCls + '" data-pwr="' + b.id + '"></div><button class="sm-btn assign-btn" data-id="' + b.id + '" style="' + abS + '">' + abT + '</button><button class="lclose" data-id="' + b.id + '">x</button></div></div><div class="lbody ' + (b.expanded ? '' : 'hide') + '">' + bH + '</div>';
    return card;
}
// Stamp for detecting structural changes in blocks (add/remove)
var _blockStamp = '';
function getBlockStamp() { return blocks.map(function (b) { return b.id; }).join(','); }

function renderBlocks() {
    var c = document.getElementById('lpScroll');
    var newStamp = getBlockStamp();

    // STRUCTURAL CHANGE: different blocks — full rebuild
    if (newStamp !== _blockStamp || c.children.length !== blocks.length) {
        _blockStamp = newStamp;
        c.innerHTML = '';
        for (var bi = 0; bi < blocks.length; bi++) {
            c.appendChild(buildBlockCard(blocks[bi], bi));
        }
        wireBlocks(); wireBlockDropTargets(); updateAssignBanner();
        return;
    }

    // PATCH: same structure — rebuild each card in-place
    for (var bi = 0; bi < blocks.length; bi++) {
        var b = blocks[bi];
        var oldCard = c.children[bi];
        if (!oldCard) continue;
        var newCard = buildBlockCard(b, bi);
        c.replaceChild(newCard, oldCard);
    }
    wireBlocks(); wireBlockDropTargets(); updateAssignBanner();
}
// Wire block cards as drop targets for param drag
function wireBlockDropTargets() {
    document.querySelectorAll('.lcard[data-blockid]').forEach(function (card) {
        card.addEventListener('dragover', function (e) {
            if (e.dataTransfer.types.indexOf('text/plain') === -1) return;
            e.preventDefault();
            e.dataTransfer.dropEffect = 'copy';
            card.classList.add('drag-hover');
        });
        card.addEventListener('dragleave', function () {
            card.classList.remove('drag-hover');
        });
        card.addEventListener('drop', function (e) {
            e.preventDefault();
            card.classList.remove('drag-hover');
            var data = e.dataTransfer.getData('text/plain');
            if (!data || data.indexOf('params:') !== 0) return;
            var pids = data.replace('params:', '').split(',');
            var bid = parseInt(card.getAttribute('data-blockid'));
            var bl = findBlock(bid);
            if (!bl) return;
            pids.forEach(function (pid) {
                var pp = PMap[pid];
                if (pp && !pp.lk) assignTarget(bl, pid);
            });
            selectedParams.clear();
            renderAllPlugins(); renderBlocks(); syncBlocksToHost();
        });
    });
}
// Targeted single-block update (avoids rebuilding all blocks)
function renderSingleBlock(blockId) {
    var c = document.getElementById('lpScroll');
    for (var bi = 0; bi < blocks.length; bi++) {
        if (blocks[bi].id === blockId) {
            var oldCard = c.children[bi];
            if (!oldCard) { renderBlocks(); return; }
            var newCard = buildBlockCard(blocks[bi], bi);
            c.replaceChild(newCard, oldCard);
            wireBlocks(); wireBlockDropTargets(); updateAssignBanner();
            return;
        }
    }
}
function renderRndBody(b) {
    var h = '';

    // ── 1. BEHAVIOUR — trigger + movement combined in one row ──
    h += '<div class="block-section"><span class="block-section-label">Behaviour</span>';
    h += '<div class="behaviour-row">';
    h += '<div class="seg" data-b="' + b.id + '" data-f="trigger">';
    ['manual', 'tempo', 'midi', 'audio'].forEach(function (t) { h += '<button class="' + (b.trigger === t ? 'on' : '') + '" data-v="' + t + '">' + { manual: 'Manual', tempo: 'Tempo', midi: 'MIDI', audio: 'Audio' }[t] + '</button>'; });
    h += '</div>';
    h += '<div class="divider-dot"></div>';
    h += '<div class="seg-inline" data-b="' + b.id + '" data-f="movement"><button class="' + (b.movement === 'instant' ? 'on' : '') + '" data-v="instant">Instant</button><button class="' + (b.movement === 'glide' ? 'on' : '') + '" data-v="glide">Smooth</button></div>';
    h += '</div>';
    // Sub-options for trigger types
    h += '<div class="sub ' + (b.trigger === 'tempo' ? 'vis' : '') + '"><div class="sub-row"><span class="sub-lbl">Division</span>' + renderBeatDivSelect(b.id, 'beatDiv', b.beatDiv) + '</div></div>';
    h += '<div class="sub ' + (b.trigger === 'midi' ? 'vis' : '') + '"><div class="sub-row"><span class="sub-lbl">Mode</span><select class="sub-sel" data-b="' + b.id + '" data-f="midiMode"><option value="any_note"' + (b.midiMode === 'any_note' ? ' selected' : '') + '>Any Note</option><option value="specific_note"' + (b.midiMode === 'specific_note' ? ' selected' : '') + '>Note</option><option value="cc"' + (b.midiMode === 'cc' ? ' selected' : '') + '>CC</option></select></div>';
    h += '<div class="sub-row"><span class="sub-lbl">Channel</span><select class="sub-sel" data-b="' + b.id + '" data-f="midiCh"><option value="0"' + (b.midiCh === 0 ? ' selected' : '') + '>Any</option>';
    for (var ch = 1; ch <= 16; ch++) h += '<option value="' + ch + '"' + (b.midiCh === ch ? ' selected' : '') + '>' + ch + '</option>';
    h += '</select></div></div>';
    h += '<div class="sub ' + (b.trigger === 'audio' ? 'vis' : '') + '"><div class="sl-row"><span class="sl-lbl">Thresh</span><input type="range" min="-60" max="0" value="' + b.threshold + '" data-b="' + b.id + '" data-f="threshold"><span class="sl-val">' + b.threshold + ' dB</span></div><div class="sub-row"><span class="sub-lbl">Source</span><select class="sub-sel" data-b="' + b.id + '" data-f="audioSrc"><option value="main"' + (b.audioSrc === 'main' ? ' selected' : '') + '>Main Input</option><option value="sidechain"' + (b.audioSrc === 'sidechain' ? ' selected' : '') + '>Sidechain</option></select></div></div>';
    // Glide knob (shown when smooth is selected)
    if (b.movement === 'glide') h += buildKnobRow(buildBlockKnob(b.glideMs, 1, 2000, 36, 'rand', 'glideMs', b.id, 'Glide', 'ms'));
    h += '</div>';

    // ── 2. CONSTRAINTS — range + quantize in inset box ──
    h += '<div class="block-section"><span class="block-section-label">Constraints</span>';
    h += '<div class="constraints-box">';
    h += '<div class="constraints-header"><div class="seg-inline" data-b="' + b.id + '" data-f="rangeMode"><button class="' + (b.rangeMode === 'absolute' ? 'on' : '') + '" data-v="absolute">Absolute</button><button class="' + (b.rangeMode === 'relative' ? 'on' : '') + '" data-v="relative">Relative</button></div></div>';
    // Range sliders
    if (b.rangeMode === 'absolute') {
        h += '<div class="sl-row"><span class="sl-lbl">Min</span><input type="range" min="0" max="100" value="' + b.rMin + '" data-b="' + b.id + '" data-f="rMin"><span class="sl-val">' + b.rMin + '%</span></div>';
        h += '<div class="sl-row"><span class="sl-lbl">Max</span><input type="range" min="0" max="100" value="' + b.rMax + '" data-b="' + b.id + '" data-f="rMax"><span class="sl-val">' + b.rMax + '%</span></div>';
    } else {
        h += '<div class="sl-row"><span class="sl-lbl">\u00b1</span><input type="range" min="1" max="100" value="' + b.rMax + '" data-b="' + b.id + '" data-f="rMax"><span class="sl-val">' + b.rMax + '%</span></div>';
    }
    // Quantize
    h += '<div class="tgl-row"><div class="tgl ' + (b.quantize ? 'on' : '') + '" data-b="' + b.id + '" data-f="quantize"></div><span class="tgl-lbl">Quantize</span><input class="sub-input" type="number" value="' + b.qSteps + '" min="2" max="128" data-b="' + b.id + '" data-f="qSteps"' + (b.quantize ? '' : ' disabled') + '><span class="sub-lbl" style="min-width:auto">steps</span></div>';
    h += '</div></div>';

    return h;
}
function renderEnvBody(b) {
    // Envelope follower always operates in relative mode, no invert
    b.rangeMode = 'relative';
    b.envInvert = false;
    var h = '';

    // ── 1. INPUT — meter + source in contained inset box ──
    h += '<div class="block-section"><span class="block-section-label">Source</span>';
    h += '<div class="env-input-box">';
    h += '<div class="brow"><span class="blbl"><span class="env-active-dot" id="envDot-' + b.id + '"></span>Envelope Follower</span><div class="env-meter" id="envMeter-' + b.id + '"><div class="env-meter-fill" id="envFill-' + b.id + '" style="height:0%"></div><div class="env-peak-line" id="envPeak-' + b.id + '" style="bottom:0%"></div><span class="env-label" id="envLbl-' + b.id + '">0%</span></div></div>';
    h += '<div class="brow-inline"><span class="blbl">Source</span><div class="seg-inline" data-b="' + b.id + '" data-f="audioSrc"><button class="' + (b.audioSrc === 'main' ? 'on' : '') + '" data-v="main">Main</button><button class="' + (b.audioSrc === 'sidechain' ? 'on' : '') + '" data-v="sidechain">Sidechain</button></div></div>';
    h += '</div></div>';

    // ── 2. RESPONSE — attack, release, gain knobs ──
    h += '<div class="block-section"><span class="block-section-label">Envelope \u0026 Level</span>';
    h += buildKnobRow(
        buildBlockKnob(b.envAtk, 1, 500, 36, 'env', 'envAtk', b.id, 'Attack', 'ms') +
        buildBlockKnob(b.envRel, 1, 2000, 36, 'env', 'envRel', b.id, 'Release', 'ms') +
        buildBlockKnob(b.envSens, 0, 100, 36, 'env', 'envSens', b.id, 'Gain', '%')
    );
    h += '</div>';

    // ── 3. RANGE — depth + polarity ──
    h += '<div class="block-section"><span class="block-section-label">Range</span>';
    h += '<div class="constraints-box">';
    h += '<div class="sl-row"><span class="sl-lbl">Depth</span><input type="range" min="0" max="100" value="' + b.rMax + '" data-b="' + b.id + '" data-f="rMax"><span class="sl-val">' + b.rMax + '%</span></div>';
    h += '<div class="polarity-row"><span class="blbl">Polarity</span><div class="seg-inline" data-b="' + b.id + '" data-f="polarity"><button class="' + ((b.polarity || 'bipolar') === 'bipolar' ? 'on' : '') + '" data-v="bipolar">\u00b1 Bi</button><button class="' + (b.polarity === 'up' ? 'on' : '') + '" data-v="up">\u2191 Up</button><button class="' + (b.polarity === 'down' ? 'on' : '') + '" data-v="down">\u2193 Down</button></div></div>';
    h += '</div></div>';

    return h;
}
function renderSampleBody(b) {
    var h = '';

    // ── 1. SAMPLE PLAYBACK — waveform + loop/reverse/speed in inset box ──
    h += '<div class="block-section"><span class="block-section-label">Sample Playback</span>';
    h += '<div class="sample-zone" data-b="' + b.id + '">';
    if (b.sampleWaveform && b.sampleWaveform.length) {
        h += '<canvas class="waveform-cv" id="waveCv-' + b.id + '" width="260" height="48"></canvas>';
        h += '<div class="waveform-head" id="waveHead-' + b.id + '"></div>';
        h += '<div class="sample-name">' + (b.sampleName || 'Loaded') + '</div>';
    } else {
        h += '<div class="drop-label">No sample loaded</div>';
    }
    h += '<button class="sm-btn load-smp" data-b="' + b.id + '">Load</button></div>';
    h += '<div class="constraints-box">';
    h += '<div class="behaviour-row">';
    h += '<div class="seg-inline" data-b="' + b.id + '" data-f="loopMode">';
    h += '<button class="' + (b.loopMode === 'oneshot' ? 'on' : '') + '" data-v="oneshot">1-shot</button>';
    h += '<button class="' + (b.loopMode === 'loop' ? 'on' : '') + '" data-v="loop">Loop</button>';
    h += '<button class="' + (b.loopMode === 'pingpong' ? 'on' : '') + '" data-v="pingpong">P-pong</button>';
    h += '</div>';
    h += '<div class="tgl-row" style="margin-left:auto"><div class="tgl ' + (b.sampleReverse ? 'on' : '') + '" data-b="' + b.id + '" data-f="sampleReverse"></div><span class="tgl-lbl">Rev</span></div>';
    h += '</div>';
    h += '<div class="sl-row"><span class="sl-lbl">Speed</span>';
    h += '<input type="range" min="10" max="3200" value="' + Math.round(b.sampleSpeed * 100) + '" data-b="' + b.id + '" data-f="sampleSpeedPct">';
    h += '<span class="sl-val">' + b.sampleSpeed.toFixed(1) + 'x</span></div>';
    h += '</div></div>';

    // ── 2. RANGE — abs/rel + polarity + sliders + invert in inset box ──
    h += '<div class="block-section"><span class="block-section-label">Range</span>';
    h += '<div class="constraints-box">';
    h += '<div class="behaviour-row">';
    h += '<div class="seg-inline" data-b="' + b.id + '" data-f="rangeMode"><button class="' + (b.rangeMode === 'absolute' ? 'on' : '') + '" data-v="absolute">Absolute</button><button class="' + (b.rangeMode === 'relative' ? 'on' : '') + '" data-v="relative">Relative</button></div>';
    if (b.rangeMode === 'relative') {
        h += '<div class="seg-inline" style="margin-left:auto" data-b="' + b.id + '" data-f="polarity"><button class="' + ((b.polarity || 'bipolar') === 'bipolar' ? 'on' : '') + '" data-v="bipolar">\u00b1 Bi</button><button class="' + (b.polarity === 'up' ? 'on' : '') + '" data-v="up">\u2191 Up</button><button class="' + (b.polarity === 'down' ? 'on' : '') + '" data-v="down">\u2193 Down</button></div>';
    }
    h += '</div>';
    if (b.rangeMode === 'absolute') {
        h += '<div class="sl-row"><span class="sl-lbl">Min</span><input type="range" min="0" max="100" value="' + b.rMin + '" data-b="' + b.id + '" data-f="rMin"><span class="sl-val">' + b.rMin + '%</span></div>';
        h += '<div class="sl-row"><span class="sl-lbl">Max</span><input type="range" min="0" max="100" value="' + b.rMax + '" data-b="' + b.id + '" data-f="rMax"><span class="sl-val">' + b.rMax + '%</span></div>';
    } else {
        h += '<div class="sl-row"><span class="sl-lbl">\u00b1</span><input type="range" min="1" max="100" value="' + b.rMax + '" data-b="' + b.id + '" data-f="rMax"><span class="sl-val">' + b.rMax + '%</span></div>';
    }
    h += '<div class="tgl-row"><div class="tgl ' + (b.envInvert ? 'on' : '') + '" data-b="' + b.id + '" data-f="envInvert"></div><span class="tgl-lbl">Invert</span></div>';
    h += '</div></div>';

    // ── 3. ENVELOPE & LEVEL — attack/release/gain/depth knobs ──
    h += '<div class="block-section"><span class="block-section-label">Envelope \u0026 Level</span>';
    var knobs = buildBlockKnob(b.envAtk, 1, 500, 36, 'smp', 'envAtk', b.id, 'Attack', 'ms') +
        buildBlockKnob(b.envRel, 1, 2000, 36, 'smp', 'envRel', b.id, 'Release', 'ms') +
        buildBlockKnob(b.envSens, 0, 100, 36, 'smp', 'envSens', b.id, 'Gain', '%');
    if (b.rangeMode === 'relative') knobs += buildBlockKnob(b.rMax, 0, 100, 36, 'smp', 'rMax', b.id, 'Depth', '%');
    h += buildKnobRow(knobs);
    h += '</div>';

    // ── 4. JUMP TRIGGER — trigger + sub-options + on jump in inset box ──
    h += '<div class="block-section"><span class="block-section-label">Jump Trigger</span>';
    h += '<div class="constraints-box">';
    h += '<div class="seg" data-b="' + b.id + '" data-f="trigger">';
    h += '<button class="' + (b.trigger === 'manual' ? 'on' : '') + '" data-v="manual">None</button>';
    h += '<button class="' + (b.trigger === 'tempo' ? 'on' : '') + '" data-v="tempo">Tempo</button>';
    h += '<button class="' + (b.trigger === 'midi' ? 'on' : '') + '" data-v="midi">MIDI</button>';
    h += '<button class="' + (b.trigger === 'audio' ? 'on' : '') + '" data-v="audio">Audio</button>';
    h += '</div>';
    // Trigger sub-options
    if (b.trigger === 'tempo') {
        h += '<div class="behaviour-row"><span class="sub-lbl">Div</span>' + renderBeatDivSelect(b.id, 'beatDiv', b.beatDiv);
        h += '<span class="sub-lbl" style="margin-left:auto">On jump</span><div class="seg-inline" data-b="' + b.id + '" data-f="jumpMode"><button class="' + (b.jumpMode === 'restart' ? 'on' : '') + '" data-v="restart">Restart</button><button class="' + (b.jumpMode === 'random' ? 'on' : '') + '" data-v="random">Random</button></div></div>';
    } else if (b.trigger === 'midi') {
        h += '<div class="sub-row"><span class="sub-lbl">Mode</span><select class="sub-sel" data-b="' + b.id + '" data-f="midiMode">';
        h += '<option value="any_note"' + (b.midiMode === 'any_note' ? ' selected' : '') + '>Any Note</option>';
        h += '<option value="specific_note"' + (b.midiMode === 'specific_note' ? ' selected' : '') + '>Note</option>';
        h += '<option value="cc"' + (b.midiMode === 'cc' ? ' selected' : '') + '>CC</option></select>';
        if (b.midiMode === 'specific_note') h += '<input class="sub-input" type="number" min="0" max="127" value="' + b.midiNote + '" data-b="' + b.id + '" data-f="midiNote">';
        if (b.midiMode === 'cc') h += '<input class="sub-input" type="number" min="0" max="127" value="' + b.midiCC + '" data-b="' + b.id + '" data-f="midiCC">';
        h += '<span class="sub-lbl">Ch</span><select class="sub-sel" data-b="' + b.id + '" data-f="midiCh"><option value="0"' + (b.midiCh == 0 ? ' selected' : '') + '>Any</option>';
        for (var c = 1; c <= 16; c++) h += '<option value="' + c + '"' + (parseInt(b.midiCh) === c ? ' selected' : '') + '>' + c + '</option>';
        h += '</select></div>';
        h += '<div class="behaviour-row"><span class="sub-lbl">On jump</span><div class="seg-inline" data-b="' + b.id + '" data-f="jumpMode"><button class="' + (b.jumpMode === 'restart' ? 'on' : '') + '" data-v="restart">Restart</button><button class="' + (b.jumpMode === 'random' ? 'on' : '') + '" data-v="random">Random</button></div></div>';
    } else if (b.trigger === 'audio') {
        h += '<div class="sub-row"><span class="sub-lbl">Src</span><select class="sub-sel" data-b="' + b.id + '" data-f="audioSrc">';
        h += '<option value="main"' + (b.audioSrc === 'main' ? ' selected' : '') + '>Main</option>';
        h += '<option value="sidechain"' + (b.audioSrc === 'sidechain' ? ' selected' : '') + '>SC</option></select>';
        h += '<span class="sub-lbl">Thr</span><input class="sub-input" type="number" min="-60" max="0" value="' + b.threshold + '" data-b="' + b.id + '" data-f="threshold"><span class="sub-lbl">dB</span></div>';
        h += '<div class="behaviour-row"><span class="sub-lbl">On jump</span><div class="seg-inline" data-b="' + b.id + '" data-f="jumpMode"><button class="' + (b.jumpMode === 'restart' ? 'on' : '') + '" data-v="restart">Restart</button><button class="' + (b.jumpMode === 'random' ? 'on' : '') + '" data-v="random">Random</button></div></div>';
    } else {
        // None - still show on-jump inline
        h += '<div class="behaviour-row"><span class="sub-lbl">On jump</span><div class="seg-inline" data-b="' + b.id + '" data-f="jumpMode"><button class="' + (b.jumpMode === 'restart' ? 'on' : '') + '" data-v="restart">Restart</button><button class="' + (b.jumpMode === 'random' ? 'on' : '') + '" data-v="random">Random</button></div></div>';
    }
    h += '</div></div>';

    return h;
}
// Build SVG path visualizing the LFO shape on the morph pad
function buildLfoPathSvg(b) {
    var depth = (b.lfoDepth != null ? b.lfoDepth : 80) / 100;
    var R = depth * 0.45;
    var shape = b.lfoShape || 'circle';
    var twoPi = Math.PI * 2;
    var halfPi = Math.PI / 2;
    var N = 200; // sample points
    var pts = [];

    for (var i = 0; i <= N; i++) {
        var t = (i / N) * twoPi;
        var dx = 0, dy = 0;
        if (shape === 'circle') {
            dx = R * Math.cos(t); dy = R * Math.sin(t);
        } else if (shape === 'figure8') {
            dx = R * Math.sin(t); dy = R * Math.sin(t * 2);
        } else if (shape === 'sweepX') {
            dx = R * Math.sin(t); dy = 0;
        } else if (shape === 'sweepY') {
            dx = 0; dy = R * Math.sin(t);
        } else if (shape === 'triangle' || shape === 'square' || shape === 'hexagon') {
            var n = shape === 'triangle' ? 3 : (shape === 'square' ? 4 : 6);
            var segF = t * n / twoPi;
            var seg = Math.floor(segF) % n;
            var segT = segF - Math.floor(segF);
            var a0 = twoPi * seg / n - halfPi;
            var a1 = twoPi * ((seg + 1) % n) / n - halfPi;
            dx = R * (Math.cos(a0) + segT * (Math.cos(a1) - Math.cos(a0)));
            dy = R * (Math.sin(a0) + segT * (Math.sin(a1) - Math.sin(a0)));
        } else if (shape === 'pentagram') {
            var order = [0, 2, 4, 1, 3];
            var segF = t * 5 / twoPi;
            var seg = Math.floor(segF) % 5;
            var segT = segF - Math.floor(segF);
            var from = order[seg], to = order[(seg + 1) % 5];
            var a0 = twoPi * from / 5 - halfPi;
            var a1 = twoPi * to / 5 - halfPi;
            dx = R * (Math.cos(a0) + segT * (Math.cos(a1) - Math.cos(a0)));
            dy = R * (Math.sin(a0) + segT * (Math.sin(a1) - Math.sin(a0)));
        } else if (shape === 'hexagram') {
            // Star of David: two overlapping triangles
            var hexPts = [];
            for (var hi = 0; hi < 6; hi++) {
                var angle = twoPi * hi / 6 - halfPi;
                hexPts.push({ x: R * Math.cos(angle), y: R * Math.sin(angle) });
            }
            var hexOrder = [0, 3, 1, 4, 2, 5];
            var segF = t * 6 / twoPi;
            var seg = Math.floor(segF) % 6;
            var segT = segF - Math.floor(segF);
            var fromP = hexPts[hexOrder[seg]];
            var toP = hexPts[hexOrder[(seg + 1) % 6]];
            dx = fromP.x + segT * (toP.x - fromP.x);
            dy = fromP.y + segT * (toP.y - fromP.y);
        } else if (shape === 'rose4') {
            var r = R * Math.abs(Math.cos(2 * t));
            dx = r * Math.cos(t); dy = r * Math.sin(t);
        } else if (shape === 'lissajous') {
            dx = R * Math.sin(3 * t); dy = R * Math.sin(2 * t);
        } else if (shape === 'spiral') {
            var progress = t / twoPi;
            var rNorm = progress < 0.5 ? progress * 2 : (1 - progress) * 2;
            var sR = R * (0.05 + 0.95 * rNorm);
            var sA = t * 3;
            dx = sR * Math.cos(sA); dy = sR * Math.sin(sA);
        } else {
            dx = R * Math.cos(t); dy = R * Math.sin(t);
        }
        // Convert to pad percentage (center = 50%, y inverted)
        var px = (0.5 + dx) * 100;
        var py = (1 - (0.5 + dy)) * 100;
        pts.push(px.toFixed(1) + ',' + py.toFixed(1));
    }
    // Rotation is applied in real-time by realtime.js using the actual C++ angle
    return '<svg xmlns="http://www.w3.org/2000/svg" class="lfo-path-svg" viewBox="0 0 100 100" preserveAspectRatio="xMidYMid meet"><polyline points="' + pts.join(' ') + '" fill="none" stroke-width="1" vector-effect="non-scaling-stroke"/></svg>';
}
// Build SVG for shapes block — independent from LFO path
function buildShapePathSvg(b, overrideSize) {
    var sz = overrideSize !== undefined ? overrideSize : (b.shapeSize != null ? b.shapeSize : 80);
    var R = (sz / 100) * 0.48; // size 100 = nearly fills the pad
    var shape = b.shapeType || 'circle';
    var twoPi = Math.PI * 2;
    var halfPi = Math.PI / 2;
    var N = 200;
    var pts = [];

    for (var i = 0; i <= N; i++) {
        var t = (i / N) * twoPi;
        var dx = 0, dy = 0;
        if (shape === 'circle') {
            dx = R * Math.cos(t); dy = R * Math.sin(t);
        } else if (shape === 'figure8') {
            dx = R * Math.sin(t); dy = R * Math.sin(t * 2);
        } else if (shape === 'sweepX') {
            dx = R * Math.sin(t); dy = 0;
        } else if (shape === 'sweepY') {
            dx = 0; dy = R * Math.sin(t);
        } else if (shape === 'triangle' || shape === 'square' || shape === 'hexagon') {
            var n = shape === 'triangle' ? 3 : (shape === 'square' ? 4 : 6);
            var segF = t * n / twoPi;
            var seg = Math.floor(segF) % n;
            var segT = segF - Math.floor(segF);
            var a0 = twoPi * seg / n - halfPi;
            var a1 = twoPi * ((seg + 1) % n) / n - halfPi;
            dx = R * (Math.cos(a0) + segT * (Math.cos(a1) - Math.cos(a0)));
            dy = R * (Math.sin(a0) + segT * (Math.sin(a1) - Math.sin(a0)));
        } else if (shape === 'pentagram') {
            var order = [0, 2, 4, 1, 3];
            var segF = t * 5 / twoPi;
            var seg = Math.floor(segF) % 5;
            var segT = segF - Math.floor(segF);
            var from = order[seg], to = order[(seg + 1) % 5];
            var a0 = twoPi * from / 5 - halfPi;
            var a1 = twoPi * to / 5 - halfPi;
            dx = R * (Math.cos(a0) + segT * (Math.cos(a1) - Math.cos(a0)));
            dy = R * (Math.sin(a0) + segT * (Math.sin(a1) - Math.sin(a0)));
        } else if (shape === 'hexagram') {
            // Star of David: two overlapping triangles
            // Triangle A: vertices at 0°, 120°, 240° (pointing up)
            // Triangle B: vertices at 60°, 180°, 300° (pointing down)
            // Trace: A vertex 0 → B vertex 1 → A vertex 1 → B vertex 2 → A vertex 2 → B vertex 0 → close
            var hexPts = [];
            for (var hi = 0; hi < 6; hi++) {
                var angle = twoPi * hi / 6 - halfPi;
                hexPts.push({ x: R * Math.cos(angle), y: R * Math.sin(angle) });
            }
            // Path order: 0,3,1,4,2,5 — alternates between the two triangles
            var hexOrder = [0, 3, 1, 4, 2, 5];
            var segF = t * 6 / twoPi;
            var seg = Math.floor(segF) % 6;
            var segT = segF - Math.floor(segF);
            var fromP = hexPts[hexOrder[seg]];
            var toP = hexPts[hexOrder[(seg + 1) % 6]];
            dx = fromP.x + segT * (toP.x - fromP.x);
            dy = fromP.y + segT * (toP.y - fromP.y);
        } else if (shape === 'rose4') {
            // Four-petaled rose: r = R * |cos(2t)|, normalized to fill pad
            var rr = R * Math.abs(Math.cos(2 * t));
            dx = rr * Math.cos(t); dy = rr * Math.sin(t);
        } else if (shape === 'lissajous') {
            dx = R * Math.sin(3 * t); dy = R * Math.sin(2 * t);
        } else if (shape === 'spiral') {
            var progress = t / twoPi;
            var rNorm = progress < 0.5 ? progress * 2 : (1 - progress) * 2;
            var sR = R * (0.05 + 0.95 * rNorm);
            var sA = t * 3;
            dx = sR * Math.cos(sA); dy = sR * Math.sin(sA);
        } else {
            dx = R * Math.cos(t); dy = R * Math.sin(t);
        }
        // Convert to pad percentage (center = 50%, y inverted)
        var px = (0.5 + dx) * 100;
        var py = (1 - (0.5 + dy)) * 100;
        pts.push(px.toFixed(1) + ',' + py.toFixed(1));
    }
    return '<svg xmlns="http://www.w3.org/2000/svg" class="lfo-path-svg" viewBox="0 0 100 100" preserveAspectRatio="xMidYMid meet"><polyline points="' + pts.join(' ') + '" fill="none" stroke-width="1" vector-effect="non-scaling-stroke"/></svg>';
}
function renderShapesBody(b) {
    var h = '';

    // ── 1. XY PAD ──
    h += '<div class="block-section"><span class="block-section-label">XY Pad</span>';
    h += '<div class="morph-pad shapes-pad" data-b="' + b.id + '">';
    h += buildShapePathSvg(b);
    var trackClass = 'shape-readout shape-readout-' + (b.shapeTracking || 'horizontal');
    h += '<div class="' + trackClass + '" id="shapeReadout-' + b.id + '"></div>';
    h += '<div class="playhead-dot" id="shapeHead-' + b.id + '" style="left:50%;top:50%"></div>';
    h += '</div></div>';

    // ── 2. RANGE — abs/rel + polarity + retrigger in inset box ──
    h += '<div class="block-section"><span class="block-section-label">Range</span>';
    h += '<div class="constraints-box">';
    h += '<div class="behaviour-row">';
    h += '<div class="seg-inline" data-b="' + b.id + '" data-f="shapeRange"><button class="' + (b.shapeRange === 'absolute' ? 'on' : '') + '" data-v="absolute">Absolute</button><button class="' + ((b.shapeRange || 'relative') === 'relative' ? 'on' : '') + '" data-v="relative">Relative</button></div>';
    h += '<div class="seg-inline" style="margin-left:auto" data-b="' + b.id + '" data-f="shapePolarity"><button class="' + (b.shapePolarity === 'up' ? 'on' : '') + '" data-v="up">\u2191 Up</button><button class="' + ((b.shapePolarity || 'bipolar') === 'bipolar' ? 'on' : '') + '" data-v="bipolar">\u2195 Bi</button><button class="' + (b.shapePolarity === 'down' ? 'on' : '') + '" data-v="down">\u2193 Down</button></div>';
    h += '</div>';
    h += '<div class="behaviour-row"><span class="sl-lbl">Retrigger</span><div class="seg-inline" data-b="' + b.id + '" data-f="shapeTrigger"><button class="' + ((b.shapeTrigger || 'free') === 'free' ? 'on' : '') + '" data-v="free">Free</button><button class="' + (b.shapeTrigger === 'midi' ? 'on' : '') + '" data-v="midi">MIDI</button></div></div>';
    h += '</div></div>';

    // ── 3. SHAPE & TRACKING — shape select + tracking + knobs + sliders + sync ──
    h += '<div class="block-section"><span class="block-section-label">Shape &amp; Tracking</span>';
    h += '<div class="constraints-box">';
    // Shape selector
    h += '<select class="sub-sel" data-b="' + b.id + '" data-f="shapeType">';
    h += '<optgroup label="Basic">';
    h += '<option value="circle"' + (b.shapeType === 'circle' ? ' selected' : '') + '>● Circle</option>';
    h += '<option value="figure8"' + (b.shapeType === 'figure8' ? ' selected' : '') + '>∞ Figure 8</option>';
    h += '<option value="sweepX"' + (b.shapeType === 'sweepX' ? ' selected' : '') + '>↔ Sweep X</option>';
    h += '<option value="sweepY"' + (b.shapeType === 'sweepY' ? ' selected' : '') + '>↕ Sweep Y</option>';
    h += '</optgroup><optgroup label="Geometry">';
    h += '<option value="triangle"' + (b.shapeType === 'triangle' ? ' selected' : '') + '>△ Triangle</option>';
    h += '<option value="square"' + (b.shapeType === 'square' ? ' selected' : '') + '>□ Square</option>';
    h += '<option value="pentagram"' + (b.shapeType === 'pentagram' ? ' selected' : '') + '>☆ Pentagram</option>';
    h += '<option value="hexagon"' + (b.shapeType === 'hexagon' ? ' selected' : '') + '>⬡ Hexagon</option>';
    h += '<option value="hexagram"' + (b.shapeType === 'hexagram' ? ' selected' : '') + '>✡ Hexagram</option>';
    h += '</optgroup><optgroup label="Curves">';
    h += '<option value="rose4"' + (b.shapeType === 'rose4' ? ' selected' : '') + '>✿ Rose</option>';
    h += '<option value="lissajous"' + (b.shapeType === 'lissajous' ? ' selected' : '') + '>∿ Lissajous</option>';
    h += '<option value="spiral"' + (b.shapeType === 'spiral' ? ' selected' : '') + '>\uD83C\uDF00 Spiral</option>';
    h += '</select>';
    // Tracking axis
    h += '<div class="seg" data-b="' + b.id + '" data-f="shapeTracking">';
    h += '<button class="' + (b.shapeTracking === 'horizontal' ? 'on' : '') + '" data-v="horizontal">Horizontal</button>';
    h += '<button class="' + (b.shapeTracking === 'vertical' ? 'on' : '') + '" data-v="vertical">Vertical</button>';
    h += '<button class="' + (b.shapeTracking === 'distance' ? 'on' : '') + '" data-v="distance">Distance</button>';
    h += '</div>';
    // Size + Depth knobs
    var sizeVal = b.shapeSize != null ? b.shapeSize : 80;
    var depthVal = b.shapeDepth || 50;
    h += buildKnobRow(
        buildBlockKnob(sizeVal, 1, 100, 36, 'shapes', 'shapeSize', b.id, 'Size', '%') +
        buildBlockKnob(depthVal, 0, 100, 36, 'shapes', 'shapeDepth', b.id, 'Depth', '±%')
    );
    // Speed + Spin sliders
    var speedVal = b.shapeSpeed || 50;
    var spinVal = b.shapeSpin || 0;
    h += '<div class="sl-row' + (b.shapeTempoSync ? ' sync-disabled' : '') + '"><span class="sl-lbl">Speed</span><input type="range" min="1" max="100" value="' + speedVal + '" data-b="' + b.id + '" data-f="shapeSpeed"' + (b.shapeTempoSync ? ' disabled' : '') + '><span class="sl-val">' + speedVal + '%</span></div>';
    h += '<div class="sl-row"><span class="sl-lbl">Spin</span><input type="range" min="-100" max="100" value="' + spinVal + '" data-b="' + b.id + '" data-f="shapeSpin"><span class="sl-val">' + (spinVal > 0 ? '+' : '') + spinVal + '%</span></div>';
    // Sync toggle
    h += '<div class="behaviour-row"><div class="tgl ' + (b.shapeTempoSync ? 'on' : '') + '" data-b="' + b.id + '" data-f="shapeTempoSync"></div><span class="tgl-lbl">Sync</span>';
    if (b.shapeTempoSync) {
        var divs = [{ v: '4/1', label: '4 Bars' }, { v: '2/1', label: '2 Bars' }].concat(BEAT_DIVS);
        h += renderBeatDivSelect(b.id, 'shapeSyncDiv', b.shapeSyncDiv, divs);
        h += '<div class="seg-inline" data-b="' + b.id + '" data-f="clockSource"><button class="' + ((b.clockSource || 'daw') === 'daw' ? 'on' : '') + '" data-v="daw">DAW</button><button class="' + (b.clockSource === 'internal' ? 'on' : '') + '" data-v="internal">Int</button></div>';
    }
    h += '</div>';
    h += '</div></div>';

    return h;
}
// ── SHAPES RANGE: per-param range variant of Shapes ──
function renderShapesRangeBody(b) {
    var h = '';
    // ── 1. XY PAD (same as Shapes) ──
    h += '<div class="block-section"><span class="block-section-label">XY Pad</span>';
    h += '<div class="morph-pad shapes-pad" data-b="' + b.id + '">';
    h += buildShapePathSvg(b, 100); // Always max size for shapes_range
    var trackClass = 'shape-readout shape-readout-' + (b.shapeTracking || 'horizontal');
    h += '<div class="' + trackClass + '" id="shapeReadout-' + b.id + '"></div>';
    h += '<div class="playhead-dot" id="shapeHead-' + b.id + '" style="left:50%;top:50%"></div>';
    h += '</div></div>';

    // ── 2. POLARITY (no abs/rel — always relative) ──
    h += '<div class="block-section"><span class="block-section-label">Polarity</span>';
    h += '<div class="seg" data-b="' + b.id + '" data-f="shapePolarity"><button class="' + ((b.shapePolarity || 'bipolar') === 'bipolar' ? 'on' : '') + '" data-v="bipolar">\u2195 Bipolar</button><button class="' + (b.shapePolarity === 'unipolar' ? 'on' : '') + '" data-v="unipolar">\u2197 Unipolar (Drag Direction)</button></div>';
    h += '</div>';

    // ── 3. PER-PARAM RANGES list ──
    h += '<div class="block-section"><span class="block-section-label">Per-Param Ranges</span>';
    h += '<div class="constraints-box sr-ranges" data-b="' + b.id + '">';
    var rangeCount = 0;
    if (b.targetRanges) {
        var tArr = Array.from(b.targets);
        for (var ri = 0; ri < tArr.length; ri++) {
            var pid = tArr[ri], p = PMap[pid];
            if (!p) continue;
            var range = b.targetRanges[pid] !== undefined ? b.targetRanges[pid] : 0;
            rangeCount++;
            var pct = Math.round(range * 100);
            var sign = pct > 0 ? '+' : '';
            var base = b.targetRangeBases && b.targetRangeBases[pid] !== undefined ? b.targetRangeBases[pid] : p.v;
            var basePct = Math.round(base * 100);
            var rangeClass = pct > 0 ? ' sr-pos' : (pct < 0 ? ' sr-neg' : '');
            h += '<div class="sr-range-row"><span class="sr-range-name">' + paramPluginName(pid) + ': ' + p.name + '</span><span class="sr-range-val' + rangeClass + '">' + sign + pct + '% @ ' + basePct + '%</span></div>';
        }
    }
    if (rangeCount === 0) h += '<div class="sr-range-empty">Click Assign, then drag knobs to set ranges</div>';
    h += '</div></div>';

    // ── 4. SHAPE & TRACKING (same as Shapes but no depth/size knobs) ──
    h += '<div class="block-section"><span class="block-section-label">Shape &amp; Tracking</span>';
    h += '<div class="constraints-box">';
    // Shape selector
    h += '<select class="sub-sel" data-b="' + b.id + '" data-f="shapeType">';
    h += '<optgroup label="Basic">';
    h += '<option value="circle"' + (b.shapeType === 'circle' ? ' selected' : '') + '>● Circle</option>';
    h += '<option value="figure8"' + (b.shapeType === 'figure8' ? ' selected' : '') + '>∞ Figure 8</option>';
    h += '<option value="sweepX"' + (b.shapeType === 'sweepX' ? ' selected' : '') + '>↔ Sweep X</option>';
    h += '<option value="sweepY"' + (b.shapeType === 'sweepY' ? ' selected' : '') + '>↕ Sweep Y</option>';
    h += '</optgroup><optgroup label="Geometry">';
    h += '<option value="triangle"' + (b.shapeType === 'triangle' ? ' selected' : '') + '>△ Triangle</option>';
    h += '<option value="square"' + (b.shapeType === 'square' ? ' selected' : '') + '>□ Square</option>';
    h += '<option value="pentagram"' + (b.shapeType === 'pentagram' ? ' selected' : '') + '>☆ Pentagram</option>';
    h += '<option value="hexagon"' + (b.shapeType === 'hexagon' ? ' selected' : '') + '>⬡ Hexagon</option>';
    h += '<option value="hexagram"' + (b.shapeType === 'hexagram' ? ' selected' : '') + '>✡ Hexagram</option>';
    h += '</optgroup><optgroup label="Curves">';
    h += '<option value="rose4"' + (b.shapeType === 'rose4' ? ' selected' : '') + '>✿ Rose</option>';
    h += '<option value="lissajous"' + (b.shapeType === 'lissajous' ? ' selected' : '') + '>∿ Lissajous</option>';
    h += '<option value="spiral"' + (b.shapeType === 'spiral' ? ' selected' : '') + '>\uD83C\uDF00 Spiral</option>';
    h += '</select>';
    // Tracking axis
    h += '<div class="seg" data-b="' + b.id + '" data-f="shapeTracking">';
    h += '<button class="' + (b.shapeTracking === 'horizontal' ? 'on' : '') + '" data-v="horizontal">Horizontal</button>';
    h += '<button class="' + (b.shapeTracking === 'vertical' ? 'on' : '') + '" data-v="vertical">Vertical</button>';
    h += '<button class="' + (b.shapeTracking === 'distance' ? 'on' : '') + '" data-v="distance">Distance</button>';
    h += '</div>';
    // Speed + Spin sliders (no Size knob — always max for shapes_range)
    var speedVal = b.shapeSpeed || 50;
    var spinVal = b.shapeSpin || 0;
    h += '<div class="sl-row' + (b.shapeTempoSync ? ' sync-disabled' : '') + '"><span class="sl-lbl">Speed</span><input type="range" min="1" max="100" value="' + speedVal + '" data-b="' + b.id + '" data-f="shapeSpeed"' + (b.shapeTempoSync ? ' disabled' : '') + '><span class="sl-val">' + speedVal + '%</span></div>';
    h += '<div class="sl-row"><span class="sl-lbl">Spin</span><input type="range" min="-100" max="100" value="' + spinVal + '" data-b="' + b.id + '" data-f="shapeSpin"><span class="sl-val">' + (spinVal > 0 ? '+' : '') + spinVal + '%</span></div>';
    // Sync toggle
    h += '<div class="behaviour-row"><div class="tgl ' + (b.shapeTempoSync ? 'on' : '') + '" data-b="' + b.id + '" data-f="shapeTempoSync"></div><span class="tgl-lbl">Sync</span>';
    if (b.shapeTempoSync) {
        var divs = [{ v: '4/1', label: '4 Bars' }, { v: '2/1', label: '2 Bars' }].concat(BEAT_DIVS);
        h += renderBeatDivSelect(b.id, 'shapeSyncDiv', b.shapeSyncDiv, divs);
        h += '<div class="seg-inline" data-b="' + b.id + '" data-f="clockSource"><button class="' + ((b.clockSource || 'daw') === 'daw' ? 'on' : '') + '" data-v="daw">DAW</button><button class="' + (b.clockSource === 'internal' ? 'on' : '') + '" data-v="internal">Int</button></div>';
    }
    h += '</div>';
    h += '</div></div>';
    return h;
}

// ════════════════════════════════════════════════════════════════
// LANE MODE — per-param automation lanes
// ════════════════════════════════════════════════════════════════
var LANE_CANVAS_H = 130; // default expanded px per lane

function ensureLanes(b) {
    // Lanes support multiple params (pids array).
    // Each assigned target can live in its own lane OR share a lane.
    if (!b.lanes) b.lanes = [];
    var tArr = Array.from(b.targets);

    // Migrate old single-pid lanes to pids array
    for (var i = 0; i < b.lanes.length; i++) {
        if (b.lanes[i].pid && !b.lanes[i].pids) {
            b.lanes[i].pids = [b.lanes[i].pid];
            delete b.lanes[i].pid;
        }
        if (!b.lanes[i].pids) b.lanes[i].pids = [];
    }

    // Build set of all PIDs in targets
    var targetSet = {};
    tArr.forEach(function (pid) { targetSet[pid] = true; });

    // Remove PIDs from lanes that are no longer in targets
    for (var i = 0; i < b.lanes.length; i++) {
        b.lanes[i].pids = b.lanes[i].pids.filter(function (pid) { return targetSet[pid]; });
    }
    // Remove empty lanes
    b.lanes = b.lanes.filter(function (l) { return l.pids.length > 0; });

    // Find PIDs not yet in any lane → create new lanes for them
    var assignedPids = {};
    b.lanes.forEach(function (l) {
        l.pids.forEach(function (pid) { assignedPids[pid] = true; });
    });
    var unassigned = tArr.filter(function (pid) { return !assignedPids[pid]; });
    for (var i = 0; i < unassigned.length; i++) {
        var pid = unassigned[i];
        var p = PMap[pid];
        var curVal = p ? p.v : 0.5;
        var yPos = 1.0 - curVal;
        b.lanes.push({
            pids: [pid],
            color: LANE_COLORS[(b.lanes.length + i) % LANE_COLORS.length],
            pts: [{ x: 0, y: yPos }, { x: 1, y: yPos }],
            loopLen: '1/1',
            freeSecs: 4,
            phase: 0,
            depth: 100,
            interp: 'smooth',
            playMode: 'forward',
            synced: true,
            muted: false,
            collapsed: false
        });
    }
}

function renderLaneBody(b) {
    ensureLanes(b);
    var h = '';

    // ── TOOLBAR ──
    h += '<div class="block-section lane-section">';
    h += '<div class="lane-toolbar">';
    // Tools
    h += '<button class="lane-tbtn' + (b.laneTool === 'draw' ? ' on' : '') + '" data-b="' + b.id + '" data-lt="draw">\u270F Draw</button>';
    h += '<button class="lane-tbtn' + (b.laneTool === 'select' ? ' on' : '') + '" data-b="' + b.id + '" data-lt="select">\u2196 Select</button>';
    h += '<button class="lane-tbtn' + (b.laneTool === 'erase' ? ' on' : '') + '" data-b="' + b.id + '" data-lt="erase">\u232B Erase</button>';
    h += '<div class="lane-tsep"></div>';
    // Grid
    h += '<span class="lane-tlbl">Grid</span>';
    h += '<div class="lane-itabs" data-b="' + b.id + '" data-f="laneGrid">';
    ['free', '1/16', '1/8', '1/4', '1/2', '1/1'].forEach(function (g) {
        h += '<button class="lane-itab' + (b.laneGrid === g ? ' on' : '') + '" data-v="' + g + '">' + (g === 'free' ? 'Free' : g) + '</button>';
    });
    h += '</div>';
    h += '<div class="lane-tsep"></div>';
    // Clear + Random
    h += '<button class="lane-tbtn" data-b="' + b.id + '" data-lt="clear">\u2298 Clear</button>';
    h += '<button class="lane-tbtn" data-b="' + b.id + '" data-lt="random">\u2684 Random</button>';
    // Right side: sync
    h += '<div class="lane-toolbar-right">';
    h += '<div class="seg-inline" data-b="' + b.id + '" data-f="clockSource"><button class="' + ((b.clockSource || 'daw') === 'daw' ? 'on' : '') + '" data-v="daw">DAW</button><button class="' + (b.clockSource === 'internal' ? 'on' : '') + '" data-v="internal">Int</button></div>';
    h += '</div>';
    h += '</div>'; // toolbar end

    // ── LANES ──
    if (b.lanes.length === 0) {
        h += '<div class="lane-empty">Assign parameters to create lanes</div>';
    } else {
        h += '<div class="lane-stack" data-b="' + b.id + '">';
        for (var li = 0; li < b.lanes.length; li++) {
            var lane = b.lanes[li];
            // Build header name from pids array
            var firstName = '', extraCount = 0;
            if (lane.pids && lane.pids.length > 0) {
                var fp = PMap[lane.pids[0]];
                firstName = fp ? (paramPluginName(lane.pids[0]) + ' / ' + fp.name) : lane.pids[0];
                extraCount = lane.pids.length - 1;
            }
            var pNameHtml = firstName + (extraCount > 0 ? ' <span class="lane-hdr-badge">+' + extraCount + '</span>' : '');
            // Lane header
            h += '<div class="lane-item" data-b="' + b.id + '" data-li="' + li + '">';
            h += '<div class="lane-hdr">';
            h += '<div class="lane-hdr-arrow" data-b="' + b.id + '" data-li="' + li + '">' + (lane.collapsed ? '\u25B6' : '\u25BC') + '</div>';
            h += '<div class="lane-hdr-color" style="background:' + lane.color + '"></div>';
            h += '<div class="lane-hdr-name">' + pNameHtml + '</div>';
            // Right controls
            h += '<div class="lane-hdr-ctrls">';
            h += '<select class="lane-hdr-sel" data-b="' + b.id + '" data-li="' + li + '" data-lf="loopLen">';
            LANE_LOOP_OPTS.forEach(function (o) {
                h += '<option value="' + o.v + '"' + (lane.loopLen === o.v ? ' selected' : '') + '>' + o.label + '</option>';
            });
            h += '</select>';
            // Free seconds input (only visible when loopLen is "free")
            if (lane.loopLen === 'free') {
                h += '<input type="number" class="lane-hdr-fsec" data-b="' + b.id + '" data-li="' + li + '" value="' + (lane.freeSecs || 4) + '" min="0.1" max="60" step="0.1" title="Loop duration in seconds">';
                h += '<span class="lane-hdr-unit">s</span>';
            }
            // Play mode selector
            h += '<select class="lane-hdr-sel lane-hdr-pm" data-b="' + b.id + '" data-li="' + li + '" data-lf="playMode" title="Playhead mode">';
            [{ v: 'forward', l: '\u25B6 Fwd' }, { v: 'reverse', l: '\u25C0 Rev' }, { v: 'pingpong', l: '\u21D4 PP' }, { v: 'random', l: '\u26A1 Rnd' }].forEach(function (m) {
                h += '<option value="' + m.v + '"' + ((lane.playMode || 'forward') === m.v ? ' selected' : '') + '>' + m.l + '</option>';
            });
            h += '</select>';
            h += '<span class="lane-hdr-depth" data-b="' + b.id + '" data-li="' + li + '" title="Depth">\u25B2 ' + (lane.depth != null ? lane.depth : 100) + '%</span>';
            h += '<span class="lane-hdr-mute' + (lane.muted ? '' : ' lit') + '" data-b="' + b.id + '" data-li="' + li + '">' + (lane.muted ? '\u25CB' : '\u25CF') + '</span>';
            h += '</div>'; // ctrls
            h += '</div>'; // hdr

            // Lane body (canvas + sidebars)
            if (!lane.collapsed) {
                h += '<div class="lane-body" data-b="' + b.id + '" data-li="' + li + '" style="height:' + LANE_CANVAS_H + 'px">';
                // Left sidebar — assigned params list
                h += '<div class="lane-lb-left">';
                h += '<span class="lane-rb-label">PARAMS</span>';
                h += '<div class="lane-param-list">';
                for (var pi = 0; pi < lane.pids.length; pi++) {
                    var pp = PMap[lane.pids[pi]];
                    var shortName = pp ? pp.name : lane.pids[pi];
                    if (shortName.length > 8) shortName = shortName.substring(0, 7) + '\u2026';
                    h += '<div class="lane-param-chip" title="' + (pp ? pp.name : lane.pids[pi]) + '">';
                    h += '<span class="lane-param-chip-name">' + shortName + '</span>';
                    h += '<span class="lane-param-chip-x" data-b="' + b.id + '" data-li="' + li + '" data-pid="' + lane.pids[pi] + '">\u00D7</span>';
                    h += '</div>';
                }
                h += '</div>';
                h += '<button class="lane-add-param-btn" data-b="' + b.id + '" data-li="' + li + '" title="Add parameter to this lane">+ Add</button>';
                h += '</div>'; // lb-left
                // Canvas
                h += '<div class="lane-canvas-wrap" id="lcw-' + b.id + '-' + li + '">';
                h += '<canvas class="lane-canvas" id="lcv-' + b.id + '-' + li + '"></canvas>';
                h += '<div class="lane-playhead" id="lph-' + b.id + '-' + li + '"></div>';
                h += '<div class="lane-val-indicator" id="lvi-' + b.id + '-' + li + '"></div>';
                h += '</div>';
                // Right sidebar — interp + sync
                h += '<div class="lane-lb-right">';
                h += '<span class="lane-rb-label">INTERP</span>';
                h += '<div class="lane-interp-stack">';
                h += '<button class="lane-ibtn' + (lane.interp === 'smooth' ? ' on' : '') + '" data-b="' + b.id + '" data-li="' + li + '" data-linterp="smooth">Smooth</button>';
                h += '<button class="lane-ibtn' + (lane.interp === 'step' ? ' on' : '') + '" data-b="' + b.id + '" data-li="' + li + '" data-linterp="step">Step</button>';
                h += '<button class="lane-ibtn' + (lane.interp === 'linear' ? ' on' : '') + '" data-b="' + b.id + '" data-li="' + li + '" data-linterp="linear">Linear</button>';
                h += '</div>';
                h += '<span class="lane-rb-label" style="margin-top:4px">SYNC</span>';
                h += '<button class="lane-sync-pill' + (lane.synced ? ' on' : '') + '" data-b="' + b.id + '" data-li="' + li + '">' + (lane.synced ? 'Host' : 'Int') + '</button>';
                h += '</div>'; // lb-right
                h += '</div>'; // lane-body

                // Lane footer — compact text controls + action buttons
                h += '<div class="lane-footer" data-b="' + b.id + '" data-li="' + li + '">';
                var depthVal = lane.depth != null ? lane.depth : 100;
                var slewVal = lane.slew || 0;
                var warpVal = lane.warp || 0;
                h += '<span class="lane-ft-knob" data-b="' + b.id + '" data-li="' + li + '" data-lk="depth" title="Depth — drag vertical to adjust">Depth ' + depthVal + '%</span>';
                h += '<span class="lane-ft-knob" data-b="' + b.id + '" data-li="' + li + '" data-lk="slew" title="Slew — drag vertical to adjust">Slew ' + (slewVal >= 0 ? '+' : '') + slewVal + '</span>';
                h += '<span class="lane-ft-knob" data-b="' + b.id + '" data-li="' + li + '" data-lk="warp" title="Warp — drag vertical to adjust">Warp ' + (warpVal >= 0 ? '+' : '') + warpVal + '</span>';
                h += '<div class="lane-ft-spacer"></div>';
                // Action buttons
                h += '<button class="lane-ft-btn" data-b="' + b.id + '" data-li="' + li + '" data-act="clear" title="Clear this lane">\u2298 Clear</button>';
                h += '<button class="lane-ft-btn" data-b="' + b.id + '" data-li="' + li + '" data-act="random" title="Randomize this lane">\u2684 Random</button>';
                h += '<button class="lane-ft-btn" data-b="' + b.id + '" data-li="' + li + '" data-act="invert" title="Invert curve vertically">\u2195 Invert</button>';
                h += '<div class="lane-ft-shapes" style="position:relative;display:inline-block">';
                h += '<button class="lane-ft-btn" data-b="' + b.id + '" data-li="' + li + '" data-act="shapes" title="Preset shapes">\u223F Shape \u25BE</button>';
                h += '</div>';
                h += '</div>'; // lane-footer
            }
            h += '</div>'; // lane-item
        }
        h += '</div>'; // lane-stack
    }
    h += '</div>'; // block-section
    return h;
}

// ── Lane canvas drawing engine ──
function laneCanvasSetup(b) {
    if (!b.lanes) return;
    var dpr = window.devicePixelRatio || 1;
    for (var li = 0; li < b.lanes.length; li++) {
        var lane = b.lanes[li];
        if (lane.collapsed) continue;
        var cvs = document.getElementById('lcv-' + b.id + '-' + li);
        var wrap = document.getElementById('lcw-' + b.id + '-' + li);
        if (!cvs || !wrap) continue;
        // HiDPI: scale canvas buffer for crisp rendering
        var cssW = wrap.clientWidth || 300;
        var cssH = wrap.clientHeight || LANE_CANVAS_H;
        cvs.width = cssW * dpr;
        cvs.height = cssH * dpr;
        cvs.style.width = cssW + 'px';
        cvs.style.height = cssH + 'px';
        var ctx = cvs.getContext('2d');
        ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
        laneDrawCanvas(b, li);
        laneSetupMouse(b, li);
        laneSetupFooter(b, li);
    }
}

// Setup footer knob drag + button handlers for a lane
function laneSetupFooter(b, li) {
    var lane = b.lanes[li];
    if (!lane || lane.collapsed) return;

    // Default values if missing
    if (lane.depth == null) lane.depth = 100;
    if (lane.slew == null) lane.slew = 0;
    if (lane.warp == null) lane.warp = 0;

    // Lane footer knob drag handlers (using standard .bk with data-li)
    document.querySelectorAll('.lane-footer[data-b="' + b.id + '"][data-li="' + li + '"] .bk').forEach(function (knob) {
        var field = knob.dataset.f;
        var mn = parseFloat(knob.dataset.min), mx = parseFloat(knob.dataset.max);
        knob.onmousedown = function (e) {
            e.preventDefault(); e.stopPropagation();
            var startY = e.clientY, startVal = lane[field] != null ? lane[field] : mn;
            document.onmousemove = function (ev) {
                var dy = startY - ev.clientY;
                var newVal = Math.max(mn, Math.min(mx, startVal + dy * 0.5));
                lane[field] = Math.round(newVal);
                // Rebuild knob SVG
                knob.querySelector('.bk-svg').innerHTML = buildBlockKnob(lane[field], mn, mx, 28, 'lane', field, b.id, '', '%', null, false, li).match(/<svg[\s\S]*<\/svg>/)[0];
                var valEl = knob.querySelector('.bk-val');
                if (valEl) valEl.textContent = Math.round(lane[field]) + '%';
                laneDrawCanvas(b, li);
            };
            document.onmouseup = function () {
                document.onmousemove = null;
                document.onmouseup = null;
                syncBlocksToHost();
            };
        };
    });

    // Footer action buttons
    document.querySelectorAll('.lane-ft-btn[data-b="' + b.id + '"][data-li="' + li + '"]').forEach(function (btn) {
        btn.onclick = function (e) {
            e.stopPropagation();
            var act = btn.dataset.act;
            if (act === 'random') {
                laneRandomize(lane, b.laneGrid);
                if (lane._sel) lane._sel.clear();
                laneDrawCanvas(b, li);
                syncBlocksToHost();
            } else if (act === 'invert') {
                for (var i = 0; i < lane.pts.length; i++) {
                    lane.pts[i].y = 1 - lane.pts[i].y;
                }
                laneDrawCanvas(b, li);
                syncBlocksToHost();
            } else if (act === 'clear') {
                var edgeY = (lane.pts.length && lane.pts[0]) ? lane.pts[0].y : 0.5;
                lane.pts = [{ x: 0, y: 0.5 }, { x: 1, y: 0.5 }];
                if (lane._sel) lane._sel.clear();
                laneDrawCanvas(b, li);
                syncBlocksToHost();
            } else if (act === 'shapes') {
                laneShowShapesMenu(b, li, btn);
            }
        };
    });
}

// ── Preset shapes menu ──
// Each shape defines minimal control points directly (y: 0=bottom, 1=top in canvas coords inverted below)
var LANE_SHAPES = [
    {
        name: 'Sine', pts: function () {
            var p = []; for (var i = 0; i <= 16; i++) { var t = i / 16; p.push({ x: t, y: 0.5 + 0.5 * Math.sin(t * Math.PI * 2 - Math.PI / 2) }); } return p;
        }
    },
    {
        name: 'Cosine', pts: function () {
            var p = []; for (var i = 0; i <= 16; i++) { var t = i / 16; p.push({ x: t, y: 0.5 + 0.5 * Math.cos(t * Math.PI * 2) }); } return p;
        }
    },
    {
        name: 'Triangle', pts: function () {
            return [{ x: 0, y: 0 }, { x: 0.25, y: 1 }, { x: 0.75, y: 0 }, { x: 1, y: 0 }];
        }
    },
    {
        name: 'Saw Up', pts: function () {
            return [{ x: 0, y: 0 }, { x: 1, y: 1 }];
        }
    },
    {
        name: 'Saw Down', pts: function () {
            return [{ x: 0, y: 1 }, { x: 1, y: 0 }];
        }
    },
    {
        name: 'Square', pts: function () {
            return [{ x: 0, y: 1 }, { x: 0.499, y: 1 }, { x: 0.5, y: 0 }, { x: 0.999, y: 0 }, { x: 1, y: 1 }];
        }
    },
    {
        name: 'Stairs Up', pts: function () {
            return [{ x: 0, y: 0 }, { x: 0.249, y: 0 }, { x: 0.25, y: 0.33 }, { x: 0.499, y: 0.33 },
            { x: 0.5, y: 0.66 }, { x: 0.749, y: 0.66 }, { x: 0.75, y: 1 }, { x: 1, y: 1 }];
        }
    },
    {
        name: 'Stairs Down', pts: function () {
            return [{ x: 0, y: 1 }, { x: 0.249, y: 1 }, { x: 0.25, y: 0.66 }, { x: 0.499, y: 0.66 },
            { x: 0.5, y: 0.33 }, { x: 0.749, y: 0.33 }, { x: 0.75, y: 0 }, { x: 1, y: 0 }];
        }
    },
    {
        name: 'Exp Rise', pts: function () {
            var p = []; for (var i = 0; i <= 8; i++) { var t = i / 8; p.push({ x: t, y: Math.pow(t, 2.5) }); } return p;
        }
    },
    {
        name: 'Exp Decay', pts: function () {
            var p = []; for (var i = 0; i <= 8; i++) { var t = i / 8; p.push({ x: t, y: Math.pow(1 - t, 2.5) }); } return p;
        }
    },
    {
        name: 'S-Curve', pts: function () {
            var p = []; for (var i = 0; i <= 10; i++) { var t = i / 10; var s = t * 2 - 1; p.push({ x: t, y: 0.5 + 0.5 * Math.tanh(s * 3) / Math.tanh(3) }); } return p;
        }
    },
    {
        name: 'Pulse', pts: function () {
            return [{ x: 0, y: 0 }, { x: 0.15, y: 0 }, { x: 0.151, y: 1 }, { x: 0.35, y: 1 }, { x: 0.351, y: 0 },
            { x: 0.65, y: 0 }, { x: 0.651, y: 1 }, { x: 0.85, y: 1 }, { x: 0.851, y: 0 }, { x: 1, y: 0 }];
        }
    }
];

function laneShowShapesMenu(b, li, anchorBtn) {
    // Remove any existing shapes menu
    var old = document.querySelector('.lane-shapes-menu');
    if (old) { old.remove(); return; }

    var lane = b.lanes[li];
    var gridDiv = { 'free': 32, '1/16': 16, '1/8': 8, '1/4': 4, '1/2': 2, '1/1': 1 };
    var divs = gridDiv[b.laneGrid] || 8;
    var numPts = Math.max(divs * 2, 16); // enough points for smooth shapes

    var menu = document.createElement('div');
    menu.className = 'lane-shapes-menu lane-add-menu';
    menu.style.position = 'absolute';
    menu.style.bottom = '100%';
    menu.style.right = '0';
    menu.style.zIndex = '200';
    menu.style.marginBottom = '2px';
    menu.style.minWidth = '120px';

    LANE_SHAPES.forEach(function (shape) {
        var item = document.createElement('div');
        item.className = 'lane-add-menu-item';
        item.textContent = shape.name;
        item.onclick = function (e) {
            e.stopPropagation();
            // Invert y (canvas 0=top) and clone points
            var raw = shape.pts();
            lane.pts = raw.map(function (p) { return { x: p.x, y: 1 - p.y }; });
            if (lane._sel) lane._sel.clear();
            laneDrawCanvas(b, li);
            syncBlocksToHost();
            menu.remove();
        };
        menu.appendChild(item);
    });

    // Position relative to the shapes button wrapper
    var wrapper = anchorBtn.closest('.lane-ft-shapes') || anchorBtn.parentElement;
    wrapper.appendChild(menu);

    // Close on outside click
    setTimeout(function () {
        document.addEventListener('mousedown', function closer(ev) {
            if (!menu.contains(ev.target)) {
                menu.remove();
                document.removeEventListener('mousedown', closer);
            }
        });
    }, 10);
}
function laneDrawCanvas(b, li, selSet) {
    var lane = b.lanes[li];
    var cvs = document.getElementById('lcv-' + b.id + '-' + li);
    if (!cvs || !lane) return;
    var ctx = cvs.getContext('2d');
    // Use CSS dimensions for drawing (HiDPI transform already applied)
    var dpr = window.devicePixelRatio || 1;
    var W = cvs.width / dpr, H = cvs.height / dpr;
    ctx.save();
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, W, H);

    // Read theme colors for canvas drawing
    var cs = getComputedStyle(document.documentElement);
    var gridColor = cs.getPropertyValue('--lane-grid').trim() || 'rgba(255,255,255,0.08)';
    var gridLabel = cs.getPropertyValue('--lane-grid-label').trim() || 'rgba(255,255,255,0.15)';

    // ── Grid: bar/beat structure ──
    var gridDiv = { 'free': 16, '1/16': 16, '1/8': 8, '1/4': 4, '1/2': 2, '1/1': 1 };
    var divs = gridDiv[b.laneGrid] || 8;
    ctx.lineWidth = 1;

    // Horizontal percentage lines (0%, 25%, 50%, 75%, 100%)
    var percLabels = ['100%', '75%', '50%', '25%', '0%'];
    ctx.font = '8px Inter, sans-serif';
    ctx.textAlign = 'left';
    ctx.textBaseline = 'middle';
    for (var yi = 0; yi <= 4; yi++) {
        var yp = yi / 4;
        var yy = yp * H;
        ctx.beginPath(); ctx.moveTo(0, yy); ctx.lineTo(W, yy);
        ctx.strokeStyle = gridColor;
        if (yp === 0.5) ctx.globalAlpha = 1.0;
        else if (yp === 0 || yp === 1) ctx.globalAlpha = 0.9;
        else ctx.globalAlpha = 0.7;
        ctx.stroke();
        ctx.globalAlpha = 1.0;
        // Percentage labels on left edge
        ctx.fillStyle = gridLabel;
        ctx.globalAlpha = 1.0;
        ctx.fillText(percLabels[yi], 2, yy + (yi === 0 ? 6 : yi === 4 ? -4 : 0));
    }

    // Vertical beat/bar grid lines
    var beatsPerLoop = divs;
    for (var i = 0; i <= divs; i++) {
        var x = (i / divs) * W;
        ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H);
        var isBoundary = (i === 0 || i === divs);
        var isBar = (divs >= 4 && i % 4 === 0) || divs <= 2;
        ctx.strokeStyle = gridColor;
        if (isBoundary) {
            ctx.globalAlpha = 1.0;
            ctx.lineWidth = 1.5;
        } else if (isBar) {
            ctx.globalAlpha = 0.9;
            ctx.lineWidth = 1;
        } else {
            ctx.globalAlpha = 0.6;
            ctx.lineWidth = 0.5;
        }
        ctx.stroke();
        ctx.globalAlpha = 1.0;
        ctx.lineWidth = 1;
        // Beat number labels at top
        if (i < divs && divs <= 16) {
            ctx.fillStyle = gridLabel;
            ctx.textAlign = 'left';
            ctx.font = '7px Inter, sans-serif';
            ctx.fillText(String(i + 1), x + 2, 8);
        }
    }

    var pts = lane.pts;
    if (!pts || !pts.length) {
        ctx.fillStyle = gridLabel;
        ctx.font = '10px Inter, sans-serif';
        ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillText('draw to shape automation curve', W / 2, H / 2);
        ctx.restore();
        return;
    }

    var depth = (lane.depth != null ? lane.depth : 100) / 100;
    var warp = (lane.warp || 0) / 50; // -1..+1 range (from -50..+50)
    var slew = (lane.slew || 0) / 50; // -1..+1 range (from -50..+50)
    var col = lane.color;
    var r = parseInt(col.slice(1, 3), 16), g = parseInt(col.slice(3, 5), 16), bl = parseInt(col.slice(5, 7), 16);
    var hasEffect = (depth < 1.0 || Math.abs(warp) > 0.001 || Math.abs(slew) > 0.001);

    // Center line reference when effects active
    if (hasEffect) {
        var midY = H * 0.5;
        ctx.beginPath();
        ctx.moveTo(0, midY); ctx.lineTo(W, midY);
        ctx.strokeStyle = 'rgba(' + r + ',' + g + ',' + bl + ', 0.4)';
        ctx.lineWidth = 1.5;
        ctx.setLineDash([6, 4]);
        ctx.stroke();
        ctx.setLineDash([]);
        ctx.lineWidth = 1;
    }

    // Evaluate raw curve y at any x (with wrapping)
    function evalRawY(xPos) {
        var sx = xPos - Math.floor(xPos);
        if (pts.length <= 1) return pts[0].y;
        if (sx <= pts[0].x) return pts[0].y;
        if (sx >= pts[pts.length - 1].x) return pts[pts.length - 1].y;
        for (var seg = 0; seg < pts.length - 1; seg++) {
            if (sx >= pts[seg].x && sx < pts[seg + 1].x) {
                var x0 = pts[seg].x, x1 = pts[seg + 1].x;
                var y0 = pts[seg].y, y1 = pts[seg + 1].y;
                var t = (x1 > x0) ? (sx - x0) / (x1 - x0) : 0;
                if (lane.interp === 'step') return y0;
                if (lane.interp === 'smooth') { var ts = t * t * (3 - 2 * t); return y0 + (y1 - y0) * ts; }
                return y0 + (y1 - y0) * t;
            }
        }
        return pts[pts.length - 1].y;
    }

    // Apply depth + warp to a y value
    function processY(y) {
        var v = 0.5 + (y - 0.5) * depth; // Depth: scale toward center
        // Warp: S-curve contrast (tanh waveshaping), bipolar
        if (Math.abs(warp) > 0.001) {
            var centered = (v - 0.5) * 2; // -1..+1
            if (warp > 0) {
                // Positive warp: compress (S-curve via tanh)
                var k = 1 + warp * 8;
                var shaped = Math.tanh(centered * k) / Math.tanh(k);
                v = shaped * 0.5 + 0.5;
            } else {
                // Negative warp: expand (inverse S-curve — push extremes)
                var aw = Math.abs(warp);
                var sign = centered >= 0 ? 1 : -1;
                var ac = Math.abs(centered);
                var expanded = Math.pow(ac, 1 / (1 + aw * 3)) * sign;
                v = expanded * 0.5 + 0.5;
            }
        }
        return Math.max(0, Math.min(1, v));
    }

    // Build processed curve (resampled polyline)
    var processedPts;
    if (hasEffect) {
        var STEPS = 128;
        processedPts = [];
        for (var si = 0; si <= STEPS; si++) {
            var sx = si / STEPS;
            var rawY = evalRawY(sx);
            var py = processY(rawY);
            processedPts.push({ x: sx, y: py });
        }
        // Slew = horizontal phase shift: + shifts right, - shifts left
        var slewAmt = Math.abs(slew);
        if (slewAmt > 0.001) {
            var shiftSteps = slew * STEPS * 0.3; // shift by up to 30% of the loop
            var shifted = [];
            for (var fi = 0; fi < processedPts.length; fi++) {
                var srcIdx = fi - shiftSteps;
                // Clamp to edges (hold first/last value)
                if (srcIdx <= 0) {
                    shifted.push({ x: processedPts[fi].x, y: processedPts[0].y });
                } else if (srcIdx >= processedPts.length - 1) {
                    shifted.push({ x: processedPts[fi].x, y: processedPts[processedPts.length - 1].y });
                } else {
                    // Linear interpolation between samples
                    var lo = Math.floor(srcIdx), hi = Math.ceil(srcIdx);
                    var frac = srcIdx - lo;
                    var yInterp = processedPts[lo].y * (1 - frac) + processedPts[hi].y * frac;
                    shifted.push({ x: processedPts[fi].x, y: yInterp });
                }
            }
            processedPts = shifted;
        }
    }

    // Filled shape
    var drawPts = processedPts || pts;
    ctx.beginPath();
    ctx.moveTo(drawPts[0].x * W, H);
    ctx.lineTo(drawPts[0].x * W, drawPts[0].y * H);
    if (processedPts) {
        for (var di = 1; di < drawPts.length; di++) ctx.lineTo(drawPts[di].x * W, drawPts[di].y * H);
    } else {
        laneTracePath(ctx, drawPts, W, H, lane.interp);
    }
    ctx.lineTo(drawPts[drawPts.length - 1].x * W, H);
    ctx.closePath();
    var grd = ctx.createLinearGradient(0, 0, 0, H);
    grd.addColorStop(0, 'rgba(' + r + ',' + g + ',' + bl + ',0.18)');
    grd.addColorStop(1, 'rgba(' + r + ',' + g + ',' + bl + ',0.02)');
    ctx.fillStyle = grd;
    ctx.fill();

    // Ghost of raw shape
    if (hasEffect) {
        ctx.beginPath();
        ctx.moveTo(pts[0].x * W, pts[0].y * H);
        laneTracePath(ctx, pts, W, H, lane.interp);
        ctx.strokeStyle = 'rgba(' + r + ',' + g + ',' + bl + ',0.2)';
        ctx.lineWidth = 1;
        ctx.setLineDash([2, 3]);
        ctx.stroke();
        ctx.setLineDash([]);
    }

    // Main stroke (processed curve)
    ctx.beginPath();
    if (processedPts) {
        ctx.moveTo(processedPts[0].x * W, processedPts[0].y * H);
        for (var di = 1; di < processedPts.length; di++) ctx.lineTo(processedPts[di].x * W, processedPts[di].y * H);
    } else {
        ctx.moveTo(pts[0].x * W, pts[0].y * H);
        laneTracePath(ctx, pts, W, H, lane.interp);
    }
    ctx.strokeStyle = col;
    ctx.lineWidth = 1.5;
    ctx.lineJoin = 'round';
    ctx.stroke();


    // Breakpoints — edge points (first/last) drawn as bigger squares, others as circles
    var sel = selSet || lane._sel;
    for (var i = 0; i < pts.length; i++) {
        var isSel = sel && sel.has(i);
        var ppx = pts[i].x * W, ppy = pts[i].y * H;
        var isEdgePt = (i === 0 || i === pts.length - 1);
        if (isSel) {
            ctx.beginPath(); ctx.arc(ppx, ppy, isEdgePt ? 12 : 8, 0, Math.PI * 2);
            ctx.fillStyle = 'rgba(' + r + ',' + g + ',' + bl + ',0.18)';
            ctx.fill();
        }
        if (isEdgePt) {
            // Bigger square for edge points (loop start/end)
            var es = isSel ? 8 : 7;
            ctx.fillStyle = isSel ? '#fff' : col;
            ctx.fillRect(ppx - es, ppy - es, es * 2, es * 2);
            ctx.strokeStyle = 'rgba(255,255,255,0.5)';
            ctx.lineWidth = 1.5;
            ctx.strokeRect(ppx - es, ppy - es, es * 2, es * 2);
        } else {
            var rad = isSel ? 5 : 3;
            ctx.beginPath(); ctx.arc(ppx, ppy, rad, 0, Math.PI * 2);
            ctx.fillStyle = isSel ? '#fff' : col;
            ctx.fill();
            ctx.strokeStyle = isSel ? col : 'rgba(0,0,0,0.4)';
            ctx.lineWidth = isSel ? 1.5 : 0.8;
            ctx.stroke();
        }
    }
    ctx.restore();
}

function laneTracePath(ctx, pts, W, H, interp) {
    if (interp === 'smooth') {
        for (var i = 0; i < pts.length - 1; i++) {
            var cx = (pts[i].x * W + pts[i + 1].x * W) / 2;
            ctx.bezierCurveTo(cx, pts[i].y * H, cx, pts[i + 1].y * H, pts[i + 1].x * W, pts[i + 1].y * H);
        }
    } else if (interp === 'step') {
        for (var i = 1; i < pts.length; i++) {
            ctx.lineTo(pts[i].x * W, pts[i - 1].y * H);
            ctx.lineTo(pts[i].x * W, pts[i].y * H);
        }
    } else {
        for (var i = 1; i < pts.length; i++) ctx.lineTo(pts[i].x * W, pts[i].y * H);
    }
}

// Rubber-band overlay
function laneDrawSelRect(b, li, x0, y0, x1, y1) {
    var cvs = document.getElementById('lcv-' + b.id + '-' + li);
    if (!cvs) return;
    var ctx = cvs.getContext('2d');
    var dpr = window.devicePixelRatio || 1;
    var W = cvs.width / dpr, H = cvs.height / dpr;
    laneDrawCanvas(b, li);
    ctx.save();
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    var rx = Math.min(x0, x1) * W, ry = Math.min(y0, y1) * H;
    var rw = Math.abs(x1 - x0) * W, rh = Math.abs(y1 - y0) * H;
    ctx.strokeStyle = 'rgba(255,255,255,0.5)';
    ctx.lineWidth = 1;
    ctx.setLineDash([3, 3]);
    ctx.strokeRect(rx, ry, rw, rh);
    ctx.setLineDash([]);
    ctx.fillStyle = 'rgba(255,255,255,0.04)';
    ctx.fillRect(rx, ry, rw, rh);
    ctx.restore();
}

function laneSetupMouse(b, li) {
    var cvs = document.getElementById('lcv-' + b.id + '-' + li);
    if (!cvs) return;
    var lane = b.lanes[li];
    if (!lane) return;
    if (!lane._sel) lane._sel = new Set();
    var active = false, rafPending = false;
    var selDrag = null;

    // Edge points: first and last in the sorted array — cannot be deleted or moved horizontally
    function isEdge(idx) {
        if (!lane.pts[idx]) return false;
        return idx === 0 || idx === lane.pts.length - 1;
    }

    function posRaw(e) {
        var r = cvs.getBoundingClientRect();
        return {
            x: Math.max(0, Math.min(1, (e.clientX - r.left) / r.width)),
            y: Math.max(0, Math.min(1, (e.clientY - r.top) / r.height))
        };
    }
    function getStep() {
        if (b.laneGrid === 'free') return 0;
        var parts = b.laneGrid.split('/');
        return parts.length === 2 ? Number(parts[0]) / Number(parts[1]) : 1;
    }
    function snap(p) {
        var step = getStep();
        if (!step) return p;
        return { x: Math.max(0, Math.min(1, Math.round(p.x / step) * step)), y: p.y };
    }
    // Hard snap: lock x to nearest grid line
    function softSnap(x) {
        var step = getStep();
        if (!step) return x; // Free mode: no snap
        return Math.round(x / step) * step;
    }
    function schedDraw() {
        if (rafPending) return;
        rafPending = true;
        requestAnimationFrame(function () { rafPending = false; laneDrawCanvas(b, li); });
    }
    function findNearest(p, radius) {
        var best = -1, bestD = radius * radius;
        for (var i = 0; i < lane.pts.length; i++) {
            // Edge points (first/last) get 3x larger hit area for easy grabbing
            var r2 = isEdge(i) ? (radius * 3) * (radius * 3) : radius * radius;
            var dx = lane.pts[i].x - p.x, dy = lane.pts[i].y - p.y;
            var d = dx * dx + dy * dy;
            if (d < r2 && d < bestD) { bestD = d; best = i; }
        }
        return best;
    }

    cvs.onmousedown = function (e) {
        e.preventDefault(); e.stopPropagation();
        active = true;
        var pr = posRaw(e), ps = snap(pr);

        if (b.laneTool === 'draw') {
            // Draw mode: check if near existing dot first → grab it
            var hit = findNearest(pr, 0.02);
            if (hit >= 0) {
                // Grab this point (single-point move)
                lane._sel.clear(); lane._sel.add(hit);
                var anch = [{ idx: hit, ox: lane.pts[hit].x, oy: lane.pts[hit].y }];
                selDrag = { mode: 'grab', startX: pr.x, startY: pr.y, anchors: anch, hitIdx: hit, moved: false };
            } else {
                lanePutPt(lane, ps, getStep());
                selDrag = { mode: 'draw', lastX: ps.x };
            }
            schedDraw();
        } else if (b.laneTool === 'erase') {
            // Erase: protect edge points from erasure
            lane.pts = lane.pts.filter(function (pt, i) {
                if (isEdge(i)) return true; // never erase edge points
                return Math.abs(pt.x - pr.x) > 0.04 || Math.abs(pt.y - pr.y) > 0.15;
            });
            lane._sel.clear();
            schedDraw();
            selDrag = { mode: 'erase' };
        } else if (b.laneTool === 'select') {
            var hit = findNearest(pr, 0.02);
            if (hit >= 0) {
                if (e.ctrlKey || e.metaKey) {
                    if (lane._sel.has(hit)) lane._sel.delete(hit); else lane._sel.add(hit);
                } else if (!lane._sel.has(hit)) {
                    lane._sel.clear(); lane._sel.add(hit);
                }
                var anchors = [];
                lane._sel.forEach(function (idx) {
                    if (lane.pts[idx]) anchors.push({ idx: idx, ox: lane.pts[idx].x, oy: lane.pts[idx].y });
                });
                selDrag = { mode: 'move', startX: pr.x, startY: pr.y, anchors: anchors, moved: false };
            } else {
                if (!e.ctrlKey && !e.metaKey) lane._sel.clear();
                selDrag = { mode: 'box', x0: pr.x, y0: pr.y };
            }
            schedDraw();
        }
    };

    cvs.onmousemove = function (e) {
        if (!active || !selDrag) return;
        var pr = posRaw(e), ps = snap(pr);

        if (selDrag.mode === 'draw') {
            var minD = b.laneGrid === 'free' ? 0.004 : 0.001;
            if (Math.abs(ps.x - selDrag.lastX) >= minD) {
                lanePutPt(lane, ps, getStep());
                selDrag.lastX = ps.x;
                schedDraw();
            }
        } else if (selDrag.mode === 'grab' || selDrag.mode === 'move') {
            var dx = pr.x - selDrag.startX, dy = pr.y - selDrag.startY;
            if (Math.abs(dx) > 0.002 || Math.abs(dy) > 0.002) selDrag.moved = true;
            for (var i = 0; i < selDrag.anchors.length; i++) {
                var a = selDrag.anchors[i];
                if (lane.pts[a.idx]) {
                    if (isEdge(a.idx)) {
                        // Edge points: vertical only, x stays locked
                        lane.pts[a.idx].y = Math.max(0, Math.min(1, a.oy + dy));
                    } else {
                        var rawX = Math.max(0, Math.min(1, a.ox + dx));
                        lane.pts[a.idx].x = softSnap(rawX);
                        lane.pts[a.idx].y = Math.max(0, Math.min(1, a.oy + dy));
                    }
                }
            }
            schedDraw();
        } else if (selDrag.mode === 'erase') {
            lane.pts = lane.pts.filter(function (pt, i) {
                if (isEdge(i)) return true;
                return Math.abs(pt.x - pr.x) > 0.04 || Math.abs(pt.y - pr.y) > 0.15;
            });
            lane._sel.clear();
            schedDraw();
        } else if (selDrag.mode === 'box') {
            if (!rafPending) {
                rafPending = true;
                var x0 = selDrag.x0, y0 = selDrag.y0, x1 = pr.x, y1 = pr.y;
                requestAnimationFrame(function () {
                    rafPending = false;
                    var minX = Math.min(x0, x1), maxX = Math.max(x0, x1);
                    var minY = Math.min(y0, y1), maxY = Math.max(y0, y1);
                    lane._sel.clear();
                    for (var i = 0; i < lane.pts.length; i++) {
                        if (lane.pts[i].x >= minX && lane.pts[i].x <= maxX && lane.pts[i].y >= minY && lane.pts[i].y <= maxY) {
                            lane._sel.add(i);
                        }
                    }
                    laneDrawSelRect(b, li, x0, y0, x1, y1);
                });
            }
        }
    };

    function mouseUp() {
        if (!active) return;
        active = false;
        if (selDrag && (selDrag.mode === 'move' || selDrag.mode === 'grab') && selDrag.moved) {
            laneResortWithSel(lane);
        }
        selDrag = null;
        schedDraw();
        if (laneSetupMouse._syncTimer) cancelAnimationFrame(laneSetupMouse._syncTimer);
        laneSetupMouse._syncTimer = requestAnimationFrame(function () { laneSetupMouse._syncTimer = null; syncBlocksToHost(); });
    }
    cvs.onmouseup = mouseUp;
    cvs.onmouseleave = function (e) {
        mouseUp();
        cvs.style.cursor = 'crosshair';
    };

    // Hover cursor: indicate grabbable dots
    var hoverHandler = function (e) {
        if (active) return; // don't interfere during drag
        if (b.laneTool === 'erase') { cvs.style.cursor = 'crosshair'; return; }
        var pr = posRaw(e);
        var hit = findNearest(pr, 0.025);
        if (hit >= 0) {
            cvs.style.cursor = isEdge(hit) ? 'ns-resize' : 'grab';
        } else {
            cvs.style.cursor = 'crosshair';
        }
    };
    cvs.addEventListener('mousemove', hoverHandler);

    // Double-click: add single breakpoint
    cvs.ondblclick = function (e) {
        e.preventDefault(); e.stopPropagation();
        var ps = snap(posRaw(e));
        lanePutPt(lane, ps, getStep());
        lane._sel.clear();
        schedDraw();
    };
}
laneSetupMouse._syncTimer = null;

// Re-sort points and remap _sel indices after a move
function laneResortWithSel(lane) {
    var tagged = lane.pts.map(function (p, i) { return { x: p.x, y: p.y, wasSel: lane._sel.has(i), isEdge: (p.x < 0.01 || p.x > 0.99) }; });
    tagged.sort(function (a, bb) { return a.x - bb.x; });
    lane._sel.clear();
    lane.pts = [];
    for (var i = 0; i < tagged.length; i++) {
        var px = tagged[i].isEdge ? tagged[i].x : tagged[i].x; // edge points keep their x
        lane.pts.push({ x: px, y: tagged[i].y });
        if (tagged[i].wasSel) lane._sel.add(i);
    }
}

// Generate a random automation shape for a lane
function laneRandomize(lane, gridMode) {
    var pts = [];
    var startY = Math.random();
    var endY = Math.random();
    pts.push({ x: 0, y: startY });

    if (gridMode === 'free') {
        // Free mode: 6-12 random breakpoints
        var count = 6 + Math.floor(Math.random() * 7);
        for (var i = 0; i < count; i++) {
            var x = 0.05 + Math.random() * 0.9; // avoid edges
            pts.push({ x: x, y: Math.random() });
        }
    } else {
        // Grid mode: place breakpoints at grid positions
        var parts = gridMode.split('/');
        var step = parts.length === 2 ? Number(parts[0]) / Number(parts[1]) : 1;
        var divisions = Math.round(1 / step);
        for (var i = 1; i < divisions; i++) {
            var x = i * step;
            // Skip some positions for variety (30% chance to skip)
            if (divisions > 4 && Math.random() < 0.3) continue;
            pts.push({ x: x, y: Math.random() });
        }
    }

    pts.push({ x: 1, y: endY });
    pts.sort(function (a, bb) { return a.x - bb.x; });
    lane.pts = pts;
}

function lanePutPt(lane, pt, gridStep) {
    // Drawing near an edge point updates its y value directly
    if (pt.x < 0.02 && lane.pts.length && lane.pts[0].x < 0.01) {
        lane.pts[0].y = pt.y;
        return;
    }
    var last = lane.pts.length - 1;
    if (pt.x > 0.98 && last >= 0 && lane.pts[last].x > 0.99) {
        lane.pts[last].y = pt.y;
        return;
    }
    // Grid-aware removal: half the grid step, or 0.004 for free
    var clearRadius = gridStep ? gridStep * 0.49 : 0.004;
    // Protect edge points, remove points within the clear zone
    lane.pts = lane.pts.filter(function (p) {
        if (p.x < 0.01 || p.x > 0.99) return true; // never remove edge points
        return Math.abs(p.x - pt.x) > clearRadius;
    });
    lane.pts.push({ x: pt.x, y: pt.y });
    lane.pts.sort(function (a, bb) { return a.x - bb.x; });
}

// Global keyboard handler for lane operations
(function () {
    document.addEventListener('keydown', function (e) {
        if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA' || e.target.tagName === 'SELECT') return;
        // Find active lane block
        var ab = actId ? findBlock(actId) : null;
        if (!ab || ab.mode !== 'lane') return;

        // Delete — remove selected points
        if (e.key === 'Delete' || e.key === 'Backspace') {
            var changed = false;
            ab.lanes.forEach(function (lane, li) {
                if (!lane._sel || !lane._sel.size) return;
                lane.pts = lane.pts.filter(function (p, i) {
                    if (p.x < 0.01 || p.x > 0.99) return true; // protect edge points
                    return !lane._sel.has(i);
                });
                lane._sel.clear();
                laneDrawCanvas(ab, li);
                changed = true;
            });
            if (changed) syncBlocksToHost();
            return;
        }

        // Ctrl+D — duplicate selected points
        if ((e.ctrlKey || e.metaKey) && (e.key === 'd' || e.key === 'D')) {
            e.preventDefault();
            ab.lanes.forEach(function (lane, li) {
                if (!lane._sel || !lane._sel.size) return;
                var newPts = [];
                lane._sel.forEach(function (idx) {
                    if (lane.pts[idx]) newPts.push({ x: lane.pts[idx].x + 0.05, y: lane.pts[idx].y });
                });
                newPts.forEach(function (p) {
                    p.x = Math.min(1, p.x);
                    lanePutPt(lane, p, 0);
                });
                // Select the new points
                lane._sel.clear();
                for (var i = 0; i < lane.pts.length; i++) {
                    for (var j = 0; j < newPts.length; j++) {
                        if (Math.abs(lane.pts[i].x - newPts[j].x) < 0.003 && Math.abs(lane.pts[i].y - newPts[j].y) < 0.003) {
                            lane._sel.add(i); break;
                        }
                    }
                }
                laneDrawCanvas(ab, li);
            });
            syncBlocksToHost();
            return;
        }

        // Ctrl+A — select all points in all lanes
        if ((e.ctrlKey || e.metaKey) && (e.key === 'a' || e.key === 'A')) {
            e.preventDefault();
            ab.lanes.forEach(function (lane, li) {
                if (!lane._sel) lane._sel = new Set();
                lane._sel.clear();
                for (var i = 0; i < lane.pts.length; i++) lane._sel.add(i);
                laneDrawCanvas(ab, li);
            });
            return;
        }
    });
})();

function renderMorphBody(b) {
    var h = '';

    // ── 1. XY PAD — pad + snap chips + add/library buttons ──
    h += '<div class="block-section"><span class="block-section-label">XY Pad</span>';
    h += '<div class="morph-pad' + (!b.snapshots || !b.snapshots.length ? ' empty' : '') + '" data-b="' + b.id + '">';
    // LFO shape path visualization
    if (b.morphMode === 'auto' && b.exploreMode === 'shapes') {
        h += buildLfoPathSvg(b);
    }
    if (!b.snapshots || !b.snapshots.length) {
        h += '<div class="empty-label">Add a snapshot to begin</div>';
    } else {
        for (var si = 0; si < b.snapshots.length; si++) {
            var s = b.snapshots[si];
            h += '<div class="snap-dot" data-b="' + b.id + '" data-si="' + si + '" style="left:' + (s.x * 100) + '%;top:' + ((1 - s.y) * 100) + '%"><span class="snap-label">' + (s.name || ('S' + (si + 1))) + '</span></div>';
        }
        var playManual = (b.morphMode === 'manual') ? ' manual' : '';
        h += '<div class="playhead-dot' + playManual + '" id="morphHead-' + b.id + '" style="left:' + (b.playheadX * 100) + '%;top:' + ((1 - b.playheadY) * 100) + '%"></div>';
    }
    h += '</div>';
    // Snapshot chips + add/library buttons
    h += '<div class="snap-chips">';
    if (b.snapshots) {
        for (var si = 0; si < b.snapshots.length; si++) {
            var chipLabel = (b.snapshots[si].name || ('S' + (si + 1)));
            if (b.snapshots[si].source) chipLabel += ' <span style="opacity:0.5;font-size:8px">(' + b.snapshots[si].source + ')</span>';
            h += '<span class="snap-chip" data-b="' + b.id + '" data-si="' + si + '">' + chipLabel + '<span class="snap-del" data-b="' + b.id + '" data-si="' + si + '">&times;</span></span>';
        }
    }
    var snapDisabled = (b.snapshots && b.snapshots.length >= 12) ? ' disabled' : '';
    h += '<button class="snap-add-btn" data-b="' + b.id + '"' + snapDisabled + '>+ Snap</button>';
    var libDisabled = (b.snapshots && b.snapshots.length >= 12) ? ' disabled' : '';
    h += '<button class="snap-lib-btn" data-b="' + b.id + '"' + libDisabled + '>\u{1F4C2} Library</button>';
    h += '</div></div>';

    // ── 2. MOVEMENT — mode + explore/trigger + knobs + sync all in one inset box ──
    h += '<div class="block-section"><span class="block-section-label">Movement</span>';
    h += '<div class="constraints-box">';
    // Mode selector
    h += '<div class="seg" data-b="' + b.id + '" data-f="morphMode">';
    h += '<button class="' + (b.morphMode === 'manual' ? 'on' : '') + '" data-v="manual">Manual</button>';
    h += '<button class="' + (b.morphMode === 'auto' ? 'on' : '') + '" data-v="auto">Auto</button>';
    h += '<button class="' + (b.morphMode === 'trigger' ? 'on' : '') + '" data-v="trigger">Trigger</button>';
    h += '</div>';

    // Auto sub-panel
    if (b.morphMode === 'auto') {
        // Explore mode
        h += '<div class="seg" data-b="' + b.id + '" data-f="exploreMode">';
        h += '<button class="' + (b.exploreMode === 'wander' ? 'on' : '') + '" data-v="wander">Wander</button>';
        h += '<button class="' + (b.exploreMode === 'bounce' ? 'on' : '') + '" data-v="bounce">Bounce</button>';
        h += '<button class="' + (b.exploreMode === 'shapes' ? 'on' : '') + '" data-v="shapes">Shapes</button>';
        h += '<button class="' + (b.exploreMode === 'orbit' ? 'on' : '') + '" data-v="orbit">Orbit</button>';
        h += '<button class="' + (b.exploreMode === 'path' ? 'on' : '') + '" data-v="path">Path</button>';
        h += '</div>';
        // Shape selector (shapes explore only)
        var morphSynced = !!b.morphTempoSync;
        if (b.exploreMode === 'shapes') {
            h += '<select class="sub-sel" data-b="' + b.id + '" data-f="lfoShape">';
            h += '<optgroup label="Basic">';
            h += '<option value="circle"' + (b.lfoShape === 'circle' ? ' selected' : '') + '>○ Circle</option>';
            h += '<option value="figure8"' + (b.lfoShape === 'figure8' ? ' selected' : '') + '>∞ Figure 8</option>';
            h += '<option value="sweepX"' + (b.lfoShape === 'sweepX' ? ' selected' : '') + '>↔ Sweep X</option>';
            h += '<option value="sweepY"' + (b.lfoShape === 'sweepY' ? ' selected' : '') + '>↕ Sweep Y</option>';
            h += '</optgroup><optgroup label="Geometry">';
            h += '<option value="triangle"' + (b.lfoShape === 'triangle' ? ' selected' : '') + '>△ Triangle</option>';
            h += '<option value="square"' + (b.lfoShape === 'square' ? ' selected' : '') + '>□ Square</option>';
            h += '<option value="pentagram"' + (b.lfoShape === 'pentagram' ? ' selected' : '') + '>☆ Pentagram</option>';
            h += '<option value="hexagram"' + (b.lfoShape === 'hexagram' ? ' selected' : '') + '>✡ Hexagram</option>';
            h += '<option value="hexagon"' + (b.lfoShape === 'hexagon' ? ' selected' : '') + '>⬡ Hexagon</option>';
            h += '<option value="rose4"' + (b.lfoShape === 'rose4' ? ' selected' : '') + '>✿ Rose</option>';
            h += '<option value="lissajous"' + (b.lfoShape === 'lissajous' ? ' selected' : '') + '>∿ Lissajous</option>';
            h += '<option value="spiral"' + (b.lfoShape === 'spiral' ? ' selected' : '') + '>◎ Spiral</option>';
            h += '</optgroup></select>';
            // LFO knobs: Fig. Size, Rotate, Speed
            h += buildKnobRow(
                buildBlockKnob(b.lfoDepth != null ? b.lfoDepth : 80, 0, 100, 36, 'morph', 'lfoDepth', b.id, 'Fig. Size', '%') +
                buildBlockKnob(b.lfoRotation || 0, -100, 100, 36, 'morph', 'lfoRotation', b.id, 'Rotate', '±') +
                buildBlockKnob(b.morphSpeed, 0, 100, 36, 'morph', 'morphSpeed', b.id, 'Speed', '%', null, morphSynced)
            );
        }
        if (b.exploreMode !== 'shapes') {
            // Speed slider for non-shapes auto explore modes
            h += '<div class="sl-row' + (morphSynced ? ' sync-disabled' : '') + '"><span class="sl-lbl">Speed</span><input type="range" min="0" max="100" value="' + b.morphSpeed + '" data-b="' + b.id + '" data-f="morphSpeed"' + (morphSynced ? ' disabled' : '') + '><span class="sl-val">' + b.morphSpeed + '%</span></div>';
        }
        // Tempo Sync toggle + beat division
        h += '<div class="behaviour-row"><div class="tgl ' + (b.morphTempoSync ? 'on' : '') + '" data-b="' + b.id + '" data-f="morphTempoSync"></div><span class="tgl-lbl">Sync</span>';
        if (b.morphTempoSync) {
            h += renderBeatDivSelect(b.id, 'morphSyncDiv', b.morphSyncDiv, MORPH_DIVS);
            h += '<div class="seg-inline" data-b="' + b.id + '" data-f="clockSource"><button class="' + ((b.clockSource || 'daw') === 'daw' ? 'on' : '') + '" data-v="daw">DAW</button><button class="' + (b.clockSource === 'internal' ? 'on' : '') + '" data-v="internal">Int</button></div>';
        }
        h += '</div>';
    }

    // Trigger sub-panel
    if (b.morphMode === 'trigger') {
        h += '<div class="behaviour-row"><span class="blbl">Action</span><div class="seg-inline" data-b="' + b.id + '" data-f="morphAction">';
        h += '<button class="' + (b.morphAction === 'jump' ? 'on' : '') + '" data-v="jump">Jump</button>';
        h += '<button class="' + (b.morphAction === 'step' ? 'on' : '') + '" data-v="step">Step</button>';
        h += '</div>';
        if (b.morphAction === 'step') {
            h += '<div class="seg-inline" data-b="' + b.id + '" data-f="stepOrder">';
            h += '<button class="' + (b.stepOrder === 'cycle' ? 'on' : '') + '" data-v="cycle">Cycle</button>';
            h += '<button class="' + (b.stepOrder === 'random' ? 'on' : '') + '" data-v="random">Rand</button>';
            h += '</div>';
        }
        h += '</div>';
        h += '<div class="behaviour-row"><span class="blbl">Source</span><div class="seg-inline" data-b="' + b.id + '" data-f="morphSource">';
        h += '<button class="' + (b.morphSource === 'midi' ? 'on' : '') + '" data-v="midi">MIDI</button>';
        h += '<button class="' + (b.morphSource === 'tempo' ? 'on' : '') + '" data-v="tempo">Tempo</button>';
        h += '<button class="' + (b.morphSource === 'audio' ? 'on' : '') + '" data-v="audio">Audio</button>';
        h += '</div></div>';
        // Source sub-options
        if (b.morphSource === 'tempo') {
            h += '<div class="sub-row"><span class="sub-lbl">Div</span>' + renderBeatDivSelect(b.id, 'beatDiv', b.beatDiv) + '</div>';
        } else if (b.morphSource === 'midi') {
            h += '<div class="sub-row"><span class="sub-lbl">Mode</span><select class="sub-sel" data-b="' + b.id + '" data-f="midiMode">';
            h += '<option value="any_note"' + (b.midiMode === 'any_note' ? ' selected' : '') + '>Any Note</option>';
            h += '<option value="specific_note"' + (b.midiMode === 'specific_note' ? ' selected' : '') + '>Note</option>';
            h += '<option value="cc"' + (b.midiMode === 'cc' ? ' selected' : '') + '>CC</option></select>';
            if (b.midiMode === 'specific_note') h += '<input class="sub-input" type="number" min="0" max="127" value="' + b.midiNote + '" data-b="' + b.id + '" data-f="midiNote">';
            if (b.midiMode === 'cc') h += '<input class="sub-input" type="number" min="0" max="127" value="' + b.midiCC + '" data-b="' + b.id + '" data-f="midiCC">';
            h += '<span class="sub-lbl">Ch</span><select class="sub-sel" data-b="' + b.id + '" data-f="midiCh"><option value="0"' + (b.midiCh == 0 ? ' selected' : '') + '>Any</option>';
            for (var c = 1; c <= 16; c++)h += '<option value="' + c + '"' + (parseInt(b.midiCh) === c ? ' selected' : '') + '>' + c + '</option>';
            h += '</select></div>';
        } else if (b.morphSource === 'audio') {
            h += '<div class="sub-row"><span class="sub-lbl">Src</span><select class="sub-sel" data-b="' + b.id + '" data-f="audioSrc">';
            h += '<option value="main"' + (b.audioSrc === 'main' ? ' selected' : '') + '>Main</option>';
            h += '<option value="sidechain"' + (b.audioSrc === 'sidechain' ? ' selected' : '') + '>SC</option></select>';
            h += '<span class="sub-lbl">Thr</span><input class="sub-input" type="number" min="-60" max="0" value="' + b.threshold + '" data-b="' + b.id + '" data-f="threshold"><span class="sub-lbl">dB</span></div>';
        }
    }
    h += '</div></div>';

    // ── 3. MODIFIERS — two columns: movement (jitter+glide) | snapshots (radius) ──
    h += '<div class="block-section"><span class="block-section-label">Modifiers</span>';
    h += '<div class="constraints-box"><div class="mod-columns">';
    // Left: Movement modifiers
    h += '<div class="mod-col">';
    h += buildKnobRow(
        buildBlockKnob(b.jitter, 0, 100, 36, 'morph', 'jitter', b.id, 'Jitter', '%') +
        buildBlockKnob(b.morphGlide, 1, 2000, 36, 'morph', 'morphGlide', b.id, 'Glide', 'ms')
    );
    h += '</div>';
    // Divider
    h += '<div class="mod-divider"></div>';
    // Right: Snapshot radius
    h += '<div class="mod-col">';
    h += buildKnobRow(
        buildBlockKnob(b.snapRadius || 100, 5, 100, 36, 'morph', 'snapRadius', b.id, 'Radius', '%')
    );
    h += '</div>';
    h += '</div></div></div>';

    return h;
}

function wireBlocks() {
    var syncTimer = null;
    function debouncedSync() { if (syncTimer) cancelAnimationFrame(syncTimer); syncTimer = requestAnimationFrame(function () { syncTimer = null; syncBlocksToHost(); }); }
    document.querySelectorAll('.lbody').forEach(function (b) { b.onclick = function (e) { e.stopPropagation(); }; });
    document.querySelectorAll('.lhead').forEach(function (h) { h.onclick = function (e) { if (e.target.closest('.assign-btn') || e.target.closest('.lclose') || e.target.closest('[data-pwr]')) return; var id = parseInt(h.dataset.id); var b = findBlock(id); if (b) { b.expanded = !b.expanded; renderSingleBlock(id); } }; });
    document.querySelectorAll('.assign-btn').forEach(function (btn) { btn.onclick = function (e) { e.stopPropagation(); var id = parseInt(btn.dataset.id); if (assignMode === id) assignMode = null; else { assignMode = id; actId = id; var b = findBlock(id); if (b && !b.expanded) b.expanded = true; } renderBlocks(); renderAllPlugins(); }; });
    document.querySelectorAll('.lclose').forEach(function (btn) { btn.onclick = function (e) { e.stopPropagation(); var id = parseInt(btn.dataset.id); pushUndoSnapshot(); blocks = blocks.filter(function (b) { return b.id !== id; }); if (actId === id) actId = blocks.length ? blocks[0].id : null; if (assignMode === id) assignMode = null; renderBlocks(); renderAllPlugins(); updCounts(); syncBlocksToHost(); }; });
    document.querySelectorAll('[data-pwr]').forEach(function (btn) { btn.onclick = function (e) { e.stopPropagation(); var bId = parseInt(btn.dataset.pwr); var b = findBlock(bId); if (b) { b.enabled = !b.enabled; renderSingleBlock(bId); syncBlocksToHost(); } }; });
    document.querySelectorAll('.seg,.seg-inline').forEach(function (seg) { seg.querySelectorAll('button').forEach(function (btn) { btn.onclick = function (e) { e.stopPropagation(); var bId = parseInt(seg.dataset.b); var b = findBlock(bId); if (b) { b[seg.dataset.f] = btn.dataset.v; renderSingleBlock(bId); if (assignMode === bId && b.mode === 'shapes_range') renderAllPlugins(); syncBlocksToHost(); } }; }); });
    document.querySelectorAll('.tgl').forEach(function (t) { t.onclick = function (e) { e.stopPropagation(); var bId = parseInt(t.dataset.b); var b = findBlock(bId); if (b) { b[t.dataset.f] = !b[t.dataset.f]; renderSingleBlock(bId); syncBlocksToHost(); } }; });
    document.querySelectorAll('.sub-sel').forEach(function (s) { s.onchange = function () { var bId = parseInt(s.dataset.b); var b = findBlock(bId); if (b) { var val = s.value; if (s.dataset.f === 'midiCh') val = parseInt(val) || 0; b[s.dataset.f] = val; renderSingleBlock(bId); syncBlocksToHost(); } }; });
    // Default values for double-click reset
    var knobDefaults = { rMin: 0, rMax: 100, threshold: -12, glideMs: 200, envAtk: 10, envRel: 100, envSens: 50, morphSpeed: 50, morphGlide: 200, jitter: 0, snapRadius: 100, lfoDepth: 80, lfoRotation: 0, sampleSpeedPct: 100, qSteps: 12, shapeSize: 80, shapeSpin: 0, shapeSpeed: 50, shapeDepth: 50 };
    document.querySelectorAll('.lbody input[type="range"]').forEach(function (sl) {
        if (!sl.dataset.b) return;
        // Capture state before slider drag for undo
        var _sliderUndoSnap = null;
        var _sliderStartVal = null;
        sl.addEventListener('mousedown', function () {
            var b = findBlock(parseInt(sl.dataset.b));
            if (!b) return;
            _sliderUndoSnap = captureFullSnapshot();
            var f = sl.dataset.f;
            _sliderStartVal = (f === 'sampleSpeedPct') ? (b.sampleSpeed * 100) : (b[f] != null ? b[f] : parseFloat(sl.value));
        });
        sl.addEventListener('change', function () {
            var b = findBlock(parseInt(sl.dataset.b));
            if (!b || !_sliderUndoSnap) return;
            var f = sl.dataset.f;
            var curVal = (f === 'sampleSpeedPct') ? (b.sampleSpeed * 100) : b[f];
            if (_sliderStartVal !== null && curVal !== _sliderStartVal) {
                undoStack.push({ type: 'full', snapshot: _sliderUndoSnap });
                if (undoStack.length > maxUndo) undoStack.shift();
                redoStack = [];
                updateUndoBadge();
            }
            _sliderUndoSnap = null; _sliderStartVal = null;
        });
        // Continuous update while dragging
        sl.oninput = function () { var b = findBlock(parseInt(sl.dataset.b)); if (!b) return; var f = sl.dataset.f; if (f === 'sampleSpeedPct') { b.sampleSpeed = parseFloat(sl.value) / 100; } else { b[f] = parseFloat(sl.value); } var row = sl.closest('.sl-row,.sub-row'); if (row) { var v = row.querySelector('.sl-val'); if (v) { if (f === 'threshold') v.textContent = sl.value + ' dB'; else if (f === 'glideMs' || f === 'envAtk' || f === 'envRel' || f === 'morphGlide') v.textContent = sl.value + 'ms'; else if (f === 'sampleSpeedPct') v.textContent = b.sampleSpeed.toFixed(1) + 'x'; else if (f === 'morphSpeed') v.textContent = morphSpeedDisplay(parseFloat(sl.value)); else if (f === 'lfoRotation' || f === 'shapeSpin') { var rv = parseInt(sl.value); v.textContent = (rv > 0 ? '+' : '') + rv + '%'; } else if (f === 'shapeDepth') v.textContent = '±' + sl.value + '%'; else v.textContent = sl.value + '%'; } } if (f === 'lfoDepth' || f === 'lfoRotation') { var pad = document.querySelector('.morph-pad[data-b="' + sl.dataset.b + '"]:not(.shapes-pad)'); if (pad) { var old = pad.querySelector('.lfo-path-svg'); if (old) old.remove(); pad.insertAdjacentHTML('afterbegin', buildLfoPathSvg(b)); } } if (f === 'shapeSize') { var pad = document.querySelector('.shapes-pad[data-b="' + sl.dataset.b + '"]'); if (pad) { var old = pad.querySelector('.lfo-path-svg'); if (old) old.remove(); pad.insertAdjacentHTML('afterbegin', buildShapePathSvg(b, b.mode === 'shapes_range' ? 100 : undefined)); } } debouncedSync(); };
        // Double-click to reset to default
        sl.ondblclick = function (e) { e.preventDefault(); var b = findBlock(parseInt(sl.dataset.b)); if (!b) return; var f = sl.dataset.f; var def = knobDefaults[f]; if (def !== undefined) { var snap = captureFullSnapshot(); sl.value = def; sl.dispatchEvent(new Event('input')); undoStack.push({ type: 'full', snapshot: snap }); if (undoStack.length > maxUndo) undoStack.shift(); redoStack = []; updateUndoBadge(); } };
    });
    // Block knob drag interaction
    // knobDefaults already declared above — reused for knob double-click reset
    document.querySelectorAll('.bk').forEach(function (bk) {
        if (!bk.dataset.b) return;
        var bId = parseInt(bk.dataset.b), f = bk.dataset.f;
        var mn = parseFloat(bk.dataset.min), mx = parseFloat(bk.dataset.max);
        bk.addEventListener('mousedown', function (e) {
            e.preventDefault(); e.stopPropagation();
            if (bk.dataset.disabled) return;
            var b = findBlock(bId); if (!b) return;
            var _knobUndoSnap = captureFullSnapshot();
            var startY = e.clientY;
            var curVal = (f === 'sampleSpeedPct') ? (b.sampleSpeed * 100) : (b[f] != null ? b[f] : mn);
            var _knobStartVal = curVal;
            var range = mx - mn;
            var sensitivity = 150;
            function onMove(me) {
                var dy = startY - me.clientY;
                var nv = Math.max(mn, Math.min(mx, curVal + (dy / sensitivity) * range));
                nv = Math.round(nv);
                if (f === 'sampleSpeedPct') b.sampleSpeed = nv / 100;
                else b[f] = nv;
                // Get mode from closest card
                var card = bk.closest('.lcard');
                var mode = 'rand';
                if (card) {
                    if (card.classList.contains('mode-env')) mode = 'env';
                    else if (card.classList.contains('mode-smp')) mode = 'smp';
                    else if (card.classList.contains('mode-morph')) mode = 'morph';
                    else if (card.classList.contains('mode-shapes')) mode = 'shapes';
                }
                // Rebuild SVG
                var norm = (nv - mn) / range;
                var size = 36, r = size / 2, cx = r, cy = r, ir = r - 3;
                var sa = 135 * Math.PI / 180, ea = 405 * Math.PI / 180, sp = ea - sa;
                var va = sa + norm * sp;
                var tPath = describeArc(cx, cy, ir, sa, ea);
                var vPath = norm > 0.005 ? describeArc(cx, cy, ir, sa, va) : '';
                var dx = cx + ir * Math.cos(va), dy2 = cy + ir * Math.sin(va);
                var tVar = 'var(--lk-' + mode + '-track, var(--knob-track))';
                var vVar = 'var(--lk-' + mode + '-value, var(--knob-value))';
                var dVar = 'var(--lk-' + mode + '-dot, var(--knob-dot))';
                var svg = '<svg width="' + size + '" height="' + size + '" viewBox="0 0 ' + size + ' ' + size + '">';
                svg += '<path d="' + tPath + '" fill="none" stroke="' + tVar + '" stroke-width="2.5" stroke-linecap="round"/>';
                if (vPath) svg += '<path d="' + vPath + '" fill="none" stroke="' + vVar + '" stroke-width="2.5" stroke-linecap="round"/>';
                svg += '<circle cx="' + dx.toFixed(1) + '" cy="' + dy2.toFixed(1) + '" r="2.5" fill="' + dVar + '"/>';
                svg += '</svg>';
                var svgEl = bk.querySelector('.bk-svg'); if (svgEl) svgEl.innerHTML = svg;
                // Update value display
                var valEl = bk.querySelector('.bk-val');
                if (valEl) {
                    var unit = '';
                    if (f === 'envAtk' || f === 'envRel' || f === 'glideMs' || f === 'morphGlide') valEl.textContent = nv + 'ms';
                    else if (f === 'threshold') valEl.textContent = nv + 'dB';
                    else if (f === 'shapeSpin' || f === 'lfoRotation') valEl.textContent = (nv > 0 ? '+' : '') + nv + '%';
                    else if (f === 'shapeDepth') valEl.textContent = '±' + nv + '%';
                    else if (f === 'morphSpeed') valEl.textContent = morphSpeedDisplay(nv);
                    else if (f === 'sampleSpeedPct') valEl.textContent = b.sampleSpeed.toFixed(1) + 'x';
                    else valEl.textContent = nv + '%';
                }
                // Live update pad visualizations
                if (f === 'lfoDepth' || f === 'lfoRotation') {
                    var pad = document.querySelector('.morph-pad[data-b="' + bId + '"]:not(.shapes-pad)');
                    if (pad) { var o = pad.querySelector('.lfo-path-svg'); if (o) o.remove(); pad.insertAdjacentHTML('afterbegin', buildLfoPathSvg(b)); }
                }
                if (f === 'shapeSize') {
                    var pad = document.querySelector('.shapes-pad[data-b="' + bId + '"]');
                    if (pad) { var o = pad.querySelector('.lfo-path-svg'); if (o) o.remove(); pad.insertAdjacentHTML('afterbegin', buildShapePathSvg(b, b.mode === 'shapes_range' ? 100 : undefined)); }
                }
                // Live update snap radius rings on morph pad
                if (f === 'snapRadius') {
                    var pad = document.querySelector('.morph-pad[data-b="' + bId + '"]:not(.shapes-pad)');
                    if (pad) {
                        pad.querySelectorAll('.radius-ring').forEach(function (r) { r.remove(); });
                        var ringDiameter = (b.snapRadius || 100) * 2;
                        if (b.snapshots) b.snapshots.forEach(function (s) {
                            var ring = document.createElement('div');
                            ring.className = 'radius-ring';
                            ring.style.cssText = 'width:' + ringDiameter + '%;height:' + ringDiameter + '%;left:' + (s.x * 100) + '%;top:' + ((1 - s.y) * 100) + '%;';
                            pad.appendChild(ring);
                        });
                    }
                }
                debouncedSync();
            }
            function onUp() {
                document.removeEventListener('mousemove', onMove);
                document.removeEventListener('mouseup', onUp);
                // Push undo if value changed
                var endVal = (f === 'sampleSpeedPct') ? (b.sampleSpeed * 100) : b[f];
                if (endVal !== _knobStartVal && _knobUndoSnap) {
                    undoStack.push({ type: 'full', snapshot: _knobUndoSnap });
                    if (undoStack.length > maxUndo) undoStack.shift();
                    redoStack = [];
                    updateUndoBadge();
                }
                // Fade out radius rings
                if (f === 'snapRadius') {
                    var pad = document.querySelector('.morph-pad[data-b="' + bId + '"]:not(.shapes-pad)');
                    if (pad) pad.querySelectorAll('.radius-ring').forEach(function (r) {
                        r.classList.add('fading');
                        setTimeout(function () { r.remove(); }, 400);
                    });
                }
            }
            document.addEventListener('mousemove', onMove);
            document.addEventListener('mouseup', onUp);
        });
        // Double-click to reset
        bk.addEventListener('dblclick', function (e) {
            e.preventDefault();
            var b = findBlock(bId); if (!b) return;
            var def = knobDefaults[f];
            if (def !== undefined) {
                var snap = captureFullSnapshot();
                if (f === 'sampleSpeedPct') b.sampleSpeed = def / 100;
                else b[f] = def;
                undoStack.push({ type: 'full', snapshot: snap });
                if (undoStack.length > maxUndo) undoStack.shift();
                redoStack = [];
                updateUndoBadge();
                renderSingleBlock(bId); syncBlocksToHost();
            }
        });
        // Scroll wheel on block knobs
        bk.addEventListener('wheel', function (e) {
            e.preventDefault(); e.stopPropagation();
            if (bk.dataset.disabled) return;
            var b = findBlock(bId); if (!b) return;
            var range = mx - mn;
            var step = e.shiftKey ? range * 0.002 : range * 0.01;
            var delta = e.deltaY < 0 ? step : -step;
            var curVal = (f === 'sampleSpeedPct') ? (b.sampleSpeed * 100) : (b[f] != null ? b[f] : mn);
            var nv = Math.round(Math.max(mn, Math.min(mx, curVal + delta)));
            if (nv === Math.round(curVal)) return;
            if (f === 'sampleSpeedPct') b.sampleSpeed = nv / 100;
            else b[f] = nv;
            renderSingleBlock(bId); debouncedSync();
        }, { passive: false });
    });
    document.querySelectorAll('.sub-input').forEach(function (inp) { if (!inp.dataset.b) return; inp.onchange = function () { var b = findBlock(parseInt(inp.dataset.b)); if (b) { b[inp.dataset.f] = Math.max(0, Math.min(128, parseInt(inp.value) || 0)); syncBlocksToHost(); } }; });
    document.querySelectorAll('.fire').forEach(function (btn) { btn.onclick = function (e) { e.stopPropagation(); btn.classList.add('flash'); setTimeout(function () { btn.classList.remove('flash'); }, 250); var bId = parseInt(btn.dataset.b); var blk = findBlock(bId); if (blk) { var ov = []; blk.targets.forEach(function (pid) { var p = PMap[pid]; if (p && !p.lk && !p.alk) ov.push({ id: pid, val: p.v }); }); randomize(bId); if (ov.length) pushMultiParamUndo(ov); } flashDot('midiD'); }; });
    document.querySelectorAll('.tx').forEach(function (x) { x.onclick = function (e) { e.stopPropagation(); var bId = parseInt(x.dataset.b); var b = findBlock(bId); if (b) b.targets.delete(x.dataset.p); renderSingleBlock(bId); renderAllPlugins(); syncBlocksToHost(); }; });
    // Sample load buttons
    document.querySelectorAll('.load-smp').forEach(function (btn) {
        btn.onclick = function (e) {
            e.stopPropagation();
            var bId = parseInt(btn.dataset.b);
            if (!(window.__JUCE__ && window.__JUCE__.backend)) return;
            var fn = window.__juceGetNativeFunction('browseSample');
            fn(bId).then(function (result) {
                if (!result) return;
                var b = findBlock(bId);
                if (!b) return;
                b.sampleName = result.name || '';
                b.sampleWaveform = result.waveform || [];
                renderSingleBlock(bId);
                drawWaveform(bId);
            });
        };
    });
    // Draw waveforms for sample blocks that already have data
    blocks.forEach(function (b) { if (b.mode === 'sample' && b.sampleWaveform && b.sampleWaveform.length) drawWaveform(b.id); });
    // Morph pad wiring: snapshot add, delete, playhead drag, snapshot drag
    document.querySelectorAll('.snap-add-btn').forEach(function (btn) {
        btn.onclick = function (e) {
            e.stopPropagation();
            var bId = parseInt(btn.dataset.b);
            var b = findBlock(bId); if (!b) return;
            if (!b.snapshots) b.snapshots = [];
            if (b.snapshots.length >= 12) return;
            // Capture ALL plugin params — not just assigned targets.
            // This way snapshots work even if you assign params later.
            var vals = {};
            var sourceName = '';
            for (var pid in PMap) {
                var p = PMap[pid];
                if (p) {
                    vals[pid] = p.v;
                    if (!sourceName && p.hostId !== undefined) sourceName = getPluginName(p.hostId);
                }
            }
            var spos = getSnapSectorPos(b.snapshots.length);
            b.snapshots.push({ x: spos.x, y: spos.y, values: vals, name: 'S' + (b.snapshots.length + 1), source: sourceName });
            renderSingleBlock(bId); syncBlocksToHost();
            // Visual flash feedback on the pad
            var pad = document.querySelector('.morph-pad[data-b="' + bId + '"]');
            if (pad) { pad.classList.remove('snap-flash'); void pad.offsetWidth; pad.classList.add('snap-flash'); }
            // Glow on the newest chip
            var chips = document.querySelectorAll('.snap-chip[data-b="' + bId + '"]');
            if (chips.length) { var last = chips[chips.length - 1]; last.classList.add('just-added'); setTimeout(function () { last.classList.remove('just-added'); }, 600); }
        };
    });
    // Snapshot Library buttons (morph pad)
    document.querySelectorAll('.snap-lib-btn').forEach(function (btn) {
        btn.onclick = function (e) {
            e.stopPropagation();
            var bId = parseInt(btn.dataset.b);
            if (typeof openSnapshotLibrary === 'function') openSnapshotLibrary(bId);
        };
    });
    document.querySelectorAll('.snap-del').forEach(function (btn) {
        btn.onclick = function (e) {
            e.stopPropagation();
            var bId = parseInt(btn.dataset.b), si = parseInt(btn.dataset.si);
            var b = findBlock(bId); if (!b || !b.snapshots) return;
            b.snapshots.splice(si, 1);
            renderSingleBlock(bId); syncBlocksToHost();
        };
    });
    document.querySelectorAll('.snap-chip').forEach(function (chip) {
        chip.onclick = function (e) {
            if (e.target.classList.contains('snap-del')) return;
            e.stopPropagation();
            var bId = parseInt(chip.dataset.b), si = parseInt(chip.dataset.si);
            var b = findBlock(bId); if (!b || !b.snapshots || !b.snapshots[si]) return;
            b.playheadX = b.snapshots[si].x;
            b.playheadY = b.snapshots[si].y;
            renderSingleBlock(bId); syncBlocksToHost();
        };
    });
    // Lightweight playhead updater — sends only blockId + x,y to C++ (no full JSON reparse)
    var _morphPlayheadFn = null;
    function sendPlayhead(bId, x, y) {
        if (!_morphPlayheadFn) _morphPlayheadFn = window.__juceGetNativeFunction ? window.__juceGetNativeFunction('updateMorphPlayhead') : null;
        if (_morphPlayheadFn) _morphPlayheadFn(bId, x, y);
    }
    // Playhead drag (manual mode)
    document.querySelectorAll('.playhead-dot.manual').forEach(function (dot) {
        dot.onmousedown = function (e) {
            e.stopPropagation(); e.preventDefault();
            var pad = dot.closest('.morph-pad'); if (!pad) return;
            var bId = parseInt(pad.dataset.b);
            var b = findBlock(bId); if (!b) return;
            var onMove = function (ev) {
                var rect = pad.getBoundingClientRect();
                var rawX = (ev.clientX - rect.left) / rect.width;
                var rawY = 1 - (ev.clientY - rect.top) / rect.height;
                var c = clampToCircle(rawX, rawY);
                b.playheadX = c.x;
                b.playheadY = c.y;
                dot.style.left = (c.x * 100) + '%';
                dot.style.top = ((1 - c.y) * 100) + '%';
                sendPlayhead(bId, c.x, c.y); // lightweight update — C++ runs IDW interpolation
            };
            var onUp = function () {
                document.removeEventListener('mousemove', onMove);
                document.removeEventListener('mouseup', onUp);
                syncBlocksToHost(); // full sync on release for state persistence
            };
            document.addEventListener('mousemove', onMove);
            document.addEventListener('mouseup', onUp);
        };
    });
    // Pad click-to-jump + drag (manual mode) — clicking anywhere on the pad moves the playhead
    document.querySelectorAll('.morph-pad:not(.shapes-pad)').forEach(function (pad) {
        pad.onmousedown = function (e) {
            if (e.target.classList.contains('snap-dot') || e.target.classList.contains('snap-label')) return;
            if (e.target.classList.contains('playhead-dot')) return;
            var bId = parseInt(pad.dataset.b);
            var b = findBlock(bId); if (!b || b.morphMode !== 'manual') return;
            if (!b.snapshots || !b.snapshots.length) return;
            e.preventDefault();
            var dot = document.getElementById('morphHead-' + bId);
            if (!dot) return;
            // Jump to click position
            var rect = pad.getBoundingClientRect();
            var c = clampToCircle((e.clientX - rect.left) / rect.width, 1 - (e.clientY - rect.top) / rect.height);
            b.playheadX = c.x; b.playheadY = c.y;
            dot.style.left = (c.x * 100) + '%'; dot.style.top = ((1 - c.y) * 100) + '%';
            sendPlayhead(bId, c.x, c.y);
            // Enter drag mode
            var onMove = function (ev) {
                var r = pad.getBoundingClientRect();
                var mc = clampToCircle((ev.clientX - r.left) / r.width, 1 - (ev.clientY - r.top) / r.height);
                b.playheadX = mc.x; b.playheadY = mc.y;
                dot.style.left = (mc.x * 100) + '%'; dot.style.top = ((1 - mc.y) * 100) + '%';
                sendPlayhead(bId, mc.x, mc.y);
            };
            var onUp = function () { document.removeEventListener('mousemove', onMove); document.removeEventListener('mouseup', onUp); syncBlocksToHost(); };
            document.addEventListener('mousemove', onMove);
            document.addEventListener('mouseup', onUp);
        };
    });
    document.querySelectorAll('.snap-dot').forEach(function (dot) {
        dot.onmousedown = function (e) {
            e.stopPropagation(); e.preventDefault();
            var pad = dot.closest('.morph-pad'); if (!pad) return;
            var bId = parseInt(dot.dataset.b), si = parseInt(dot.dataset.si);
            var b = findBlock(bId); if (!b || !b.snapshots || !b.snapshots[si]) return;
            var onMove = function (ev) {
                var rect = pad.getBoundingClientRect();
                var rawX = (ev.clientX - rect.left) / rect.width;
                var rawY = 1 - (ev.clientY - rect.top) / rect.height;
                var c = clampToCircle(rawX, rawY);
                b.snapshots[si].x = c.x;
                b.snapshots[si].y = c.y;
                dot.style.left = (c.x * 100) + '%';
                dot.style.top = ((1 - c.y) * 100) + '%';
            };
            var onUp = function () {
                document.removeEventListener('mousemove', onMove);
                document.removeEventListener('mouseup', onUp);
                syncBlocksToHost();
            };
            document.addEventListener('mousemove', onMove);
            document.addEventListener('mouseup', onUp);
        };
    });
    // ── Lane mode wiring ──
    // Tool buttons
    document.querySelectorAll('.lane-tbtn[data-lt]').forEach(function (btn) {
        btn.onclick = function (e) {
            e.stopPropagation();
            var bId = parseInt(btn.dataset.b), b = findBlock(bId);
            if (!b) return;
            if (btn.dataset.lt === 'clear') {
                b.lanes.forEach(function (l) {
                    var edgeY = (l.pts.length && l.pts[0].x < 0.01) ? l.pts[0].y : 0.5;
                    l.pts = [{ x: 0, y: edgeY }, { x: 1, y: edgeY }];
                    if (l._sel) l._sel.clear();
                });
                renderSingleBlock(bId); syncBlocksToHost(); return;
            }
            if (btn.dataset.lt === 'random') {
                b.lanes.forEach(function (l) {
                    laneRandomize(l, b.laneGrid);
                    if (l._sel) l._sel.clear();
                });
                renderSingleBlock(bId); syncBlocksToHost(); return;
            }
            b.laneTool = btn.dataset.lt;
            // Update button states without full rebuild
            btn.closest('.lane-toolbar').querySelectorAll('.lane-tbtn[data-lt]').forEach(function (t) {
                if (t.dataset.lt !== 'clear' && t.dataset.lt !== 'random') t.classList.toggle('on', t.dataset.lt === b.laneTool);
            });
        };
    });
    // Grid tabs
    document.querySelectorAll('.lane-itabs').forEach(function (tabs) {
        tabs.querySelectorAll('.lane-itab').forEach(function (tab) {
            tab.onclick = function (e) {
                e.stopPropagation();
                var bId = parseInt(tabs.dataset.b), b = findBlock(bId);
                if (!b) return;
                b.laneGrid = tab.dataset.v;
                tabs.querySelectorAll('.lane-itab').forEach(function (t) { t.classList.toggle('on', t.dataset.v === b.laneGrid); });
                // Grid is a snap aid — switching does NOT move existing points
                // Redraw all canvases with new grid
                if (b.lanes) b.lanes.forEach(function (l, li) { laneDrawCanvas(b, li); });
                debouncedSync();
            };
        });
    });
    // Lane collapse arrows
    document.querySelectorAll('.lane-hdr-arrow').forEach(function (arr) {
        arr.onclick = function (e) {
            e.stopPropagation();
            var bId = parseInt(arr.dataset.b), li = parseInt(arr.dataset.li);
            var b = findBlock(bId); if (!b || !b.lanes[li]) return;
            b.lanes[li].collapsed = !b.lanes[li].collapsed;
            renderSingleBlock(bId);
        };
    });
    // Lane knob clicks (depth + phase) — in left sidebar + header
    document.querySelectorAll('.lane-lb-knob, .lane-hdr-phase, .lane-hdr-depth').forEach(function (el) {
        el.onclick = function (e) {
            e.stopPropagation();
            var bId = parseInt(el.dataset.b), li = parseInt(el.dataset.li);
            var b = findBlock(bId); if (!b || !b.lanes[li]) return;
            var k = el.dataset.lk || (el.classList.contains('lane-hdr-phase') ? 'phase' : 'depth');
            if (k === 'phase') {
                b.lanes[li].phase = (b.lanes[li].phase + 90) % 360;
            } else {
                b.lanes[li].depth = b.lanes[li].depth >= 100 ? 25 : b.lanes[li].depth + 25;
            }
            renderSingleBlock(bId); debouncedSync();
        };
    });
    // Lane footer text knob drag — mousedown + vertical drag + dblclick reset
    document.querySelectorAll('.lane-ft-knob').forEach(function (el) {
        var bId = parseInt(el.dataset.b), li = parseInt(el.dataset.li);
        var k = el.dataset.lk;
        var isDepth = (k === 'depth');
        var mn = isDepth ? 0 : -50, mx = isDepth ? 100 : 50;
        var defaults = { depth: 100, slew: 0, warp: 0 };
        var labels = { depth: 'Depth ', slew: 'Slew ', warp: 'Warp ' };
        function fmt(v) {
            if (k === 'depth') return labels[k] + v + '%';
            return labels[k] + (v >= 0 ? '+' : '') + v;
        }
        el.addEventListener('mousedown', function (e) {
            e.preventDefault(); e.stopPropagation();
            var b = findBlock(bId); if (!b || !b.lanes[li]) return;
            var lane = b.lanes[li];
            // Double-click detection via timestamp on the lane object
            if (!lane._knobClicks) lane._knobClicks = {};
            var now = Date.now();
            if (lane._knobClicks[k] && now - lane._knobClicks[k] < 350) {
                // Double-click: reset to default
                lane[k] = defaults[k];
                lane._knobClicks[k] = 0;
                el.textContent = fmt(defaults[k]);
                laneDrawCanvas(b, li);
                renderSingleBlock(bId); debouncedSync();
                return;
            }
            lane._knobClicks[k] = now;
            var startY = e.clientY;
            var startVal = (lane[k] != null ? lane[k] : defaults[k]);
            var dragged = false;
            document.body.classList.add('knob-dragging');
            el.classList.add('dragging');
            function onMove(me) {
                dragged = true;
                var dy = startY - me.clientY;
                var nv = Math.round(Math.max(mn, Math.min(mx, startVal + dy * 0.5)));
                lane[k] = nv;
                el.textContent = fmt(nv);
                laneDrawCanvas(b, li);
            }
            function onUp() {
                document.removeEventListener('mousemove', onMove);
                document.removeEventListener('mouseup', onUp);
                document.body.classList.remove('knob-dragging');
                el.classList.remove('dragging');
                renderSingleBlock(bId); debouncedSync();
            }
            document.addEventListener('mousemove', onMove);
            document.addEventListener('mouseup', onUp);
        });
    });
    // Lane mute toggle
    document.querySelectorAll('.lane-hdr-mute').forEach(function (sp) {
        sp.onclick = function (e) {
            e.stopPropagation();
            var bId = parseInt(sp.dataset.b), li = parseInt(sp.dataset.li);
            var b = findBlock(bId); if (!b || !b.lanes[li]) return;
            b.lanes[li].muted = !b.lanes[li].muted;
            renderSingleBlock(bId); debouncedSync();
        };
    });
    // Lane param chip × remove
    document.querySelectorAll('.lane-param-chip-x').forEach(function (btn) {
        btn.onclick = function (e) {
            e.stopPropagation();
            var bId = parseInt(btn.dataset.b), li = parseInt(btn.dataset.li);
            var pid = btn.dataset.pid;
            var b = findBlock(bId); if (!b || !b.lanes[li]) return;
            var lane = b.lanes[li];
            lane.pids = lane.pids.filter(function (p) { return p !== pid; });
            if (lane.pids.length === 0) {
                b.lanes.splice(li, 1); // remove empty lane
            }
            renderSingleBlock(bId); debouncedSync();
        };
    });
    // Lane + Add param button
    document.querySelectorAll('.lane-add-param-btn').forEach(function (btn) {
        btn.onclick = function (e) {
            e.stopPropagation();
            var bId = parseInt(btn.dataset.b), li = parseInt(btn.dataset.li);
            var b = findBlock(bId); if (!b || !b.lanes[li]) return;
            var lane = b.lanes[li];
            var assignedHere = {};
            lane.pids.forEach(function (p) { assignedHere[p] = true; });

            // Build all assigned-in-any-lane set
            var allAssigned = {};
            b.lanes.forEach(function (l) { l.pids.forEach(function (p) { allAssigned[p] = true; }); });

            // Section 1: params in OTHER lanes (merge/move)
            var moveOpts = [];
            for (var oi = 0; oi < b.lanes.length; oi++) {
                if (oi === li) continue;
                b.lanes[oi].pids.forEach(function (pid) {
                    var pp = PMap[pid];
                    moveOpts.push({ pid: pid, label: pp ? pp.name : pid, srcLane: oi });
                });
            }

            // Section 2: plugin params NOT yet in any lane of this block
            var pluginOpts = [];
            pluginBlocks.forEach(function (pb) {
                pb.params.forEach(function (p) {
                    if (allAssigned[p.id] || assignedHere[p.id]) return;
                    pluginOpts.push({ pid: p.id, label: p.name, plugin: pb.name });
                });
            });

            if (moveOpts.length === 0 && pluginOpts.length === 0) return;

            // Build dropdown menu
            var menu = document.createElement('div');
            menu.className = 'lane-add-menu';
            menu.style.position = 'absolute';
            menu.style.zIndex = '999';
            var rect = btn.getBoundingClientRect();
            menu.style.left = (rect.left + window.scrollX) + 'px';
            menu.style.top = (rect.bottom + window.scrollY) + 'px';

            // Search input for filtering (shown when many options)
            var totalOpts = moveOpts.length + pluginOpts.length;
            var searchInput = null;
            var allItems = [];
            if (totalOpts > 8) {
                searchInput = document.createElement('input');
                searchInput.type = 'text';
                searchInput.className = 'lane-add-menu-search';
                searchInput.placeholder = 'Search params\u2026';
                searchInput.onclick = function (ev) { ev.stopPropagation(); };
                menu.appendChild(searchInput);
            }

            // Helper to build a section
            function addSection(title, items, isMove) {
                if (items.length === 0) return;
                var hdr = document.createElement('div');
                hdr.className = 'lane-add-menu-hdr';
                hdr.textContent = title;
                menu.appendChild(hdr);
                items.forEach(function (opt) {
                    var item = document.createElement('div');
                    item.className = 'lane-add-menu-item';
                    var label = opt.label;
                    if (isMove) label += ' \u2190 Lane ' + (opt.srcLane + 1);
                    else label = opt.plugin + ' / ' + opt.label;
                    item.textContent = label;
                    item.dataset.search = label.toLowerCase();
                    item.onclick = function (ev) {
                        ev.stopPropagation();
                        lane.pids.push(opt.pid);
                        if (isMove && opt.srcLane >= 0 && b.lanes[opt.srcLane]) {
                            // Move from source lane
                            b.lanes[opt.srcLane].pids = b.lanes[opt.srcLane].pids.filter(function (p) { return p !== opt.pid; });
                            if (b.lanes[opt.srcLane].pids.length === 0) b.lanes.splice(opt.srcLane, 1);
                        } else if (!isMove) {
                            // Add to block targets too
                            b.targets.add(opt.pid);
                        }
                        menu.remove();
                        renderSingleBlock(bId); debouncedSync();
                    };
                    menu.appendChild(item);
                    allItems.push(item);
                });
            }

            addSection('\u21C4 MOVE FROM LANE', moveOpts, true);
            addSection('\u2795 ADD FROM PLUGIN', pluginOpts, false);

            // Wire up search filtering
            if (searchInput) {
                searchInput.oninput = function () {
                    var q = searchInput.value.toLowerCase();
                    allItems.forEach(function (el) {
                        el.style.display = (el.dataset.search || '').indexOf(q) >= 0 ? '' : 'none';
                    });
                };
            }

            document.body.appendChild(menu);
            if (searchInput) searchInput.focus();
            // Close on outside click
            setTimeout(function () {
                document.addEventListener('click', function closer() {
                    menu.remove();
                    document.removeEventListener('click', closer);
                });
            }, 10);
        };
    });
    // Lane interp buttons
    document.querySelectorAll('.lane-ibtn[data-linterp]').forEach(function (btn) {
        btn.onclick = function (e) {
            e.stopPropagation();
            var bId = parseInt(btn.dataset.b), li = parseInt(btn.dataset.li);
            var b = findBlock(bId); if (!b || !b.lanes[li]) return;
            b.lanes[li].interp = btn.dataset.linterp;
            // Update buttons without re-render
            var wrap = btn.closest('.lane-interp-stack');
            if (wrap) wrap.querySelectorAll('.lane-ibtn').forEach(function (t) { t.classList.toggle('on', t.dataset.linterp === b.lanes[li].interp); });
            laneDrawCanvas(b, li);
            debouncedSync();
        };
    });
    // Lane sync pills
    document.querySelectorAll('.lane-sync-pill').forEach(function (btn) {
        btn.onclick = function (e) {
            e.stopPropagation();
            var bId = parseInt(btn.dataset.b), li = parseInt(btn.dataset.li);
            var b = findBlock(bId); if (!b || !b.lanes[li]) return;
            b.lanes[li].synced = !b.lanes[li].synced;
            btn.classList.toggle('on', b.lanes[li].synced);
            btn.textContent = b.lanes[li].synced ? 'Host' : 'Int';
            debouncedSync();
        };
    });
    // Lane header selects (loop length, play mode)
    document.querySelectorAll('.lane-hdr-sel').forEach(function (sel) {
        sel.onchange = function () {
            var bId = parseInt(sel.dataset.b), li = parseInt(sel.dataset.li);
            var b = findBlock(bId); if (!b || !b.lanes[li]) return;
            b.lanes[li][sel.dataset.lf] = sel.value;
            if (sel.dataset.lf === 'loopLen') renderSingleBlock(bId); // show/hide freeSecs
            debouncedSync();
        };
    });
    // Free seconds input
    document.querySelectorAll('.lane-hdr-fsec').forEach(function (inp) {
        inp.onchange = function () {
            var bId = parseInt(inp.dataset.b), li = parseInt(inp.dataset.li);
            var b = findBlock(bId); if (!b || !b.lanes[li]) return;
            b.lanes[li].freeSecs = parseFloat(inp.value) || 4;
            debouncedSync();
        };
    });
    // Initialize lane canvases
    blocks.forEach(function (b) {
        if (b.mode === 'lane') laneCanvasSetup(b);
    });
}
function drawWaveform(blockId) {
    var b = findBlock(blockId);
    if (!b || !b.sampleWaveform || !b.sampleWaveform.length) return;
    var cv = document.getElementById('waveCv-' + blockId);
    if (!cv) return;
    var ctx = cv.getContext('2d');
    var w = cv.width, h = cv.height, peaks = b.sampleWaveform;
    ctx.clearRect(0, 0, w, h);
    ctx.fillStyle = '#AA44FF33';
    ctx.strokeStyle = '#AA44FF';
    ctx.lineWidth = 1;
    ctx.beginPath();
    var step = w / peaks.length;
    for (var i = 0; i < peaks.length; i++) {
        var x = i * step, p = Math.min(1, peaks[i]);
        var barH = p * h;
        ctx.rect(x, h - barH, Math.max(1, step - 0.5), barH);
    }
    ctx.fill();
    ctx.beginPath();
    ctx.moveTo(0, h);
    for (var i = 0; i < peaks.length; i++) {
        var x = i * step, p = Math.min(1, peaks[i]);
        ctx.lineTo(x + step / 2, h - p * h);
    }
    ctx.lineTo(w, h);
    ctx.stroke();
}
function updateAssignBanner() {
    var bn = document.getElementById('assignBanner'), lb = document.getElementById('assignTarget');
    if (assignMode) { var b = findBlock(assignMode); if (!b) { bn.classList.remove('vis'); return; } bn.classList.add('vis'); var col = bColor(b.colorIdx); bn.style.background = col + '22'; bn.style.borderColor = col + '66'; bn.style.color = col; lb.textContent = 'Block ' + (blocks.indexOf(b) + 1) + ' (' + b.mode + ')'; }
    else { bn.classList.remove('vis'); }
}
// ==========================================================
// RANDOMIZE — handles all range modes, quantize, smooth glide
// ==========================================================
function randomize(bId) {
    var b = findBlock(bId); if (!b) return;
    var mn = b.rMin / 100, mx = b.rMax / 100;
    // Guard: if Min > Max in absolute mode, swap so randomize stays valid
    if (mn > mx) { var t = mn; mn = mx; mx = t; }
    var isRelative = b.rangeMode === 'relative';
    var startGlideFn = (window.__JUCE__ && window.__JUCE__.backend) ? window.__juceGetNativeFunction('startGlide') : null;

    // Collect all instant param changes into a batch for single IPC call (C4 fix)
    var instantBatch = [];

    b.targets.forEach(function (id) {
        var p = PMap[id]; if (!p || p.lk) return;
        var newVal;
        if (isRelative) {
            // Relative: offset from current value by random amount between ±[rMin..rMax]
            var offset = mn + Math.random() * (mx - mn); // magnitude in [rMin, rMax]
            var sign = Math.random() < 0.5 ? -1 : 1;
            newVal = p.v + sign * offset;
        } else {
            // Absolute: random between min and max
            newVal = mn + Math.random() * (mx - mn);
        }
        // Quantize
        if (b.quantize && b.qSteps > 1) {
            newVal = Math.round(newVal * (b.qSteps - 1)) / (b.qSteps - 1);
        }
        newVal = Math.max(0, Math.min(1, newVal));

        if (b.movement === 'glide' && b.glideMs > 0) {
            // Send glide to C++ for per-buffer interpolation (no zipper noise)
            if (startGlideFn && p.hostId !== undefined) {
                startGlideFn(p.hostId, p.realIndex, newVal, b.glideMs);
            }
            // Update JS state to target so undo captures correct values
            p.v = newVal;
            _dirtyParams.add(id);
        } else {
            // Instant — collect for batch
            p.v = newVal;
            _dirtyParams.add(id);
            if (p.hostId !== undefined) {
                instantBatch.push({ p: p.hostId, i: p.realIndex, v: newVal });
            }
        }
    });

    // Send all instant changes in a single IPC call (instead of N individual setParam calls)
    if (instantBatch.length > 0 && window.__JUCE__ && window.__JUCE__.backend) {
        var batchFn = window.__juceGetNativeFunction('applyParamBatch');
        if (batchFn) batchFn(JSON.stringify(instantBatch));
    }

    // Defer display refresh to next animation frame (L2 fix)
    requestAnimationFrame(function () { refreshParamDisplay(); });
}

// ==========================================================
// REAL-TIME DATA PROCESSING
// ==========================================================

// ─── Sync logic block state to C++ backend ───
function syncBlocksToHost() {
    if (typeof markGpDirty === 'function') markGpDirty();
    if (!(window.__JUCE__ && window.__JUCE__.backend)) return;
    var fn = window.__juceGetNativeFunction('updateBlocks');
    var data = blocks.map(function (b) {
        // Build consistent target lists — tList for C++, tIds for snapshot value lookup
        var tList = [], tIds = [];
        b.targets.forEach(function (id) {
            var p = PMap[id];
            if (!p || p.lk) return; // Skip locked params
            tList.push({ hostId: p.hostId, paramIndex: p.realIndex });
            tIds.push(id);
        });
        var obj = {
            id: b.id, mode: b.mode, targets: tList,
            trigger: b.trigger, beatDiv: b.beatDiv,
            midiMode: b.midiMode, midiNote: b.midiNote || 60, midiCC: b.midiCC || 1, midiCh: parseInt(b.midiCh) || 0,
            threshold: b.threshold || -12, audioSrc: b.audioSrc || 'main',
            rMin: b.rMin / 100, rMax: b.rMax / 100,
            rangeMode: b.rangeMode || 'absolute', polarity: b.polarity || 'bipolar',
            quantize: !!b.quantize, qSteps: b.qSteps || 12,
            movement: b.movement || 'instant', glideMs: b.glideMs || 200,
            envAtk: b.envAtk || 10, envRel: b.envRel || 100, envSens: b.envSens || 50, envInvert: !!b.envInvert,
            loopMode: b.loopMode || 'loop', sampleSpeed: b.sampleSpeed || 1.0, sampleReverse: !!b.sampleReverse, jumpMode: b.jumpMode || 'restart',
            clockSource: b.clockSource || 'daw', internalBpm: internalBpm,
            enabled: b.enabled !== false
        };
        // Send base values for relative mode (captured at assignment time)
        var bases = [];
        for (var ti = 0; ti < tIds.length; ti++) {
            var base = (b.targetBases && b.targetBases[tIds[ti]] !== undefined)
                ? b.targetBases[tIds[ti]]
                : (PMap[tIds[ti]] ? PMap[tIds[ti]].v : 0.5);
            bases.push(base);
        }
        obj.targetBases = bases;
        if (b.mode === 'morph_pad') {
            obj.snapshots = (b.snapshots || []).map(function (s) {
                var vals = [];
                // Use tIds (same order as tList) so targets[i] aligns with targetValues[i]
                for (var ti = 0; ti < tIds.length; ti++) {
                    // If snapshot has a stored value for this param, use it.
                    // Otherwise fall back to the param's CURRENT value (not 0.5)
                    // so IDW doesn't overwrite newly assigned params with a meaningless default.
                    var fallback = PMap[tIds[ti]] ? PMap[tIds[ti]].v : 0.5;
                    vals.push(s.values && s.values[tIds[ti]] !== undefined ? s.values[tIds[ti]] : fallback);
                }
                return { x: s.x, y: s.y, targetValues: vals };
            });
            obj.playheadX = b.playheadX;
            obj.playheadY = b.playheadY;
            obj.morphMode = b.morphMode || 'manual';
            obj.exploreMode = b.exploreMode || 'wander';
            obj.lfoShape = b.lfoShape || 'circle';
            obj.lfoDepth = (b.lfoDepth != null ? b.lfoDepth : 80) / 100;
            obj.lfoRotation = (b.lfoRotation || 0) / 100;
            obj.morphSpeed = (b.morphSpeed || 50) / 100;
            obj.morphAction = b.morphAction || 'jump';
            obj.stepOrder = b.stepOrder || 'cycle';
            obj.morphSource = b.morphSource || 'midi';
            obj.jitter = (b.jitter || 0) / 100;
            obj.morphGlide = b.morphGlide || 200;
            obj.morphTempoSync = !!b.morphTempoSync;
            obj.morphSyncDiv = b.morphSyncDiv || '1/4';
            obj.snapRadius = (b.snapRadius || 100) / 100;
        }
        if (b.mode === 'shapes' || b.mode === 'shapes_range') {
            obj.shapeType = b.shapeType || 'circle';
            obj.shapeTracking = b.shapeTracking || 'horizontal';
            obj.shapeSize = b.mode === 'shapes_range' ? 1.0 : (b.shapeSize != null ? b.shapeSize : 80) / 100;
            obj.shapeSpin = (b.shapeSpin || 0) / 100;
            obj.shapeSpeed = (b.shapeSpeed || 50) / 100;
            obj.shapeDepth = (b.shapeDepth || 50) / 100;
            obj.shapeRange = b.mode === 'shapes_range' ? 'relative' : (b.shapeRange || 'relative');
            obj.shapePolarity = b.shapePolarity || 'bipolar';
            obj.shapeTempoSync = !!b.shapeTempoSync;
            obj.shapeSyncDiv = b.shapeSyncDiv || '1/4';
            obj.shapeTrigger = b.shapeTrigger || 'free';
        }
        if (b.mode === 'shapes_range') {
            // Send per-param ranges aligned with targets array
            obj.targetRanges = tIds.map(function (pid) {
                return b.targetRanges && b.targetRanges[pid] !== undefined ? b.targetRanges[pid] : 0;
            });
            // Send per-param base values (anchor positions) aligned with targets array
            // Use the JS-stored base (updated on knob drags) as the source of truth
            obj.targetRangeBases = tIds.map(function (pid) {
                return b.targetRangeBases && b.targetRangeBases[pid] !== undefined ? b.targetRangeBases[pid] : (PMap[pid] ? PMap[pid].v : 0.5);
            });
        }
        if (b.mode === 'lane') {
            obj.lanes = (b.lanes || []).map(function (lane, li) {
                // Resolve all pids → targets
                var laneTargets = [];
                (lane.pids || []).forEach(function (pid) {
                    for (var ti = 0; ti < tIds.length; ti++) {
                        if (tIds[ti] === pid) {
                            laneTargets.push({ pluginId: tList[ti].hostId, paramIndex: tList[ti].paramIndex });
                            break;
                        }
                    }
                });
                if (laneTargets.length === 0) return null;
                return {
                    targets: laneTargets,
                    pts: (lane.pts || []).map(function (p) { return { x: p.x, y: p.y }; }),
                    loopLen: lane.loopLen || '1/1',
                    phase: (lane.phase || 0) / 360.0,
                    depth: (lane.depth != null ? lane.depth : 100) / 100.0,
                    slew: lane.slew || 0,
                    warp: lane.warp || 0,
                    interp: lane.interp || 'smooth',
                    playMode: lane.playMode || 'forward',
                    freeSecs: lane.freeSecs || 4,
                    synced: lane.synced !== false,
                    muted: !!lane.muted
                };
            }).filter(function (l) { return l !== null; });
        }
        return obj;
    });
    fn(JSON.stringify(data));
    saveUiStateToHost();
}

// Get active morph pad blocks (for context menu submenu)
function getMorphBlocks() {
    var result = [];
    for (var i = 0; i < blocks.length; i++) {
        if (blocks[i].mode === 'morph_pad') result.push({ id: blocks[i].id, idx: i, colorIdx: blocks[i].colorIdx, snapCount: (blocks[i].snapshots || []).length });
    }
    return result;
}

// Add a snapshot to a morph block from a plugin's current param values
// pluginId: which plugin to capture values from (or null for all)
function addSnapshotToMorphBlock(blockId, pluginId) {
    var b = findBlock(blockId);
    if (!b || b.mode !== 'morph_pad') return;
    if (!b.snapshots) b.snapshots = [];
    if (b.snapshots.length >= 12) return;

    // Capture ALL plugin params — not just assigned targets.
    // Snapshots are full state captures. You can assign params later
    // and the snapshot will already have their values stored.
    var vals = {};
    for (var pid in PMap) {
        var p = PMap[pid];
        if (p) vals[pid] = p.v;
    }

    // Source label: use the triggering plugin's name
    var sourceName = getPluginName(pluginId) || 'Manual';

    var spos = getSnapSectorPos(b.snapshots.length);
    b.snapshots.push({ x: spos.x, y: spos.y, values: vals, name: 'S' + (b.snapshots.length + 1), source: sourceName });
    renderSingleBlock(blockId);
    syncBlocksToHost();

    // Flash feedback
    var pad = document.querySelector('.morph-pad[data-b="' + blockId + '"]');
    if (pad) { pad.classList.remove('snap-flash'); void pad.offsetWidth; pad.classList.add('snap-flash'); }
    var chips = document.querySelectorAll('.snap-chip[data-b="' + blockId + '"]');
    if (chips.length) { var last = chips[chips.length - 1]; last.classList.add('just-added'); setTimeout(function () { last.classList.remove('just-added'); }, 600); }
}
