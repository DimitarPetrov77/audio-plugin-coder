// ============================================================
// CONTEXT MENUS
// Param context menu, plugin context menu, lock/unlock
// ============================================================
// Context menu
function showCtx(x, y, p) {
    var m = document.getElementById('ctx');
    m.style.left = Math.min(x + window.scrollX, 900) + 'px'; m.style.top = Math.min(y + window.scrollY, 580) + 'px';
    m.classList.add('vis');
    var pids = selectedParams.size > 0 ? Array.from(selectedParams) : [p.id];
    var count = pids.length;
    var suffix = count > 1 ? ' (' + count + ')' : '';
    // Determine Lock/Unlock visibility based on ALL selected params
    var anyLockable = false, anyUnlockable = false, anyLocked = false;
    pids.forEach(function (pid) {
        var pp = PMap[pid]; if (!pp) return;
        if (!pp.lk && !pp.alk) anyLockable = true;
        if (pp.lk && !pp.alk) anyUnlockable = true;
        if (pp.lk) anyLocked = true;
    });
    var cL = document.getElementById('cL');
    var cU = document.getElementById('cU');
    cL.style.display = anyLockable ? '' : 'none';
    cU.style.display = anyUnlockable ? '' : 'none';
    cL.textContent = 'Lock' + suffix;
    cU.textContent = 'Unlock' + suffix;
    // Build "Unassign from Block" submenu — show blocks that have any selected param
    var unSub = document.getElementById('ctxUnassignMenu');
    var unSep = document.getElementById('ctxUnassignSep');
    var unWrap = document.getElementById('ctxUnassignSub');
    var assignedBlocks = [];
    for (var bi = 0; bi < blocks.length; bi++) {
        var bl = blocks[bi];
        var hasAny = false;
        for (var pi = 0; pi < pids.length; pi++) {
            if (bl.targets.has(pids[pi])) { hasAny = true; break; }
        }
        if (hasAny) assignedBlocks.push({ bl: bl, idx: bi });
    }
    if (assignedBlocks.length > 0 && !anyLocked) {
        unSep.style.display = ''; unWrap.style.display = '';
        var ush = '';
        for (var ai = 0; ai < assignedBlocks.length; ai++) {
            var ab = assignedBlocks[ai];
            ush += '<div class="ctx-i" data-unassignblock="' + ab.bl.id + '"><span class="ctx-block-dot" style="background:' + bColor(ab.bl.colorIdx) + '"></span>Block ' + (ab.idx + 1) + ' (' + ab.bl.mode + ')</div>';
        }
        unSub.innerHTML = ush;
        unSub.querySelectorAll('[data-unassignblock]').forEach(function (item) {
            item.onclick = function (e) {
                e.stopPropagation();
                var bid = parseInt(item.dataset.unassignblock);
                var bl = findBlock(bid);
                if (!bl) return;
                pids.forEach(function (pid) { bl.targets.delete(pid); });
                m.classList.remove('vis');
                selectedParams.clear();
                renderAllPlugins(); renderBlocks(); syncBlocksToHost();
            };
        });
    } else {
        unSep.style.display = 'none'; unWrap.style.display = 'none';
    }
    // Build "Assign to Block" submenu
    var sub = document.getElementById('ctxAssignMenu');
    var sep = document.getElementById('ctxAssignSep');
    var subWrap = document.getElementById('ctxAssignSub');
    if (blocks.length > 0 && !anyLocked) {
        sep.style.display = ''; subWrap.style.display = '';
        var sh = '';
        for (var bi = 0; bi < blocks.length; bi++) {
            var bl = blocks[bi];
            sh += '<div class="ctx-i" data-assignblock="' + bl.id + '"><span class="ctx-block-dot" style="background:' + bColor(bl.colorIdx) + '"></span>Block ' + (bi + 1) + ' (' + bl.mode + ')</div>';
        }
        sub.innerHTML = sh;
        sub.querySelectorAll('[data-assignblock]').forEach(function (item) {
            item.onclick = function (e) {
                e.stopPropagation();
                var bid = parseInt(item.dataset.assignblock);
                var bl = findBlock(bid);
                if (!bl) return;
                pids.forEach(function (pid) {
                    var pp = PMap[pid];
                    if (pp && !pp.lk) assignTarget(bl, pid);
                });
                m.classList.remove('vis');
                selectedParams.clear();
                renderAllPlugins(); renderBlocks(); syncBlocksToHost();
            };
        });
    } else {
        sep.style.display = 'none'; subWrap.style.display = 'none';
    }
}
function showPlugCtx(x, y, plugId) {
    var m = document.getElementById('plugCtx');
    m.style.left = Math.min(x + window.scrollX, 900) + 'px';
    m.style.top = Math.min(y + window.scrollY, 560) + 'px';
    m.classList.add('vis');
    // Update bypass label
    var pb = null;
    for (var i = 0; i < pluginBlocks.length; i++) { if (pluginBlocks[i].id === plugId) { pb = pluginBlocks[i]; break; } }
    document.getElementById('pcBypass').textContent = (pb && pb.bypassed) ? 'Unbypass Plugin' : 'Bypass Plugin';
    // Build "Add Snapshot to" submenu — show morph_pad blocks
    var snapSep = document.getElementById('pcSnapSep');
    var snapWrap = document.getElementById('pcSnapSub');
    var snapMenu = document.getElementById('pcSnapMenu');
    var morphBlocks = getMorphBlocks();
    if (morphBlocks.length > 0) {
        snapSep.style.display = ''; snapWrap.style.display = '';
        var sh = '';
        for (var mi = 0; mi < morphBlocks.length; mi++) {
            var mb = morphBlocks[mi];
            var full = mb.snapCount >= 12;
            sh += '<div class="ctx-i' + (full ? ' disabled' : '') + '" data-snapblock="' + mb.id + '" data-snapplug="' + plugId + '"><span class="ctx-block-dot" style="background:' + bColor(mb.colorIdx) + '"></span>Block ' + (mb.idx + 1) + ' (' + mb.snapCount + '/12)' + (full ? ' — Full' : '') + '</div>';
        }
        snapMenu.innerHTML = sh;
        snapMenu.querySelectorAll('[data-snapblock]').forEach(function (item) {
            if (item.classList.contains('disabled')) return;
            item.onclick = function (e) {
                e.stopPropagation();
                var bid = parseInt(item.dataset.snapblock);
                var pid = parseInt(item.dataset.snapplug);
                addSnapshotToMorphBlock(bid, pid);
                m.classList.remove('vis');
            };
        });
    } else {
        snapSep.style.display = 'none'; snapWrap.style.display = 'none';
    }
}
document.addEventListener('click', function () {
    document.getElementById('ctx').classList.remove('vis');
    document.getElementById('plugCtx').classList.remove('vis');
});
// Lock: operates on all selected params
document.getElementById('cL').onclick = function () {
    var pids = selectedParams.size > 0 ? Array.from(selectedParams) : (ctxP ? [ctxP.id] : []);
    pushUndoSnapshot();
    pids.forEach(function (pid) {
        var pp = PMap[pid]; if (!pp || pp.alk) return;
        pp.lk = true;
        blocks.forEach(function (b) { b.targets.delete(pid); });
    });
    selectedParams.clear();
    renderAllPlugins(); renderBlocks(); syncBlocksToHost();
};
// Unlock: operates on all selected params
document.getElementById('cU').onclick = function () {
    var pids = selectedParams.size > 0 ? Array.from(selectedParams) : (ctxP ? [ctxP.id] : []);
    pushUndoSnapshot();
    pids.forEach(function (pid) {
        var pp = PMap[pid]; if (!pp || pp.alk) return;
        pp.lk = false;
    });
    selectedParams.clear();
    renderAllPlugins(); syncBlocksToHost();
};

// Plugin context menu actions
document.getElementById('pcLockAll').onclick = function () {
    var pb = null;
    for (var i = 0; i < pluginBlocks.length; i++) { if (pluginBlocks[i].id === plugCtxPluginId) { pb = pluginBlocks[i]; break; } }
    if (!pb) return;
    pushUndoSnapshot();
    pb.params.forEach(function (p) {
        p.lk = true;
        blocks.forEach(function (b) { b.targets.delete(p.id); });
    });
    renderAllPlugins(); renderBlocks(); updCounts(); syncBlocksToHost(); saveUiStateToHost();
};
document.getElementById('pcUnlockAll').onclick = function () {
    var pb = null;
    for (var i = 0; i < pluginBlocks.length; i++) { if (pluginBlocks[i].id === plugCtxPluginId) { pb = pluginBlocks[i]; break; } }
    if (!pb) return;
    pushUndoSnapshot();
    pb.params.forEach(function (p) { if (!p.alk) p.lk = false; });
    renderAllPlugins(); updCounts(); syncBlocksToHost(); saveUiStateToHost();
};
document.getElementById('pcBypass').onclick = function () {
    var pb = null;
    for (var i = 0; i < pluginBlocks.length; i++) { if (pluginBlocks[i].id === plugCtxPluginId) { pb = pluginBlocks[i]; break; } }
    if (!pb) return;
    pb.bypassed = !pb.bypassed;
    // Sync to C++ audio thread
    if (window.__JUCE__ && window.__JUCE__.backend) {
        var fn = window.__juceGetNativeFunction('setPluginBypass');
        fn(pb.hostId, pb.bypassed);
    }
    renderAllPlugins(); saveUiStateToHost();
};
document.getElementById('pcRandomize').onclick = function () {
    var pb = null;
    for (var i = 0; i < pluginBlocks.length; i++) { if (pluginBlocks[i].id === plugCtxPluginId) { pb = pluginBlocks[i]; break; } }
    if (!pb) return;
    var oldVals = [];
    pb.params.forEach(function (p) { if (!p.lk && !p.alk) oldVals.push({ id: p.id, val: p.v }); });
    var setParamFn = (window.__JUCE__ && window.__JUCE__.backend) ? window.__juceGetNativeFunction('setParam') : null;
    pb.params.forEach(function (p) {
        if (p.lk || p.alk) return;
        var newVal = Math.random();
        p.v = newVal;
        if (setParamFn && p.hostId !== undefined) setParamFn(p.hostId, p.realIndex, newVal);
    });
    pushMultiParamUndo(oldVals);
    renderAllPlugins();
};
