// ============================================================
// PRESET SYSTEM
// Plugin presets, snapshots, and global presets
// ============================================================
// ── Preset Browser ──
var presetPluginId = null;
var presetSaveType = 'preset'; // 'preset' or 'snapshot'
var presetFilterType = 'all';  // 'all', 'preset', 'snapshot'
function getPresetPluginName(plugId) {
    for (var i = 0; i < pluginBlocks.length; i++) {
        if (pluginBlocks[i].id === plugId) return pluginBlocks[i].name;
    }
    return 'Unknown';
}
function openPresetBrowser(plugId, saveType) {
    presetPluginId = plugId;
    presetSaveType = saveType || 'preset';
    presetFilterType = 'all';
    var pName = getPresetPluginName(plugId);
    document.getElementById('presetModalTitle').textContent = pName + ' \u2014 Library';
    document.getElementById('presetNameInput').value = '';
    // Reset search
    var searchEl = document.getElementById('presetSearch');
    if (searchEl) { searchEl.value = ''; }
    if (typeof presetSearchText !== 'undefined') presetSearchText = '';
    // Sync type toggle
    document.querySelectorAll('.preset-type-btn').forEach(function (b) {
        b.classList.toggle('on', b.dataset.savetype === presetSaveType);
    });
    document.getElementById('presetModal').classList.add('vis');
    // Update filter tab visuals
    document.querySelectorAll('#presetModal .preset-filter').forEach(function (btn) {
        btn.classList.toggle('on', btn.dataset.filter === 'all');
    });
    refreshPresetList();
}
function closePresetBrowser() {
    document.getElementById('presetModal').classList.remove('vis');
    presetPluginId = null;
}
function refreshPresetList() {
    var body = document.getElementById('presetBody');
    var info = document.getElementById('presetInfo');
    body.innerHTML = '<div class="preset-empty">Loading...</div>';
    if (!(window.__JUCE__ && window.__JUCE__.backend)) {
        body.innerHTML = '<div class="preset-empty">No backend connected</div>';
        info.textContent = '0 items';
        return;
    }
    var pName = getPresetPluginName(presetPluginId);
    var fn = window.__juceGetNativeFunction('getPluginPresets');
    fn(pName).then(function (names) {
        if (!names || !names.length) {
            body.innerHTML = '<div class="preset-empty">No saved presets or snapshots</div>';
            info.textContent = '0 items';
            return;
        }
        // Load each preset to check its type
        var loadFn = window.__juceGetNativeFunction('loadPluginPreset');
        var items = [];
        var loaded = 0;
        names.forEach(function (n) {
            loadFn(pName, n).then(function (jsonStr) {
                var type = 'preset'; // default for legacy presets without type field
                if (jsonStr) {
                    try { var d = JSON.parse(jsonStr); if (d.type) type = d.type; } catch (e) { }
                }
                items.push({ name: n, type: type });
                loaded++;
                if (loaded === names.length) renderPresetItems(items);
            }).catch(function () {
                items.push({ name: n, type: 'preset' });
                loaded++;
                if (loaded === names.length) renderPresetItems(items);
            });
        });
    });
}
function renderPresetItems(items) {
    var body = document.getElementById('presetBody');
    var info = document.getElementById('presetInfo');
    // Apply type filter
    var filtered = items;
    if (presetFilterType !== 'all') {
        filtered = items.filter(function (it) { return it.type === presetFilterType; });
    }
    // Apply search filter
    if (typeof presetSearchText === 'string' && presetSearchText) {
        filtered = filtered.filter(function (it) { return it.name.toLowerCase().indexOf(presetSearchText) >= 0; });
    }
    var sorted = filtered.slice().sort(function (a, b) { return a.name.localeCompare(b.name); });
    info.textContent = sorted.length + ' of ' + items.length + ' item' + (items.length !== 1 ? 's' : '');
    if (!sorted.length) {
        body.innerHTML = '<div class="preset-empty">' + (presetSearchText ? 'No matches for "' + escHtml(presetSearchText) + '"' : 'No ' + (presetFilterType === 'all' ? 'saved items' : presetFilterType + 's')) + '</div>';
        return;
    }
    var h = '';
    sorted.forEach(function (it) {
        var badgeClass = it.type === 'snapshot' ? 'type-snapshot' : 'type-preset';
        h += '<div class="preset-row" data-pname="' + escHtml(it.name) + '">';
        h += '<span class="preset-type-badge ' + badgeClass + '">' + it.type + '</span>';
        h += '<span class="preset-name">' + escHtml(it.name) + '</span>';
        h += '<button class="preset-del" data-pdel="' + escHtml(it.name) + '">&times;</button>';
        h += '</div>';
    });
    body.innerHTML = h;
    body.querySelectorAll('.preset-row').forEach(function (row) {
        row.onclick = function (e) {
            if (e.target.closest('[data-pdel]')) return;
            loadPreset(row.dataset.pname);
        };
    });
    // Delete with confirmation
    body.querySelectorAll('[data-pdel]').forEach(function (btn) {
        var confirmTimer = null;
        btn.onclick = function (e) {
            e.stopPropagation();
            if (btn._confirming) {
                clearTimeout(confirmTimer);
                btn._confirming = false;
                deletePreset(btn.dataset.pdel);
            } else {
                btn._confirming = true;
                btn.textContent = 'Delete?';
                btn.style.color = '#e55';
                btn.style.borderColor = '#e55';
                confirmTimer = setTimeout(function () {
                    btn._confirming = false;
                    btn.innerHTML = '&times;';
                    btn.style.color = '';
                    btn.style.borderColor = '';
                }, 2000);
            }
        };
    });
    // Store items for filter changes
    body._allItems = items;
}
function savePresetFromInput() {
    var nameInput = document.getElementById('presetNameInput');
    var name = nameInput.value.trim();
    if (!name) { nameInput.focus(); return; }
    var pb = null;
    for (var i = 0; i < pluginBlocks.length; i++) {
        if (pluginBlocks[i].id === presetPluginId) { pb = pluginBlocks[i]; break; }
    }
    if (!pb) return;
    // Build preset data by param index
    var data = { pluginName: pb.name, type: presetSaveType, params: {} };
    pb.params.forEach(function (p) {
        data.params[p.realIndex] = { name: p.name, value: p.v, locked: p.lk || false, alk: p.alk || false };
    });
    var fn = window.__juceGetNativeFunction('savePluginPreset');
    fn(pb.name, name, JSON.stringify(data)).then(function () {
        nameInput.value = '';
        refreshPresetList();
    });
}
function loadPreset(presetName) {
    var pb = null;
    for (var i = 0; i < pluginBlocks.length; i++) {
        if (pluginBlocks[i].id === presetPluginId) { pb = pluginBlocks[i]; break; }
    }
    if (!pb) return;
    if (!(window.__JUCE__ && window.__JUCE__.backend)) return;
    var fn = window.__juceGetNativeFunction('loadPluginPreset');
    fn(pb.name, presetName).then(function (jsonStr) {
        if (!jsonStr) return;
        try {
            var data = JSON.parse(jsonStr);
            if (!data.params) return;
            // Capture old values before applying preset
            var oldVals = [];
            pb.params.forEach(function (p) { oldVals.push({ id: p.id, val: p.v }); });
            var setParamFn = window.__juceGetNativeFunction('setParam');
            for (var idx in data.params) {
                var entry = data.params[idx];
                var val = (typeof entry === 'object') ? entry.value : entry;
                var savedLk = (typeof entry === 'object') ? entry.locked : false;
                var savedAlk = (typeof entry === 'object') ? entry.alk : false;
                for (var pi = 0; pi < pb.params.length; pi++) {
                    if (pb.params[pi].realIndex === parseInt(idx)) {
                        var p = pb.params[pi];
                        // Restore lock states
                        p.lk = !!savedLk;
                        p.alk = !!savedAlk;
                        // Apply value (even if locked — we're loading a preset)
                        p.v = val;
                        if (p.hostId !== undefined) setParamFn(p.hostId, p.realIndex, p.v);
                        break;
                    }
                }
            }
            pushMultiParamUndo(oldVals);
            renderAllPlugins();
            closePresetBrowser();
            // Visual confirmation: flash the plugin card + toast
            showToast('Preset loaded: ' + presetName, 'success', 2500);
            var card = document.querySelector('.pcard[data-plugid="' + pb.id + '"]');
            if (card) { card.classList.remove('preset-flash'); void card.offsetWidth; card.classList.add('preset-flash'); }
        } catch (e) {
            console.log('Preset parse error:', e);
            showToast('Failed to load preset: ' + e.message, 'error', 4000);
        }
    });
}
function deletePreset(presetName) {
    var pName = getPresetPluginName(presetPluginId);
    var fn = window.__juceGetNativeFunction('deletePluginPreset');
    fn(pName, presetName).then(function () {
        refreshPresetList();
    });
}
document.getElementById('presetModalClose').onclick = closePresetBrowser;
document.getElementById('presetModal').onclick = function (e) {
    if (e.target === this) closePresetBrowser();
};
document.getElementById('presetSaveBtn').onclick = function () {
    savePresetFromInput();
    // Flash save button green
    var btn = document.getElementById('presetSaveBtn');
    btn.textContent = '\u2713 Saved';
    btn.style.background = '#4a8';
    setTimeout(function () { btn.textContent = 'Save'; btn.style.background = ''; }, 1200);
};
document.getElementById('presetNameInput').onkeydown = function (e) {
    if (e.key === 'Enter') savePresetFromInput();
};
// Type toggle wiring
document.querySelectorAll('.preset-type-btn').forEach(function (btn) {
    btn.onclick = function () {
        presetSaveType = btn.dataset.savetype;
        document.querySelectorAll('.preset-type-btn').forEach(function (b) { b.classList.toggle('on', b === btn); });
    };
});
// Search wiring
var presetSearchText = '';
document.getElementById('presetSearch').oninput = function () {
    presetSearchText = this.value.toLowerCase();
    var body = document.getElementById('presetBody');
    if (body._allItems) renderPresetItems(body._allItems);
};
// Filter tab wiring
document.querySelectorAll('#presetModal .preset-filter').forEach(function (btn) {
    btn.onclick = function () {
        presetFilterType = btn.dataset.filter;
        document.querySelectorAll('#presetModal .preset-filter').forEach(function (b) { b.classList.toggle('on', b === btn); });
        var body = document.getElementById('presetBody');
        if (body._allItems) renderPresetItems(body._allItems);
    };
});

// Plugin context menu wiring — Save as Preset / Save as Snapshot
function syncTypeToggle(type) {
    document.querySelectorAll('.preset-type-btn').forEach(function (b) {
        b.classList.toggle('on', b.dataset.savetype === type);
    });
}
document.getElementById('pcSavePreset').onclick = function () {
    presetSaveType = 'preset';
    syncTypeToggle('preset');
    openPresetBrowser(plugCtxPluginId, 'preset');
};
document.getElementById('pcSaveSnapshot').onclick = function () {
    presetSaveType = 'snapshot';
    syncTypeToggle('snapshot');
    openPresetBrowser(plugCtxPluginId, 'snapshot');
};
document.getElementById('pcLoadState').onclick = function () {
    openPresetBrowser(plugCtxPluginId, 'preset');
};

// ============================================================
// SNAPSHOT LIBRARY (for morph pad — loads presets/snapshots from any plugin)
// ============================================================
var snapLibBlockId = null;   // which morph pad block requested the library
var snapLibFilter = 'all';
var snapLibSearch = '';
var snapLibAllEntries = [];

function openSnapshotLibrary(blockId) {
    snapLibBlockId = blockId;
    snapLibFilter = 'all';
    snapLibSearch = '';
    document.getElementById('snapLibSearch').value = '';
    document.getElementById('snapLibModal').classList.add('vis');
    // Reset filter tabs
    document.querySelectorAll('#snapLibModal [data-slfilter]').forEach(function (btn) {
        btn.classList.toggle('on', btn.dataset.slfilter === 'all');
    });
    refreshSnapshotLibrary();
}

function closeSnapshotLibrary() {
    document.getElementById('snapLibModal').classList.remove('vis');
    snapLibBlockId = null;
}

function refreshSnapshotLibrary() {
    var body = document.getElementById('snapLibBody');
    var info = document.getElementById('snapLibInfo');
    body.innerHTML = '<div class="preset-empty">Loading...</div>';
    snapLibAllEntries = [];
    if (!(window.__JUCE__ && window.__JUCE__.backend)) {
        body.innerHTML = '<div class="preset-empty">No backend connected</div>';
        info.textContent = '0 items';
        return;
    }
    // Gather presets from ALL loaded plugins
    var pending = pluginBlocks.length;
    if (pending === 0) {
        body.innerHTML = '<div class="preset-empty">No plugins loaded</div>';
        info.textContent = '0 items';
        return;
    }
    var getPresetsFn = window.__juceGetNativeFunction('getPluginPresets');
    var loadPresetFn = window.__juceGetNativeFunction('loadPluginPreset');
    pluginBlocks.forEach(function (pb) {
        getPresetsFn(pb.name).then(function (names) {
            if (!names || !names.length) { pending--; if (pending === 0) renderSnapLibItems(); return; }
            var subPending = names.length;
            names.forEach(function (n) {
                loadPresetFn(pb.name, n).then(function (jsonStr) {
                    var type = 'preset';
                    if (jsonStr) {
                        try { var d = JSON.parse(jsonStr); if (d.type) type = d.type; } catch (e) { }
                    }
                    snapLibAllEntries.push({
                        name: n,
                        type: type,
                        pluginName: pb.name,
                        pluginId: pb.id,
                        hostId: pb.hostId
                    });
                    subPending--;
                    if (subPending === 0) { pending--; if (pending === 0) renderSnapLibItems(); }
                }).catch(function () {
                    snapLibAllEntries.push({ name: n, type: 'preset', pluginName: pb.name, pluginId: pb.id, hostId: pb.hostId });
                    subPending--;
                    if (subPending === 0) { pending--; if (pending === 0) renderSnapLibItems(); }
                });
            });
        }).catch(function () {
            pending--;
            if (pending === 0) renderSnapLibItems();
        });
    });
}

function renderSnapLibItems() {
    var body = document.getElementById('snapLibBody');
    var info = document.getElementById('snapLibInfo');
    var filtered = snapLibAllEntries;
    // Type filter
    if (snapLibFilter !== 'all') {
        filtered = filtered.filter(function (it) { return it.type === snapLibFilter; });
    }
    // Search filter
    if (snapLibSearch) {
        var q = snapLibSearch.toLowerCase();
        filtered = filtered.filter(function (it) {
            return it.name.toLowerCase().indexOf(q) >= 0 ||
                it.pluginName.toLowerCase().indexOf(q) >= 0;
        });
    }
    var sorted = filtered.slice().sort(function (a, b) {
        if (a.pluginName !== b.pluginName) return a.pluginName.localeCompare(b.pluginName);
        return a.name.localeCompare(b.name);
    });
    info.textContent = sorted.length + ' item' + (sorted.length !== 1 ? 's' : '');
    if (!sorted.length) {
        body.innerHTML = '<div class="preset-empty">No matching items</div>';
        return;
    }
    var h = '';
    sorted.forEach(function (it, idx) {
        var badgeClass = it.type === 'snapshot' ? 'type-snapshot' : 'type-preset';
        h += '<div class="preset-row" data-sli="' + idx + '">';
        h += '<span class="preset-type-badge ' + badgeClass + '">' + it.type + '</span>';
        h += '<div class="plug-info"><div class="preset-name">' + escHtml(it.name) + '</div>';
        h += '<div class="preset-sub">' + escHtml(it.pluginName) + '</div></div>';
        h += '</div>';
    });
    body.innerHTML = h;
    body.querySelectorAll('.preset-row').forEach(function (row) {
        row.onclick = function () {
            var idx = parseInt(row.dataset.sli);
            var entry = sorted[idx];
            if (!entry) return;
            loadSnapshotFromLibrary(entry);
        };
    });
}

function loadSnapshotFromLibrary(entry) {
    // Load the preset data and create a snapshot on the morph pad
    if (!(window.__JUCE__ && window.__JUCE__.backend)) return;
    var b = findBlock(snapLibBlockId);
    if (!b || b.mode !== 'morph_pad') return;
    if (!b.snapshots) b.snapshots = [];
    if (b.snapshots.length >= 12) { closeSnapshotLibrary(); return; }

    var loadFn = window.__juceGetNativeFunction('loadPluginPreset');
    loadFn(entry.pluginName, entry.name).then(function (jsonStr) {
        if (!jsonStr) return;
        try {
            var data = JSON.parse(jsonStr);
            if (!data.params) return;
            // Build snapshot values keyed by paramId (hostId:paramIndex)
            var vals = {};
            b.targets.forEach(function (pid) {
                var p = PMap[pid];
                if (!p) return;
                // Check if this param belongs to the same plugin
                if (p.hostId === entry.hostId || p.hostId === entry.pluginId) {
                    var savedParam = data.params[p.realIndex];
                    if (savedParam !== undefined) {
                        vals[pid] = (typeof savedParam === 'object') ? savedParam.value : savedParam;
                    } else {
                        vals[pid] = p.v; // fallback to current value
                    }
                } else {
                    // Different plugin — use current value
                    vals[pid] = p.v;
                }
            });
            var spos = getSnapSectorPos(b.snapshots.length);
            b.snapshots.push({
                x: spos.x, y: spos.y,
                values: vals,
                name: entry.name,
                source: entry.pluginName
            });
            renderSingleBlock(snapLibBlockId);
            syncBlocksToHost();
            // Flash feedback
            var pad = document.querySelector('.morph-pad[data-b="' + snapLibBlockId + '"]');
            if (pad) { pad.classList.remove('snap-flash'); void pad.offsetWidth; pad.classList.add('snap-flash'); }
            var chips = document.querySelectorAll('.snap-chip[data-b="' + snapLibBlockId + '"]');
            if (chips.length) { var last = chips[chips.length - 1]; last.classList.add('just-added'); setTimeout(function () { last.classList.remove('just-added'); }, 600); }
            closeSnapshotLibrary();
        } catch (e) { console.log('Snapshot load error:', e); }
    });
}

// Snapshot Library modal wiring
document.getElementById('snapLibClose').onclick = closeSnapshotLibrary;
document.getElementById('snapLibModal').onclick = function (e) {
    if (e.target === this) closeSnapshotLibrary();
};
document.getElementById('snapLibSearch').oninput = function () {
    snapLibSearch = this.value;
    renderSnapLibItems();
};
document.querySelectorAll('#snapLibModal [data-slfilter]').forEach(function (btn) {
    btn.onclick = function () {
        snapLibFilter = btn.dataset.slfilter;
        document.querySelectorAll('#snapLibModal [data-slfilter]').forEach(function (b) { b.classList.toggle('on', b === btn); });
        renderSnapLibItems();
    };
});

// ── Global Preset System ──
var currentGlobalPresetName = null;
function updateGpNameDisplay() {
    document.getElementById('gpName').textContent = currentGlobalPresetName || '\u2014';
}
function openGlobalPresetBrowser() {
    document.getElementById('gpNameInput').value = currentGlobalPresetName || '';
    var gpSearchEl = document.getElementById('gpSearch');
    if (gpSearchEl) gpSearchEl.value = '';
    document.getElementById('globalPresetModal').classList.add('vis');
    refreshGlobalPresetList();
}
var gpLoadInProgress = false;
function closeGlobalPresetBrowser() {
    if (gpLoadInProgress) return; // Prevent closing while plugins are loading
    document.getElementById('globalPresetModal').classList.remove('vis');
}
function refreshGlobalPresetList() {
    var body = document.getElementById('gpBody');
    var info = document.getElementById('gpInfo');
    body.innerHTML = '<div class="preset-empty">Loading...</div>';
    if (!(window.__JUCE__ && window.__JUCE__.backend)) {
        body.innerHTML = '<div class="preset-empty">No backend connected</div>';
        info.textContent = '0 presets';
        return;
    }
    var fn = window.__juceGetNativeFunction('getGlobalPresets');
    fn().then(function (names) {
        if (!names || !names.length) {
            body.innerHTML = '<div class="preset-empty">No saved global presets</div>';
            info.textContent = '0 presets';
            body._gpNames = [];
            return;
        }
        var sorted = names.slice().sort();
        body._gpNames = sorted; // store for nav arrows
        // Apply search filter
        var gpSearchText = document.getElementById('gpSearch').value.toLowerCase();
        var filtered = sorted;
        if (gpSearchText) {
            filtered = sorted.filter(function (n) { return n.toLowerCase().indexOf(gpSearchText) >= 0; });
        }
        info.textContent = filtered.length + ' of ' + sorted.length + ' preset' + (sorted.length !== 1 ? 's' : '');
        if (!filtered.length) {
            body.innerHTML = '<div class="preset-empty">No matches for "' + escHtml(gpSearchText) + '"</div>';
            return;
        }
        var h = '';
        filtered.forEach(function (n) {
            h += '<div class="preset-row' + (n === currentGlobalPresetName ? ' active' : '') + '" data-gpname="' + escHtml(n) + '">';
            h += '<span class="preset-name">' + escHtml(n) + '</span>';
            h += '<button class="preset-del" data-gpdel="' + escHtml(n) + '">&times;</button>';
            h += '</div>';
        });
        body.innerHTML = h;
        body.querySelectorAll('.preset-row').forEach(function (row) {
            row.onclick = function (e) {
                if (e.target.closest('[data-gpdel]')) return;
                loadGlobalPreset(row.dataset.gpname);
            };
        });
        // Delete with confirmation
        body.querySelectorAll('[data-gpdel]').forEach(function (btn) {
            var confirmTimer = null;
            btn.onclick = function (e) {
                e.stopPropagation();
                if (btn._confirming) {
                    clearTimeout(confirmTimer);
                    btn._confirming = false;
                    deleteGlobalPreset(btn.dataset.gpdel);
                } else {
                    btn._confirming = true;
                    btn.textContent = 'Delete?';
                    btn.style.color = '#e55';
                    btn.style.borderColor = '#e55';
                    confirmTimer = setTimeout(function () {
                        btn._confirming = false;
                        btn.innerHTML = '&times;';
                        btn.style.color = '';
                        btn.style.borderColor = '';
                    }, 2000);
                }
            };
        });
    });
}
function buildGlobalPresetData() {
    return {
        version: 1,
        routingMode: routingMode,
        pluginOrder: pluginBlocks.map(function (pb) { return pb.id; }),
        plugins: pluginBlocks.map(function (pb) {
            var paramData = {};
            pb.params.forEach(function (p) {
                paramData[p.realIndex] = { name: p.name, value: p.v, locked: p.lk || false };
            });
            return { name: pb.name, path: pb.path || '', hostId: pb.hostId, params: paramData, bypassed: pb.bypassed || false, expanded: pb.expanded, busId: pb.busId || 0 };
        }),
        blocks: blocks.map(function (b) {
            return {
                id: b.id, mode: b.mode, colorIdx: b.colorIdx,
                targets: Array.from(b.targets), targetBases: b.targetBases || {}, targetRanges: b.targetRanges || {}, targetRangeBases: b.targetRangeBases || {},
                trigger: b.trigger, beatDiv: b.beatDiv,
                midiMode: b.midiMode, midiNote: b.midiNote, midiCC: b.midiCC, midiCh: b.midiCh,
                velScale: b.velScale, threshold: b.threshold, audioSrc: b.audioSrc,
                rMin: b.rMin, rMax: b.rMax, rangeMode: b.rangeMode, polarity: b.polarity || 'bipolar',
                quantize: b.quantize, qSteps: b.qSteps,
                movement: b.movement, glideMs: b.glideMs,
                envAtk: b.envAtk, envRel: b.envRel, envSens: b.envSens, envInvert: b.envInvert,
                loopMode: b.loopMode, sampleSpeed: b.sampleSpeed, sampleReverse: b.sampleReverse, jumpMode: b.jumpMode,
                sampleName: b.sampleName || '', sampleWaveform: b.sampleWaveform || null,
                // Morph Pad fields
                snapshots: (b.snapshots || []).map(function (s) { return { x: s.x, y: s.y, name: s.name || '', source: s.source || '', values: s.values || {} }; }),
                playheadX: b.playheadX || 0.5, playheadY: b.playheadY || 0.5,
                morphMode: b.morphMode || 'manual', exploreMode: b.exploreMode || 'wander',
                lfoShape: b.lfoShape || 'circle', lfoDepth: b.lfoDepth != null ? b.lfoDepth : 80, lfoRotation: b.lfoRotation || 0, morphSpeed: b.morphSpeed || 50,
                morphAction: b.morphAction || 'jump', stepOrder: b.stepOrder || 'cycle',
                morphSource: b.morphSource || 'midi', jitter: b.jitter || 0,
                morphGlide: b.morphGlide || 200,
                morphTempoSync: !!b.morphTempoSync, morphSyncDiv: b.morphSyncDiv || '1/4',
                snapRadius: b.snapRadius || 100,
                shapeType: b.shapeType || 'circle', shapeTracking: b.shapeTracking || 'horizontal',
                shapeSize: b.shapeSize != null ? b.shapeSize : 80, shapeSpin: b.shapeSpin || 0,
                shapeSpeed: b.shapeSpeed || 50, shapeDepth: b.shapeDepth || 50,
                shapeRange: b.shapeRange || 'relative', shapePolarity: b.shapePolarity || 'bipolar',
                shapeTempoSync: !!b.shapeTempoSync, shapeSyncDiv: b.shapeSyncDiv || '1/4', shapeTrigger: b.shapeTrigger || 'free',
                clockSource: b.clockSource || 'daw',
                laneTool: b.laneTool || 'draw', laneGrid: b.laneGrid || '1/8',
                lanes: (b.lanes || []).map(function (lane) {
                    return {
                        pids: lane.pids || (lane.pid ? [lane.pid] : []), color: lane.color || '', collapsed: !!lane.collapsed,
                        pts: (lane.pts || []).map(function (p) { return { x: p.x, y: p.y }; }),
                        loopLen: lane.loopLen || '1/1', phase: lane.phase || 0, depth: lane.depth != null ? lane.depth : 100,
                        slew: lane.slew || 0, warp: lane.warp || 0, interp: lane.interp || 'smooth',
                        playMode: lane.playMode || 'forward', freeSecs: lane.freeSecs || 4,
                        synced: lane.synced !== false, muted: !!lane.muted
                    };
                }),
                enabled: b.enabled !== false, expanded: b.expanded
            };
        }),
        bc: bc, actId: actId,
        internalBpm: internalBpm,
        autoLocate: autoLocate,
        busVolumes: busVolumes.slice(),
        busMutes: busMutes.slice(),
        busSolos: busSolos.slice()
    };
}
function saveGlobalPresetFromInput() {
    var nameInput = document.getElementById('gpNameInput');
    var name = nameInput.value.trim();
    if (!name) { nameInput.focus(); return; }
    var data = buildGlobalPresetData();
    var fn = window.__juceGetNativeFunction('saveGlobalPreset');
    fn(name, JSON.stringify(data)).then(function () {
        currentGlobalPresetName = name;
        updateGpNameDisplay();
        clearGpDirty();
        nameInput.value = '';
        refreshGlobalPresetList();
    });
}
function loadGlobalPreset(presetName) {
    if (!(window.__JUCE__ && window.__JUCE__.backend)) return;
    var fn = window.__juceGetNativeFunction('loadGlobalPreset');
    fn(presetName).then(function (jsonStr) {
        if (!jsonStr) return;
        try {
            var data = JSON.parse(jsonStr);
            applyGlobalPreset(data, presetName);
        } catch (e) { console.log('Global preset parse error:', e); }
    });
}
function applyGlobalPreset(data, presetName) {
    // Remove all current plugins
    var removeFn = (window.__JUCE__ && window.__JUCE__.backend) ? window.__juceGetNativeFunction('removePlugin') : null;
    pluginBlocks.forEach(function (pb) {
        if (removeFn) removeFn(pb.hostId || pb.id);
        pb.params.forEach(function (p) { delete PMap[p.id]; });
    });
    pluginBlocks = [];
    blocks = [];
    bc = 0;
    actId = null;
    assignMode = null;

    if (!data.plugins || !data.plugins.length) {
        currentGlobalPresetName = presetName;
        updateGpNameDisplay();
        renderAllPlugins(); renderBlocks(); updCounts();
        closeGlobalPresetBrowser();
        return;
    }

    // Load plugins sequentially
    var loadPlugin = (window.__JUCE__ && window.__JUCE__.backend) ? window.__juceGetNativeFunction('loadPlugin') : null;
    var setParamFn = (window.__JUCE__ && window.__JUCE__.backend) ? window.__juceGetNativeFunction('setParam') : null;
    var setBypassFn = (window.__JUCE__ && window.__JUCE__.backend) ? window.__juceGetNativeFunction('setPluginBypass') : null;
    var getStateFn = (window.__JUCE__ && window.__JUCE__.backend) ? window.__juceGetNativeFunction('getFullState') : null;

    // We need to use getFullState after loading plugins to get the actual params
    // Build a chain of plugin loads
    var pluginPaths = data.plugins.map(function (p) { return p.path; });
    var loadIdx = 0;
    var loadFailures = [];
    gpLoadInProgress = true;

    // Show progress in modal body
    var gpBody = document.getElementById('gpBody');
    function updateGpProgress() {
        gpBody.innerHTML = '<div class="preset-empty"><div class="loading-dots" style="font-size:14px">Loading plugin ' + (loadIdx + 1) + ' of ' + pluginPaths.length + '</div>' +
            '<div style="margin-top:8px;font-size:11px;opacity:0.6">' + escHtml(pluginPaths[loadIdx].split(/[\\/]/).pop()) + '</div></div>';
    }

    function loadNextPlugin() {
        if (loadIdx >= pluginPaths.length) {
            gpLoadInProgress = false;
            // All plugins loaded — now fetch state and apply params
            if (getStateFn) {
                getStateFn().then(function (result) {
                    if (result && result.plugins) {
                        // Rebuild pluginBlocks from hosted plugins
                        pluginBlocks = [];
                        PMap = {};
                        result.plugins.forEach(function (plug, idx) {
                            var savedPlug = data.plugins[idx] || {};
                            var params = (plug.params || []).map(function (p) {
                                var fid = plug.id + ':' + p.index;
                                var savedParam = savedPlug.params ? savedPlug.params[p.index] : null;
                                var val = savedParam ? (typeof savedParam === 'object' ? savedParam.value : savedParam) : p.value;
                                var locked = savedParam && savedParam.locked ? true : false;
                                var param = { id: fid, name: p.name, v: val, disp: p.disp || '', lk: locked, alk: false, realIndex: p.index, hostId: plug.id };
                                PMap[fid] = param;
                                // Apply param values to C++
                                if (setParamFn) setParamFn(plug.id, p.index, val);
                                return param;
                            });
                            pluginBlocks.push({
                                id: plug.id, hostId: plug.id,
                                name: plug.name, path: savedPlug.path || '',
                                params: params,
                                expanded: savedPlug.expanded !== false,
                                bypassed: savedPlug.bypassed || false,
                                searchFilter: ''
                            });
                            // Apply bypass
                            if (savedPlug.bypassed && setBypassFn) setBypassFn(plug.id, true);
                        });

                        // Restore blocks with re-mapped target IDs
                        if (data.blocks && data.blocks.length) {
                            // Build old-to-new ID mapping
                            var idMap = {};
                            for (var mi = 0; mi < data.plugins.length && mi < result.plugins.length; mi++) {
                                var oldId = data.plugins[mi].hostId;
                                var newId = result.plugins[mi].id;
                                if (oldId !== undefined && oldId !== newId) {
                                    idMap[oldId] = newId;
                                }
                            }
                            blocks = data.blocks.map(function (sb) {
                                var tSet = new Set();
                                if (sb.targets) sb.targets.forEach(function (t) {
                                    // Remap target ID if needed
                                    var parts = t.split(':');
                                    if (parts.length === 2 && idMap[parseInt(parts[0])] !== undefined) {
                                        t = idMap[parseInt(parts[0])] + ':' + parts[1];
                                    }
                                    if (PMap[t]) tSet.add(t);
                                });
                                // Remap snapshot values keys too
                                var remappedSnaps = (sb.snapshots || []).map(function (s) {
                                    var newVals = {};
                                    if (s.values) {
                                        for (var k in s.values) {
                                            var kp = k.split(':');
                                            var nk = k;
                                            if (kp.length === 2 && idMap[parseInt(kp[0])] !== undefined) {
                                                nk = idMap[parseInt(kp[0])] + ':' + kp[1];
                                            }
                                            newVals[nk] = s.values[k];
                                        }
                                    }
                                    return { x: s.x || 0.5, y: s.y || 0.5, name: s.name || '', source: s.source || '', values: newVals };
                                });
                                // Remap keyed maps (targetBases, targetRanges, targetRangeBases)
                                function remapKeyedMap(obj) {
                                    if (!obj) return {};
                                    var out = {};
                                    for (var k in obj) {
                                        var kp = k.split(':');
                                        var nk = k;
                                        if (kp.length === 2 && idMap[parseInt(kp[0])] !== undefined) {
                                            nk = idMap[parseInt(kp[0])] + ':' + kp[1];
                                        }
                                        out[nk] = obj[k];
                                    }
                                    return out;
                                }
                                // Remap lane PIDs
                                function remapPid(pid) {
                                    if (!pid) return pid;
                                    var pp = pid.split(':');
                                    if (pp.length === 2 && idMap[parseInt(pp[0])] !== undefined) {
                                        return idMap[parseInt(pp[0])] + ':' + pp[1];
                                    }
                                    return pid;
                                }
                                return {
                                    id: sb.id, mode: sb.mode || 'randomize', targets: tSet,
                                    targetBases: remapKeyedMap(sb.targetBases),
                                    targetRanges: remapKeyedMap(sb.targetRanges),
                                    targetRangeBases: remapKeyedMap(sb.targetRangeBases),
                                    colorIdx: sb.colorIdx || 0,
                                    trigger: sb.trigger || 'manual', beatDiv: sb.beatDiv || '1/4',
                                    midiMode: sb.midiMode || 'any_note', midiNote: sb.midiNote || 60, midiCC: sb.midiCC || 1, midiCh: sb.midiCh || 0,
                                    velScale: sb.velScale || false, threshold: sb.threshold || -12, audioSrc: sb.audioSrc || 'main',
                                    rMin: sb.rMin || 0, rMax: sb.rMax !== undefined ? sb.rMax : 100,
                                    rangeMode: sb.rangeMode || 'absolute', polarity: sb.polarity || 'bipolar',
                                    quantize: sb.quantize || false, qSteps: sb.qSteps || 12,
                                    movement: sb.movement || 'instant', glideMs: sb.glideMs || 200,
                                    envAtk: sb.envAtk || 10, envRel: sb.envRel || 100, envSens: sb.envSens || 50, envInvert: sb.envInvert || false,
                                    loopMode: sb.loopMode || 'loop', sampleSpeed: sb.sampleSpeed || 1.0,
                                    sampleReverse: sb.sampleReverse || false, jumpMode: sb.jumpMode || 'restart',
                                    sampleName: sb.sampleName || '', sampleWaveform: sb.sampleWaveform || null,
                                    // Morph Pad fields
                                    snapshots: remappedSnaps,
                                    playheadX: sb.playheadX || 0.5, playheadY: sb.playheadY || 0.5,
                                    morphMode: sb.morphMode || 'manual', exploreMode: (sb.exploreMode === 'lfo' ? 'shapes' : sb.exploreMode) || 'wander',
                                    lfoShape: sb.lfoShape || 'circle', lfoDepth: sb.lfoDepth != null ? sb.lfoDepth : 80, lfoRotation: sb.lfoRotation || 0, morphSpeed: sb.morphSpeed || 50,
                                    morphAction: sb.morphAction || 'jump', stepOrder: sb.stepOrder || 'cycle',
                                    morphSource: sb.morphSource || 'midi', jitter: sb.jitter || 0,
                                    morphGlide: sb.morphGlide || 200,
                                    morphTempoSync: !!sb.morphTempoSync, morphSyncDiv: sb.morphSyncDiv || '1/4',
                                    snapRadius: sb.snapRadius || 100,
                                    shapeType: sb.shapeType || 'circle', shapeTracking: sb.shapeTracking || 'horizontal',
                                    shapeSize: sb.shapeSize != null ? sb.shapeSize : 80, shapeSpin: sb.shapeSpin || 0,
                                    shapeSpeed: sb.shapeSpeed || 50, shapeDepth: sb.shapeDepth || 50,
                                    shapeRange: sb.shapeRange || 'relative', shapePolarity: sb.shapePolarity || 'bipolar',
                                    shapeTempoSync: !!sb.shapeTempoSync, shapeSyncDiv: sb.shapeSyncDiv || '1/4', shapeTrigger: sb.shapeTrigger || 'free',
                                    clockSource: sb.clockSource || 'daw',
                                    laneTool: sb.laneTool || 'draw', laneGrid: sb.laneGrid || '1/8',
                                    lanes: (sb.lanes || []).map(function (lane) {
                                        var lPids = lane.pids || (lane.pid ? [lane.pid] : []);
                                        return {
                                            pids: lPids.map(remapPid), color: lane.color || '', collapsed: !!lane.collapsed,
                                            pts: (lane.pts || []).map(function (p) { return { x: p.x, y: p.y }; }),
                                            loopLen: lane.loopLen || '1/1', phase: lane.phase || 0, depth: lane.depth != null ? lane.depth : 100,
                                            slew: lane.slew || 0, warp: lane.warp || 0, interp: lane.interp || 'smooth',
                                            playMode: lane.playMode || 'forward', freeSecs: lane.freeSecs || 4,
                                            synced: lane.synced !== false, muted: !!lane.muted
                                        };
                                    }),
                                    enabled: sb.enabled !== false, expanded: sb.expanded !== false
                                };
                            });
                            bc = data.bc || blocks.reduce(function (m, b) { return Math.max(m, b.id); }, 0);
                            actId = data.actId || (blocks.length > 0 ? blocks[0].id : null);
                        } else {
                            addBlock('randomize');
                        }
                    }
                    currentGlobalPresetName = presetName;
                    updateGpNameDisplay();
                    // Restore global settings
                    if (data.internalBpm) {
                        internalBpm = data.internalBpm;
                        var bpmInp = document.getElementById('internalBpmInput');
                        if (bpmInp) bpmInp.value = internalBpm;
                    }
                    if (data.autoLocate !== undefined) {
                        autoLocate = data.autoLocate;
                        var alChk = document.getElementById('autoLocateChk');
                        if (alChk) alChk.checked = autoLocate;
                    }

                    // Restore routing mode (sequential/parallel)
                    if (data.routingMode !== undefined) {
                        routingMode = data.routingMode;
                        var setRoutFn = (window.__JUCE__ && window.__JUCE__.backend) ? window.__juceGetNativeFunction('setRoutingMode') : null;
                        if (setRoutFn) setRoutFn(routingMode);
                        // Update routing toggle buttons
                        var seqBtn = document.getElementById('routeSeq');
                        var parBtn = document.getElementById('routePar');
                        if (seqBtn) seqBtn.classList.toggle('on', routingMode === 0);
                        if (parBtn) parBtn.classList.toggle('on', routingMode === 1);
                    }

                    // Restore per-plugin bus assignments
                    var setBusFn = (window.__JUCE__ && window.__JUCE__.backend) ? window.__juceGetNativeFunction('setPluginBus') : null;
                    if (setBusFn && data.plugins) {
                        for (var bi = 0; bi < data.plugins.length && bi < pluginBlocks.length; bi++) {
                            var savedBus = data.plugins[bi].busId || 0;
                            pluginBlocks[bi].busId = savedBus;
                            if (setBusFn) setBusFn(pluginBlocks[bi].id, savedBus);
                        }
                    }

                    // Restore bus mixer state
                    if (data.busVolumes) {
                        var setBvFn = (window.__JUCE__ && window.__JUCE__.backend) ? window.__juceGetNativeFunction('setBusVolume') : null;
                        for (var bvi = 0; bvi < data.busVolumes.length && bvi < busVolumes.length; bvi++) {
                            busVolumes[bvi] = data.busVolumes[bvi];
                            if (setBvFn) setBvFn(bvi, busVolumes[bvi]);
                        }
                    }
                    if (data.busMutes) {
                        var setBmFn = (window.__JUCE__ && window.__JUCE__.backend) ? window.__juceGetNativeFunction('setBusMute') : null;
                        for (var bmi = 0; bmi < data.busMutes.length && bmi < busMutes.length; bmi++) {
                            busMutes[bmi] = data.busMutes[bmi];
                            if (setBmFn) setBmFn(bmi, busMutes[bmi]);
                        }
                    }
                    if (data.busSolos) {
                        var setBsFn = (window.__JUCE__ && window.__JUCE__.backend) ? window.__juceGetNativeFunction('setBusSolo') : null;
                        for (var bsi = 0; bsi < data.busSolos.length && bsi < busSolos.length; bsi++) {
                            busSolos[bsi] = data.busSolos[bsi];
                            if (setBsFn) setBsFn(bsi, busSolos[bsi]);
                        }
                    }

                    // Restore plugin order
                    var reorderFn = (window.__JUCE__ && window.__JUCE__.backend) ? window.__juceGetNativeFunction('reorderPlugins') : null;
                    if (reorderFn) {
                        var ids = pluginBlocks.map(function (pb) { return pb.id; });
                        reorderFn(ids);
                    }

                    renderAllPlugins(); renderBlocks(); updCounts(); syncBlocksToHost(); saveUiStateToHost(); syncExpandedPlugins();
                    clearGpDirty();
                    closeGlobalPresetBrowser();

                    // Show confirmation toast + report failures
                    if (loadFailures.length > 0) {
                        showToast('Preset loaded with errors. Could not load: ' + loadFailures.join(', '), 'error', 6000);
                    } else {
                        showToast('Preset loaded: ' + presetName, 'success', 3000);
                    }
                });
            }
            return;
        }
        // Show progress before loading
        updateGpProgress();
        if (loadPlugin) {
            loadPlugin(pluginPaths[loadIdx]).then(function (result) {
                // Check for load failure
                if (!result || result.error) {
                    loadFailures.push(pluginPaths[loadIdx].split(/[\\/]/).pop().replace(/\.vst3$/i, ''));
                }
                loadIdx++;
                loadNextPlugin();
            }).catch(function () {
                loadFailures.push(pluginPaths[loadIdx].split(/[\\/]/).pop().replace(/\.vst3$/i, ''));
                loadIdx++;
                loadNextPlugin();
            });
        } else {
            loadIdx++;
            loadNextPlugin();
        }
    }
    loadNextPlugin();
}
function deleteGlobalPreset(presetName) {
    var fn = window.__juceGetNativeFunction('deleteGlobalPreset');
    fn(presetName).then(function () {
        if (currentGlobalPresetName === presetName) {
            currentGlobalPresetName = null;
            updateGpNameDisplay();
        }
        refreshGlobalPresetList();
    });
}

// Dirty state tracking
var gpDirty = false;
function markGpDirty() {
    if (!gpDirty && currentGlobalPresetName) {
        gpDirty = true;
        var el = document.getElementById('gpDirty');
        if (el) el.classList.add('on');
    }
}
function clearGpDirty() {
    gpDirty = false;
    var el = document.getElementById('gpDirty');
    if (el) el.classList.remove('on');
}

// Wire header buttons
document.getElementById('gpBrowse').onclick = openGlobalPresetBrowser;
document.getElementById('gpSave').onclick = function () {
    // Quick save: if we have a current name, overwrite. Otherwise open browser.
    if (currentGlobalPresetName) {
        var data = buildGlobalPresetData();
        var fn = window.__juceGetNativeFunction('saveGlobalPreset');
        fn(currentGlobalPresetName, JSON.stringify(data));
        clearGpDirty();
        // Flash feedback
        var btn = document.getElementById('gpSave');
        btn.textContent = '\u2713';
        setTimeout(function () { btn.textContent = 'Save'; }, 800);
    } else {
        openGlobalPresetBrowser();
    }
};

// Nav arrows — cycle through global presets
document.getElementById('gpPrev').onclick = function () { navigateGlobalPreset(-1); };
document.getElementById('gpNext').onclick = function () { navigateGlobalPreset(1); };
function navigateGlobalPreset(dir) {
    if (!(window.__JUCE__ && window.__JUCE__.backend)) return;
    var fn = window.__juceGetNativeFunction('getGlobalPresets');
    fn().then(function (names) {
        if (!names || !names.length) return;
        var sorted = names.slice().sort();
        var idx = sorted.indexOf(currentGlobalPresetName);
        if (idx < 0) {
            // No current preset — load first or last
            idx = dir > 0 ? 0 : sorted.length - 1;
        } else {
            idx = (idx + dir + sorted.length) % sorted.length;
        }
        loadGlobalPreset(sorted[idx]);
    });
}

document.getElementById('gpModalClose').onclick = closeGlobalPresetBrowser;
document.getElementById('globalPresetModal').onclick = function (e) {
    if (e.target === this) closeGlobalPresetBrowser();
};
document.getElementById('gpSaveBtn').onclick = function () {
    saveGlobalPresetFromInput();
    var btn = document.getElementById('gpSaveBtn');
    btn.textContent = '\u2713 Saved';
    btn.style.background = '#4a8';
    setTimeout(function () { btn.textContent = 'Save'; btn.style.background = ''; }, 1200);
};
document.getElementById('gpNameInput').onkeydown = function (e) {
    if (e.key === 'Enter') saveGlobalPresetFromInput();
};
// Global preset search
document.getElementById('gpSearch').oninput = function () {
    refreshGlobalPresetList();
};
