// ============================================================
// UI CONTROLS
// Bypass, mix, scale, auto-locate, add buttons, plugin browser
// ============================================================
// Bypass button — connected to JUCE BYPASS toggle relay
document.getElementById('bypassBtn').onclick = function () {
    this.classList.toggle('on');
    // Send to JUCE backend if available
    if (window.__JUCE__ && window.__JUCE__.getToggleState) {
        try {
            var state = window.__JUCE__.getToggleState('BYPASS');
            if (state) state.setValue(!state.getValue());
        } catch (e) { console.log('Bypass relay not ready'); }
    }
};
// Mix slider — connected to JUCE MIX slider relay
document.getElementById('mixSlider').oninput = function () {
    document.getElementById('mixVal').textContent = this.value + '%';
    // Send to JUCE backend if available
    if (window.__JUCE__ && window.__JUCE__.getSliderState) {
        try {
            var state = window.__JUCE__.getSliderState('MIX');
            if (state) state.setNormalisedValue(this.value / 100.0);
        } catch (e) { console.log('Mix relay not ready'); }
    }
};
// UI Scale — professional: resize JUCE editor window, CSS fills it
var currentScale = 1;
var autoLocate = true;
document.getElementById('scaleSelect').onchange = function () {
    var scale = parseFloat(this.value);
    if (isNaN(scale) || scale < 0.25) scale = 1;
    currentScale = scale;
    if (window.__JUCE__ && window.__JUCE__.backend) {
        var fn = window.__juceGetNativeFunction('setEditorScale');
        fn(scale);
    }
    saveUiStateToHost();
};
function applyScale(scale) {
    currentScale = scale;
    var sel = document.getElementById('scaleSelect');
    for (var i = 0; i < sel.options.length; i++) {
        if (parseFloat(sel.options[i].value) === scale) { sel.selectedIndex = i; break; }
    }
    if (window.__JUCE__ && window.__JUCE__.backend) {
        var fn = window.__juceGetNativeFunction('setEditorScale');
        fn(scale);
    }
}
// Auto-Locate toggle
document.getElementById('autoLocateChk').onchange = function () {
    autoLocate = this.checked;
    saveUiStateToHost();
};
// Internal Tempo BPM input
document.getElementById('internalBpmInput').onchange = function () {
    var v = Math.max(20, Math.min(300, parseInt(this.value) || 120));
    this.value = v;
    internalBpm = v;
    syncBlocksToHost();
    saveUiStateToHost();
};
// Plugin Routing mode toggle
document.querySelectorAll('.routing-btn').forEach(function (btn) {
    btn.onclick = function () {
        var mode = parseInt(btn.dataset.rmode);
        routingMode = mode;
        document.querySelectorAll('.routing-btn').forEach(function (b) { b.classList.toggle('on', parseInt(b.dataset.rmode) === mode); });
        if (window.__JUCE__ && window.__JUCE__.backend) {
            var fn = window.__juceGetNativeFunction('setRoutingMode');
            fn(mode);
        }
        renderAllPlugins(); saveUiStateToHost();
    };
});
document.getElementById('addRnd').onclick = function () { addBlock('randomize'); };
document.getElementById('addEnv').onclick = function () { addBlock('envelope'); };
document.getElementById('addSmp').onclick = function () { addBlock('sample'); };
document.getElementById('addMorph').onclick = function () { addBlock('morph_pad'); };
document.getElementById('addShapes').onclick = function () { addBlock('shapes'); };
document.getElementById('addShapesRange').onclick = function () { addBlock('shapes_range'); };
document.getElementById('addLane').onclick = function () { addBlock('lane'); };
document.getElementById('addPluginBtn').onclick = function () { openPluginBrowser(); };
document.getElementById('undoBtn').onclick = function () { performUndo(); };
document.getElementById('redoBtn').onclick = function () { performRedo(); };

// Collapse / Expand All Plugins
document.getElementById('collapseAllBtn').onclick = function () {
    pluginBlocks.forEach(function (pb) { pb.expanded = false; });
    renderAllPlugins(); saveUiStateToHost();
};
document.getElementById('expandAllBtn').onclick = function () {
    pluginBlocks.forEach(function (pb) { pb.expanded = true; });
    renderAllPlugins(); saveUiStateToHost();
};

// Plugin loading state — prevent double-clicks
var pluginLoading = false;
function setPluginLoading(isLoading, name) {
    pluginLoading = isLoading;
    var btn = document.getElementById('addPluginBtn');
    if (isLoading) {
        btn.disabled = true;
        btn.textContent = 'Loading...';
        btn.title = 'Loading ' + (name || 'plugin') + '...';
    } else {
        btn.disabled = false;
        btn.textContent = '+ Plugin';
        btn.title = '';
    }
}

// ── Toast notification system ──
// Types: 'success' (green), 'error' (red), 'info' (blue)
// Colors driven by CSS variables for theme support
function showToast(message, type, durationMs) {
    type = type || 'info';
    durationMs = durationMs || 3500;
    var container = document.getElementById('crash-toast-container');
    if (!container) {
        container = document.createElement('div');
        container.id = 'crash-toast-container';
        container.style.cssText = 'position:fixed;top:12px;right:12px;z-index:99999;display:flex;flex-direction:column;gap:8px;pointer-events:none;';
        document.body.appendChild(container);
    }
    var rs = getComputedStyle(document.documentElement);
    var colors = {
        success: {
            bg: rs.getPropertyValue('--toast-success-bg').trim() || 'linear-gradient(135deg,#0a3a1a,#082a10)',
            border: rs.getPropertyValue('--toast-success-border').trim() || '#4a8',
            icon: '✓'
        },
        error: {
            bg: rs.getPropertyValue('--toast-error-bg').trim() || 'linear-gradient(135deg,#4a1010,#2a0808)',
            border: rs.getPropertyValue('--toast-error-border').trim() || '#ff3333',
            icon: '✕'
        },
        info: {
            bg: rs.getPropertyValue('--toast-info-bg').trim() || 'linear-gradient(135deg,#102040,#081828)',
            border: rs.getPropertyValue('--toast-info-border').trim() || '#4a8cff',
            icon: 'ℹ'
        }
    };
    var textColor = rs.getPropertyValue('--toast-text').trim() || '#fff';
    var c = colors[type] || colors.info;
    var toast = document.createElement('div');
    toast.style.cssText = 'pointer-events:auto;background:' + c.bg + ';border:1px solid ' + c.border + ';border-radius:8px;padding:10px 14px;color:' + textColor + ';font-size:12px;font-family:inherit;box-shadow:0 4px 24px rgba(0,0,0,0.4);display:flex;align-items:center;gap:8px;animation:crashSlideIn 0.3s ease-out;max-width:380px;cursor:pointer;';
    toast.innerHTML = '<span style="font-size:16px;opacity:0.9">' + c.icon + '</span><span>' + message + '</span>';
    toast.onclick = function () { dismiss(); };
    container.appendChild(toast);
    function dismiss() {
        toast.style.animation = 'crashSlideOut 0.2s ease-in forwards';
        setTimeout(function () { if (toast.parentNode) toast.parentNode.removeChild(toast); }, 200);
    }
    setTimeout(dismiss, durationMs);
}

// ── Placeholder card for plugin loading ──
function appendPlaceholderCard(placeholderId, plugName) {
    var c = document.getElementById('pluginScroll');
    var card = document.createElement('div');
    card.className = 'pcard pcard-loading';
    card.id = placeholderId;
    card.innerHTML = '<div class="pcard-head"><span class="pcard-name">' + escHtml(plugName) + '</span><span class="pcard-info loading-dots">Loading</span></div>' +
        '<div class="pcard-body"><div class="pcard-loading-bar"><div class="pcard-loading-fill"></div></div></div>';
    c.appendChild(card);
    // Scroll into view
    card.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}
function removePlaceholderCard(placeholderId) {
    var el = document.getElementById(placeholderId);
    if (el) el.remove();
}
function showLoadError(plugName, error) {
    showToast('Failed to load ' + plugName + ': ' + (error || 'Unknown error'), 'error', 5000);
}

// ── Keyboard Shortcuts ──
// Use CAPTURE phase so we intercept before WebView2's native handlers
document.addEventListener('keydown', function (e) {
    var tag = e.target.tagName;
    var inInput = (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT');
    var code = e.code || '';
    var key = (e.key || '').toLowerCase();

    // Ctrl+Z — Undo (works even in inputs)
    if ((e.ctrlKey || e.metaKey) && !e.shiftKey && (key === 'z' || code === 'KeyZ')) {
        e.preventDefault();
        e.stopPropagation();
        performUndo();
        return;
    }
    // Ctrl+Shift+Z — Redo (works even in inputs)
    if ((e.ctrlKey || e.metaKey) && e.shiftKey && (key === 'z' || code === 'KeyZ')) {
        e.preventDefault();
        e.stopPropagation();
        performRedo();
        return;
    }
    // Ctrl+Y — Redo (alternative, works even in inputs)
    if ((e.ctrlKey || e.metaKey) && (key === 'y' || code === 'KeyY')) {
        e.preventDefault();
        e.stopPropagation();
        performRedo();
        return;
    }
    // Ctrl+S — Quick-save global preset (works even in inputs)
    if ((e.ctrlKey || e.metaKey) && (key === 's' || code === 'KeyS')) {
        e.preventDefault();
        e.stopPropagation();
        if (typeof currentGlobalPresetName !== 'undefined' && currentGlobalPresetName) {
            document.getElementById('gpSave').click();
        } else {
            openGlobalPresetBrowser();
        }
        return;
    }

    // Skip remaining shortcuts when typing in inputs
    if (inInput) {
        if (e.key === 'Escape') { e.target.blur(); return; }
        return;
    }
    // Escape — close modals / exit assign mode
    if (e.key === 'Escape') {
        // Close any open modal
        var modals = document.querySelectorAll('.modal-overlay.vis');
        if (modals.length > 0) {
            modals.forEach(function (m) { m.classList.remove('vis'); });
            return;
        }
        // Close context menus
        document.getElementById('ctx').classList.remove('vis');
        document.getElementById('plugCtx').classList.remove('vis');
        // Exit assign mode
        if (assignMode) {
            assignMode = null;
            renderBlocks(); renderAllPlugins();
            return;
        }
        // Clear selection
        if (selectedParams.size > 0) {
            selectedParams.clear();
            renderAllPlugins();
        }
        return;
    }
    // Space — trigger active randomizer block
    if (e.key === ' ' || e.code === 'Space') {
        e.preventDefault();
        if (typeof actId !== 'undefined' && actId !== null) {
            var b = findBlock(actId);
            if (b && b.mode === 'randomize' && b.enabled !== false) {
                var ov = []; b.targets.forEach(function (pid) { var p = PMap[pid]; if (p && !p.lk && !p.alk) ov.push({ id: pid, val: p.v }); });
                randomize(actId);
                if (ov.length) pushMultiParamUndo(ov);
                flashDot('midiD');
            }
        }
        return;
    }
    // Delete — remove selected params from active block
    if (e.key === 'Delete' || e.key === 'Backspace') {
        if (selectedParams.size > 0 && typeof actId !== 'undefined' && actId !== null) {
            var b = findBlock(actId);
            if (b) {
                selectedParams.forEach(function (pid) { b.targets.delete(pid); });
                selectedParams.clear();
                renderAllPlugins(); renderBlocks(); syncBlocksToHost();
            }
        }
        return;
    }
    // Ctrl+A — select all params in assign mode
    if ((e.ctrlKey || e.metaKey) && (e.key === 'a' || e.key === 'A')) {
        e.preventDefault();
        if (assignMode) {
            // Select all visible (non-locked) params
            selectedParams.clear();
            pluginBlocks.forEach(function (pb) {
                pb.params.forEach(function (p) {
                    if (!p.lk && !p.alk) selectedParams.add(p.id);
                });
            });
            renderAllPlugins();
        }
        return;
    }
    // R — apply range (existing shortcut, keep it)
    if (e.key === 'r' || e.key === 'R') {
        if (!assignMode) return;
        var b = findBlock(assignMode);
        if (!b || b.mode !== 'shapes_range') return;
        if (selectedParams.size === 0) return;
        e.preventDefault();
        if (!b.targetRanges) b.targetRanges = {};
        if (!b.targetRangeBases) b.targetRangeBases = {};
        selectedParams.forEach(function (pid) {
            var p = PMap[pid];
            if (!p || p.lk) return;
            assignTarget(b, pid);
            b.targetRanges[pid] = 0;
            b.targetRangeBases[pid] = p.v;
        });
        renderAllPlugins(); renderBlocks(); syncBlocksToHost();
    }
}, true); // CAPTURE phase — intercept before WebView2 native handlers
// Plugin browser modal logic
var modalCat = 'all', modalQuery = '';
function doScanPlugins() {
    if (!window.__JUCE__ || !window.__JUCE__.backend || scanInProgress) return;
    scanInProgress = true;
    document.getElementById('modalInfo').textContent = 'Scanning VST3 directories...';
    document.getElementById('modalBody').innerHTML = '<div class="no-results">Scanning for plugins...</div>';
    var scanFn = window.__juceGetNativeFunction('scanPlugins');
    scanFn(scanPaths).then(function (result) {
        scanInProgress = false;
        if (result && result.length) {
            scannedPlugins = result.map(function (p) {
                return { name: p.name || 'Unknown', vendor: p.vendor || '', cat: p.category || 'fx', path: p.path || '' };
            });
        } else {
            scannedPlugins = [];
        }
        renderModalList();
    });
}
function openPluginBrowser() {
    modalCat = 'all'; modalQuery = '';
    document.getElementById('modalSearch').value = '';
    document.getElementById('scanPaths').classList.remove('vis');
    renderModalTabs();
    // Auto-scan on first open if we haven't scanned yet
    if (scannedPlugins.length === 0) {
        doScanPlugins();
    } else {
        renderModalList();
    }
    document.getElementById('pluginModal').classList.add('vis');
    document.getElementById('modalSearch').focus();
}
function closePluginBrowser() { document.getElementById('pluginModal').classList.remove('vis'); }
document.getElementById('modalClose').onclick = closePluginBrowser;
document.getElementById('pluginModal').onclick = function (e) { if (e.target === this) closePluginBrowser(); };
document.getElementById('modalSearch').oninput = function () { modalQuery = this.value; renderModalList(); };
document.getElementById('modalTabs').onclick = function (e) {
    var tab = e.target.closest('.modal-tab'); if (!tab) return;
    modalCat = tab.dataset.cat; renderModalTabs(); renderModalList();
};
function renderModalTabs() {
    document.querySelectorAll('.modal-tab').forEach(function (t) {
        t.className = 'modal-tab' + (t.dataset.cat === modalCat ? ' on' : '');
    });
}
function renderModalList() {
    var body = document.getElementById('modalBody');
    var q = modalQuery.toLowerCase();
    var filtered = scannedPlugins.filter(function (p) {
        if (modalCat !== 'all' && p.cat !== modalCat) return false;
        if (q && p.name.toLowerCase().indexOf(q) === -1 && p.vendor.toLowerCase().indexOf(q) === -1) return false;
        return true;
    });
    document.getElementById('modalInfo').textContent = filtered.length + ' plugin' + (filtered.length !== 1 ? 's' : '') + ' found';
    if (filtered.length === 0) { body.innerHTML = '<div class="no-results">No plugins found. Click \u2699 Scan Paths to configure.</div>'; return; }
    var h = '';
    filtered.forEach(function (p) {
        var initials = p.name.split(' ').map(function (w) { return w[0]; }).join('').substring(0, 2);
        h += '<div class="plug-row" data-ppath="' + (p.path || p.name).replace(/"/g, '&quot;') + '">';
        h += '<div class="plug-icon">' + initials + '</div>';
        h += '<div class="plug-info"><div class="plug-name">' + p.name + '</div><div class="plug-meta">' + p.vendor + '</div></div>';
        h += '<span class="plug-type ' + p.cat + '">' + p.cat + '</span>';
        h += '</div>';
    });
    body.innerHTML = h;
    body.querySelectorAll('.plug-row').forEach(function (row) {
        row.onclick = function () {
            addPlugin(row.dataset.ppath);
            closePluginBrowser();
        };
    });
}
// Scan paths toggle
document.getElementById('scanToggle').onclick = function () {
    var sp = document.getElementById('scanPaths');
    sp.classList.toggle('vis'); renderScanPaths();
    // Also trigger a fresh scan with updated paths
    if (!sp.classList.contains('vis')) {
        scannedPlugins = []; // Clear so next open triggers re-scan
        doScanPlugins();
    }
};
document.getElementById('addScanPath').onclick = function () {
    scanPaths.push(''); renderScanPaths();
};
function renderScanPaths() {
    var c = document.getElementById('scanPathList'); c.innerHTML = '';
    scanPaths.forEach(function (p, i) {
        var row = document.createElement('div'); row.className = 'scan-path-row';
        row.innerHTML = '<input type="text" value="' + p + '" data-spi="' + i + '"><button class="scan-path-rm" data-sprm="' + i + '">&times;</button>';
        c.appendChild(row);
    });
    c.querySelectorAll('input').forEach(function (inp) {
        inp.onchange = function () { scanPaths[parseInt(inp.dataset.spi)] = inp.value; };
    });
    c.querySelectorAll('[data-sprm]').forEach(function (btn) {
        btn.onclick = function () { scanPaths.splice(parseInt(btn.dataset.sprm), 1); renderScanPaths(); };
    });
}
function flashDot(id) { var d = document.getElementById(id); d.classList.add('on'); setTimeout(function () { d.classList.remove('on'); }, 150); }
function updCounts() { var ap = allParams(); document.getElementById('stP').textContent = ap.length; document.getElementById('stL').textContent = ap.filter(function (p) { return p.lk || p.alk; }).length; document.getElementById('stB').textContent = blocks.length; document.getElementById('blockInfo').textContent = blocks.length + ' blocks'; }
