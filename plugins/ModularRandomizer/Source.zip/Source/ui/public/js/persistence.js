// ============================================================
// STATE PERSISTENCE
// Save/restore UI state across editor close/reopen
// ============================================================
// ==========================================================
// STATE PERSISTENCE — save/restore across editor close/reopen
// ==========================================================

// Serialize full UI state to JSON and send to processor
function saveUiStateToHost() {
    if (!(window.__JUCE__ && window.__JUCE__.backend)) return;
    var fn = window.__juceGetNativeFunction('saveUiState');
    var state = {
        blocks: blocks.map(function (b) {
            return {
                id: b.id, mode: b.mode, colorIdx: b.colorIdx,
                targets: Array.from(b.targets), targetBases: b.targetBases || {}, targetRanges: b.targetRanges || {}, targetRangeBases: b.targetRangeBases || {},
                trigger: b.trigger, beatDiv: b.beatDiv,
                midiMode: b.midiMode, midiNote: b.midiNote, midiCC: b.midiCC, midiCh: b.midiCh,
                velScale: b.velScale, threshold: b.threshold, audioSrc: b.audioSrc,
                rMin: b.rMin, rMax: b.rMax, rangeMode: b.rangeMode,
                quantize: b.quantize, qSteps: b.qSteps,
                movement: b.movement, glideMs: b.glideMs,
                envAtk: b.envAtk, envRel: b.envRel, envSens: b.envSens, envInvert: b.envInvert,
                loopMode: b.loopMode, sampleSpeed: b.sampleSpeed, sampleReverse: b.sampleReverse, jumpMode: b.jumpMode,
                sampleName: b.sampleName || '', sampleWaveform: b.sampleWaveform || null,
                polarity: b.polarity || 'bipolar', clockSource: b.clockSource || 'daw',
                snapshots: (b.snapshots || []).map(function (s) { return { x: s.x, y: s.y, name: s.name || '', source: s.source || '', values: s.values || {} }; }),
                playheadX: b.playheadX || 0.5, playheadY: b.playheadY || 0.5,
                morphMode: b.morphMode || 'manual', exploreMode: b.exploreMode || 'wander',
                lfoShape: b.lfoShape || 'circle', lfoDepth: b.lfoDepth != null ? b.lfoDepth : 80, lfoRotation: b.lfoRotation || 0, morphSpeed: b.morphSpeed || 50,
                morphAction: b.morphAction || 'jump', stepOrder: b.stepOrder || 'cycle',
                morphSource: b.morphSource || 'midi', jitter: b.jitter || 0,
                morphGlide: b.morphGlide || 200,
                morphTempoSync: !!b.morphTempoSync, morphSyncDiv: b.morphSyncDiv || '1/4',
                snapRadius: b.snapRadius || 100,
                shapeType: b.shapeType || 'circle', shapeTracking: b.shapeTracking || 'horizontal',
                shapeSize: b.shapeSize != null ? b.shapeSize : 80, shapeSpin: b.shapeSpin || 0,
                shapeSpeed: b.shapeSpeed || 50, shapeDepth: b.shapeDepth || 50,
                shapeRange: b.shapeRange || 'relative', shapePolarity: b.shapePolarity || 'bipolar',
                shapeTempoSync: !!b.shapeTempoSync, shapeSyncDiv: b.shapeSyncDiv || '1/4', shapeTrigger: b.shapeTrigger || 'free',
                laneTool: b.laneTool || 'draw', laneGrid: b.laneGrid || '1/8',
                lanes: (b.lanes || []).map(function (lane) {
                    return {
                        pids: lane.pids || (lane.pid ? [lane.pid] : []), color: lane.color || '', collapsed: !!lane.collapsed,
                        pts: (lane.pts || []).map(function (p) { return { x: p.x, y: p.y }; }),
                        loopLen: lane.loopLen || '1/1', phase: lane.phase || 0, depth: lane.depth != null ? lane.depth : 100,
                        slew: lane.slew || 0, warp: lane.warp || 0, interp: lane.interp || 'smooth',
                        playMode: lane.playMode || 'forward', freeSecs: lane.freeSecs || 4,
                        synced: lane.synced !== false, muted: !!lane.muted
                    };
                }),
                enabled: b.enabled !== false,
                expanded: b.expanded
            };
        }),
        bc: bc, actId: actId,
        locks: (function () {
            var lk = {};
            for (var id in PMap) { if (PMap[id].lk) lk[id] = true; }
            return lk;
        })(),
        pluginOrder: pluginBlocks.map(function (pb) { return pb.id; }),
        pluginExpanded: (function () {
            var exp = {};
            pluginBlocks.forEach(function (pb) { exp[pb.id] = pb.expanded; });
            return exp;
        })(),
        pluginBypassed: (function () {
            var byp = {};
            pluginBlocks.forEach(function (pb) { if (pb.bypassed) byp[pb.id] = true; });
            return byp;
        }()),
        uiScale: currentScale,
        uiTheme: currentTheme,
        autoLocate: autoLocate,
        internalBpm: internalBpm,
        routingMode: routingMode,
        pluginBuses: (function () {
            var buses = {};
            pluginBlocks.forEach(function (pb) { if (pb.busId) buses[pb.id] = pb.busId; });
            return buses;
        }()),
        busVolumes: busVolumes.slice(),
        busMutes: busMutes.slice(),
        busSolos: busSolos.slice(),
        busCollapsed: busCollapsed.slice()
    };
    fn(JSON.stringify(state));
}

// Restore state from processor (called once on editor open)
function restoreFromHost() {
    if (!(window.__JUCE__ && window.__JUCE__.backend)) {
        // No JUCE backend, just start fresh
        addBlock('randomize');
        return;
    }
    var fn = window.__juceGetNativeFunction('getFullState');
    fn().then(function (result) {
        if (!result) { addBlock('randomize'); processRealTimeData(); return; }

        var hasPlugins = result.plugins && result.plugins.length > 0;
        var hasUiState = result.uiState && result.uiState.length > 0;

        if (!hasPlugins && !hasUiState) {
            // Fresh session — start with default block
            addBlock('randomize');
            processRealTimeData();
            return;
        }

        // Rebuild pluginBlocks and PMap from hosted plugins
        pluginBlocks = [];
        PMap = {};
        if (result.plugins) {
            result.plugins.forEach(function (plug) {
                var params = (plug.params || []).map(function (p) {
                    var fid = plug.id + ':' + p.index;
                    var param = { id: fid, name: p.name, v: p.value, disp: p.disp || '', lk: false, alk: false, realIndex: p.index, hostId: plug.id };
                    PMap[fid] = param;
                    return param;
                });
                pluginBlocks.push({ id: plug.id, hostId: plug.id, name: plug.name, path: plug.path || '', params: params, expanded: true, searchFilter: '' });
            });
        }

        // Restore UI state (blocks, mappings, locks)
        if (hasUiState) {
            try {
                var saved = JSON.parse(result.uiState);

                // Restore locks
                if (saved.locks) {
                    for (var lid in saved.locks) {
                        if (PMap[lid]) PMap[lid].lk = true;
                    }
                }

                // Restore plugin expanded states
                if (saved.pluginExpanded) {
                    pluginBlocks.forEach(function (pb) {
                        if (saved.pluginExpanded[pb.id] !== undefined)
                            pb.expanded = saved.pluginExpanded[pb.id];
                    });
                }

                // Restore plugin order
                if (saved.pluginOrder && saved.pluginOrder.length > 0) {
                    var ordered = [];
                    saved.pluginOrder.forEach(function (pid) {
                        for (var i = 0; i < pluginBlocks.length; i++) {
                            if (pluginBlocks[i].id === pid) {
                                ordered.push(pluginBlocks[i]);
                                break;
                            }
                        }
                    });
                    // Add any plugins not in saved order (newly loaded)
                    pluginBlocks.forEach(function (pb) {
                        if (ordered.indexOf(pb) < 0) ordered.push(pb);
                    });
                    pluginBlocks = ordered;

                    // Sync restored order to C++ backend
                    var reorderFn = (window.__JUCE__ && window.__JUCE__.backend) ? window.__juceGetNativeFunction('reorderPlugins') : null;
                    if (reorderFn) {
                        var ids = pluginBlocks.map(function (pb) { return pb.id; });
                        reorderFn(ids);
                    }
                }

                // Restore bypass state
                if (saved.pluginBypassed) {
                    pluginBlocks.forEach(function (pb) {
                        if (saved.pluginBypassed[pb.id]) {
                            pb.bypassed = true;
                            if (window.__JUCE__ && window.__JUCE__.backend) {
                                var fn = window.__juceGetNativeFunction('setPluginBypass');
                                fn(pb.hostId, true);
                            }
                        }
                    });
                }
                // Restore blocks
                if (saved.blocks && saved.blocks.length > 0) {
                    blocks = saved.blocks.map(function (sb) {
                        // Convert targets array back to Set
                        var tSet = new Set();
                        if (sb.targets) sb.targets.forEach(function (t) {
                            // Only restore target if the param still exists
                            if (PMap[t]) tSet.add(t);
                        });
                        return {
                            id: sb.id, mode: sb.mode || 'randomize', targets: tSet, targetBases: sb.targetBases || {}, targetRanges: sb.targetRanges || {}, targetRangeBases: sb.targetRangeBases || {},
                            colorIdx: sb.colorIdx || 0,
                            trigger: sb.trigger || 'manual', beatDiv: sb.beatDiv || '1/4',
                            midiMode: sb.midiMode || 'any_note', midiNote: sb.midiNote || 60,
                            midiCC: sb.midiCC || 1, midiCh: sb.midiCh || 0,
                            velScale: sb.velScale || false, threshold: sb.threshold || -12,
                            audioSrc: sb.audioSrc || 'main',
                            rMin: sb.rMin || 0, rMax: sb.rMax !== undefined ? sb.rMax : 100,
                            rangeMode: sb.rangeMode || 'absolute',
                            quantize: sb.quantize || false, qSteps: sb.qSteps || 12,
                            movement: sb.movement || 'instant', glideMs: sb.glideMs || 200,
                            envAtk: sb.envAtk || 10, envRel: sb.envRel || 100,
                            envSens: sb.envSens || 50, envInvert: sb.envInvert || false,
                            loopMode: sb.loopMode || 'loop', sampleSpeed: sb.sampleSpeed || 1.0,
                            sampleReverse: sb.sampleReverse || false, jumpMode: sb.jumpMode || 'restart',
                            sampleName: sb.sampleName || '', sampleWaveform: sb.sampleWaveform || null,
                            polarity: sb.polarity || 'bipolar', clockSource: sb.clockSource || 'daw',
                            snapshots: (sb.snapshots || []).map(function (s) { return { x: s.x || 0.5, y: s.y || 0.5, name: s.name || '', source: s.source || '', values: s.values || {} }; }),
                            playheadX: (function () { var c = clampToCircle(sb.playheadX || 0.5, sb.playheadY || 0.5); return c.x; })(),
                            playheadY: (function () { var c = clampToCircle(sb.playheadX || 0.5, sb.playheadY || 0.5); return c.y; })(),
                            morphMode: sb.morphMode || 'manual', exploreMode: (sb.exploreMode === 'lfo' ? 'shapes' : sb.exploreMode) || 'wander',
                            lfoShape: sb.lfoShape || 'circle', lfoDepth: sb.lfoDepth != null ? sb.lfoDepth : 80, lfoRotation: sb.lfoRotation || 0, morphSpeed: sb.morphSpeed || 50,
                            morphAction: sb.morphAction || 'jump', stepOrder: sb.stepOrder || 'cycle',
                            morphSource: sb.morphSource || 'midi', jitter: sb.jitter || 0,
                            morphGlide: sb.morphGlide || 200,
                            morphTempoSync: !!sb.morphTempoSync, morphSyncDiv: sb.morphSyncDiv || '1/4',
                            snapRadius: sb.snapRadius || 100,
                            shapeType: sb.shapeType || 'circle', shapeTracking: sb.shapeTracking || 'horizontal',
                            shapeSize: sb.shapeSize != null ? sb.shapeSize : 80, shapeSpin: sb.shapeSpin || 0,
                            shapeSpeed: sb.shapeSpeed || 50, shapeDepth: sb.shapeDepth || 50,
                            shapeRange: sb.shapeRange || 'relative', shapePolarity: sb.shapePolarity || 'bipolar',
                            shapeTempoSync: !!sb.shapeTempoSync, shapeSyncDiv: sb.shapeSyncDiv || '1/4', shapeTrigger: sb.shapeTrigger || 'free',
                            laneTool: sb.laneTool || 'draw', laneGrid: sb.laneGrid || '1/8',
                            lanes: (sb.lanes || []).map(function (lane) {
                                return {
                                    pids: lane.pids || (lane.pid ? [lane.pid] : []), color: lane.color || '', collapsed: !!lane.collapsed,
                                    pts: (lane.pts || []).map(function (p) { return { x: p.x, y: p.y }; }),
                                    loopLen: lane.loopLen || '1/1', phase: lane.phase || 0, depth: lane.depth != null ? lane.depth : 100,
                                    slew: lane.slew || 0, warp: lane.warp || 0, interp: lane.interp || 'smooth',
                                    playMode: lane.playMode || 'forward', freeSecs: lane.freeSecs || 4,
                                    synced: lane.synced !== false, muted: !!lane.muted
                                };
                            }),
                            enabled: sb.enabled !== false,
                            expanded: sb.expanded !== undefined ? sb.expanded : true
                        };
                    });
                    bc = saved.bc || 0;
                    actId = saved.actId || (blocks.length > 0 ? blocks[0].id : null);
                } else {
                    // Has plugins but no blocks — create default
                    addBlock('randomize');
                }
            } catch (e) {
                console.log('UI state restore error:', e);
                addBlock('randomize');
            }
            // Restore UI scale (outside try/catch so it always applies)
            if (saved && saved.uiScale) {
                applyScale(saved.uiScale);
            }
            // Restore theme
            if (saved && saved.uiTheme && THEMES[saved.uiTheme]) {
                applyTheme(saved.uiTheme);
            }
            // Restore auto-locate setting
            if (saved && saved.autoLocate !== undefined) {
                autoLocate = saved.autoLocate;
                document.getElementById('autoLocateChk').checked = autoLocate;
            }
            if (saved && saved.internalBpm) {
                internalBpm = saved.internalBpm;
                document.getElementById('internalBpmInput').value = internalBpm;
            }
            // Restore routing mode
            if (saved && saved.routingMode !== undefined) {
                routingMode = saved.routingMode;
                document.querySelectorAll('.routing-btn').forEach(function (b) {
                    b.classList.toggle('on', parseInt(b.dataset.rmode) === routingMode);
                });
                if (window.__JUCE__ && window.__JUCE__.backend) {
                    var rmFn = window.__juceGetNativeFunction('setRoutingMode');
                    rmFn(routingMode);
                }
            }
            // Restore also from getFullState response
            if (data.routingMode !== undefined && !(saved && saved.routingMode !== undefined)) {
                routingMode = data.routingMode;
                document.querySelectorAll('.routing-btn').forEach(function (b) {
                    b.classList.toggle('on', parseInt(b.dataset.rmode) === routingMode);
                });
            }
            // Restore bus assignments
            if (saved && saved.pluginBuses) {
                var buses = saved.pluginBuses;
                pluginBlocks.forEach(function (pb) {
                    if (buses[pb.id] !== undefined) {
                        pb.busId = buses[pb.id];
                        if (window.__JUCE__ && window.__JUCE__.backend) {
                            var busFn = window.__juceGetNativeFunction('setPluginBus');
                            busFn(pb.hostId || pb.id, pb.busId);
                        }
                    }
                });
            }
            // Restore bus mixer state
            if (saved && saved.busVolumes) {
                for (var bvi = 0; bvi < saved.busVolumes.length && bvi < busVolumes.length; bvi++) {
                    busVolumes[bvi] = saved.busVolumes[bvi];
                    if (window.__JUCE__ && window.__JUCE__.backend) {
                        var bvFn = window.__juceGetNativeFunction('setBusVolume');
                        bvFn(bvi, busVolumes[bvi]);
                    }
                }
            }
            if (saved && saved.busMutes) {
                for (var bmi = 0; bmi < saved.busMutes.length && bmi < busMutes.length; bmi++) {
                    busMutes[bmi] = saved.busMutes[bmi];
                    if (window.__JUCE__ && window.__JUCE__.backend) {
                        var bmFn = window.__juceGetNativeFunction('setBusMute');
                        bmFn(bmi, busMutes[bmi]);
                    }
                }
            }
            if (saved && saved.busSolos) {
                for (var bsi = 0; bsi < saved.busSolos.length && bsi < busSolos.length; bsi++) {
                    busSolos[bsi] = saved.busSolos[bsi];
                    if (window.__JUCE__ && window.__JUCE__.backend) {
                        var bsFn = window.__juceGetNativeFunction('setBusSolo');
                        bsFn(bsi, busSolos[bsi]);
                    }
                }
            }
            if (saved && saved.busCollapsed) {
                for (var bci = 0; bci < saved.busCollapsed.length && bci < busCollapsed.length; bci++) {
                    busCollapsed[bci] = saved.busCollapsed[bci];
                }
            }
            // Also read busId from getFullState plugin data
            if (data.plugins) {
                data.plugins.forEach(function (dp) {
                    if (dp.busId) {
                        for (var i = 0; i < pluginBlocks.length; i++) {
                            if (pluginBlocks[i].id === dp.id) {
                                pluginBlocks[i].busId = dp.busId;
                                break;
                            }
                        }
                    }
                });
            }
        } else {
            // Has plugins but no saved UI state — create default block
            addBlock('randomize');
        }

        renderAllPlugins();
        renderBlocks();
        updCounts();
        syncBlocksToHost();
        syncExpandedPlugins();
        processRealTimeData();
    }).catch(function (e) {
        console.log('getFullState error:', e);
        addBlock('randomize');
        processRealTimeData();
    });
}

// ============================================================
// AUTO-SAVE: Periodic + on-close state persistence
// Ensures processor always has current UI state, even if the
// editor is destroyed without an explicit save action.
// ============================================================

// Auto-save every 3 seconds so processor always has recent state
setInterval(function () {
    saveUiStateToHost();
}, 3000);

// Last-ditch save when WebView is about to be destroyed
window.addEventListener('beforeunload', function () {
    saveUiStateToHost();
});

// Save when page becomes hidden (tab switch, minimize, etc.)
document.addEventListener('visibilitychange', function () {
    if (document.visibilityState === 'hidden') {
        saveUiStateToHost();
    }
});
