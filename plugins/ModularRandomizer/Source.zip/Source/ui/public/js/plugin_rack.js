// ============================================================
// PLUGIN RACK
// Plugin loading, rendering, param display, drag & context menu
// ============================================================

// Visibility culling: tell C++ which plugin IDs are currently expanded.
// C++ skips polling params from collapsed plugins.
function syncExpandedPlugins() {
    if (!(window.__JUCE__ && window.__JUCE__.backend)) return;
    var fn = window.__juceGetNativeFunction('setExpandedPlugins');
    var ids = [];
    for (var i = 0; i < pluginBlocks.length; i++) {
        if (pluginBlocks[i].expanded) ids.push(pluginBlocks[i].id);
    }
    fn(ids);
}

// Force-dirty all params for a plugin so refreshParamDisplay repaints them.
// Called when a card is expanded or when scroll reveals new rows.
function dirtyPluginParams(pluginId) {
    for (var pid in PMap) {
        if (PMap[pid].hostId === pluginId) _dirtyParams.add(pid);
    }
}

// Load a REAL VST3 plugin via native function
function addPlugin(pluginPath) {
    if (!window.__JUCE__ || !window.__JUCE__.backend) {
        console.log('JUCE backend not available');
        return;
    }
    if (typeof pluginLoading !== 'undefined' && pluginLoading) return; // prevent double-click
    var plugName = pluginPath.split(/[\\/]/).pop().replace(/\.vst3$/i, '');
    if (typeof setPluginLoading === 'function') setPluginLoading(true, plugName);

    // Show placeholder card immediately (visual feedback while loading)
    var placeholderId = 'loading-' + Date.now();
    appendPlaceholderCard(placeholderId, plugName);

    // Timeout: if load takes > 15s, assume it's hung
    var loadTimedOut = false;
    var loadTimeout = setTimeout(function () {
        loadTimedOut = true;
        removePlaceholderCard(placeholderId);
        if (typeof setPluginLoading === 'function') setPluginLoading(false);
        showLoadError(plugName, 'Load timed out after 15 seconds');
    }, 15000);

    console.log('Loading plugin: ' + pluginPath);
    var loadFn = window.__juceGetNativeFunction('loadPlugin');
    loadFn(pluginPath).then(function (result) {
        clearTimeout(loadTimeout);
        if (loadTimedOut) return; // already cleaned up
        removePlaceholderCard(placeholderId);
        if (typeof setPluginLoading === 'function') setPluginLoading(false);
        if (!result || result.error) {
            showLoadError(plugName, result ? result.error : 'Load failed');
            return;
        }
        var hostedId = result.id;
        var params = (result.params || []).map(function (p, i) {
            var fid = hostedId + ':' + p.index;
            var param = { id: fid, name: p.name, v: p.value, disp: p.disp || '', lk: false, alk: false, realIndex: p.index, hostId: hostedId };
            PMap[fid] = param;
            return param;
        });
        pluginBlocks.push({ id: hostedId, hostId: hostedId, name: result.name, path: pluginPath, params: params, expanded: true, searchFilter: '' });
        console.log('Loaded: ' + result.name + ' (' + params.length + ' params)');
        showToast(result.name + ' loaded (' + params.length + ' params)', 'success', 2500);
        renderAllPlugins(); updCounts(); saveUiStateToHost(); syncExpandedPlugins();
    }).catch(function (err) {
        clearTimeout(loadTimeout);
        if (loadTimedOut) return;
        removePlaceholderCard(placeholderId);
        if (typeof setPluginLoading === 'function') setPluginLoading(false);
        showLoadError(plugName, err);
    });
}
function removePlugin(pid) {
    var pb; for (var i = 0; i < pluginBlocks.length; i++) { if (pluginBlocks[i].id === pid) { pb = pluginBlocks[i]; break; } }
    if (!pb) return;
    pushUndoSnapshot();
    // Call native removePlugin
    if (window.__JUCE__ && window.__JUCE__.backend) {
        var removeFn = window.__juceGetNativeFunction('removePlugin');
        removeFn(pb.hostId || pid);
    }
    pb.params.forEach(function (p) { delete PMap[p.id]; blocks.forEach(function (b) { b.targets.delete(p.id); }); });
    pluginBlocks = pluginBlocks.filter(function (p) { return p.id !== pid; });
    renderAllPlugins(); renderBlocks(); updCounts(); syncBlocksToHost(); syncExpandedPlugins();
}
// Full build of a single plugin card DOM element
var plugCtxPluginId = null;  // which plugin the context menu is targeting
function buildPluginCard(pb, pi, isA, aBlk, aCol) {
    var card = document.createElement('div'); card.className = 'pcard' + (pb.bypassed ? ' bypassed' : '');
    card.setAttribute('draggable', 'true');
    card.setAttribute('data-plugidx', pi);
    card.setAttribute('data-plugid', pb.id);
    var bulkBtns = isA ? '<button class="sm-btn bulk-all" style="font-size:9px;padding:2px 6px;margin-left:4px" data-plugbulk="' + pb.id + '" data-bulkmode="all">All</button><button class="sm-btn bulk-none" style="font-size:9px;padding:2px 6px" data-plugbulk="' + pb.id + '" data-bulkmode="none">None</button>' : '';
    // Bus dropdown (parallel mode only)
    var busBadge = '';
    if (routingMode === 1) {
        var busIdx = pb.busId || 0;
        var busCol = BUS_COLORS[busIdx % BUS_COLORS.length];
        var opts = '';
        for (var bi = 0; bi < 7; bi++) {
            opts += '<option value="' + bi + '"' + (bi === busIdx ? ' selected' : '') + '>Bus ' + (bi + 1) + '</option>';
        }
        busBadge = '<span class="pcard-bus-wrap" style="background:' + busCol + '"><select class="pcard-bus-sel" data-plugbus="' + pb.id + '">' + opts + '</select></span>';
    }
    // Footer toolbar
    var footer = '<div class="pcard-foot">';
    footer += '<button class="pf-btn" data-pfrand="' + pb.id + '">Rand</button>';
    footer += '<div class="pf-snap-wrap"><button class="pf-btn" data-pfsnap="' + pb.id + '">Snap &#9662;</button>';
    footer += '<div class="pf-snap-menu" data-pfsnapmenu="' + pb.id + '"></div></div>';
    footer += '<div class="pf-snap-wrap"><button class="pf-btn" data-pfassign="' + pb.id + '">Assign &#9662;</button>';
    footer += '<div class="pf-snap-menu" data-pfassignmenu="' + pb.id + '"></div></div>';
    footer += '<div class="pf-snap-wrap"><button class="pf-btn" data-pfunassign="' + pb.id + '">Unassign &#9662;</button>';
    footer += '<div class="pf-snap-menu" data-pfunassignmenu="' + pb.id + '"></div></div>';
    // Bypass icon pushed to the right
    footer += '<button class="pf-bypass' + (pb.bypassed ? ' pf-active' : '') + '" data-pfbypass="' + pb.id + '" title="' + (pb.bypassed ? 'Unbypass' : 'Bypass') + '">&#9211;</button>';
    footer += '</div>';
    card.innerHTML = '<div class="pcard-head" data-plugid="' + pb.id + '">' + busBadge + '<span class="lchev ' + (pb.expanded ? 'open' : '') + '">&#9654;</span><span class="pcard-name">' + pb.name + '</span><span class="pcard-info">' + pb.params.length + ' params</span>' + bulkBtns + '<button class="pcard-preset" data-plugpreset="' + pb.id + '" title="Presets">&#128203;</button><button class="sm-btn" style="font-size:9px;padding:2px 6px" data-pluged="' + pb.id + '">Open</button><button class="pcard-close" data-plugrm="' + pb.id + '">x</button></div><div class="pcard-body ' + (pb.expanded ? '' : 'hide') + '"><div class="pcard-search"><input type="text" placeholder="Filter..." data-plugsearch="' + pb.id + '" value="' + (pb.searchFilter || '') + '"></div><div class="pcard-params" data-plugparams="' + pb.id + '"></div></div>' + footer;
    fillPluginParams(card.querySelector('[data-plugparams="' + pb.id + '"]'), pb, isA, aBlk, aCol);
    return card;
}
// Fill param rows into a container element (used by both full build and patch)
function fillPluginParams(paramC, pb, isA, aBlk, aCol) {
    paramC.innerHTML = '';
    var filter = (pb.searchFilter || '').toLowerCase();
    // Check if we're in shapes_range assign mode (for drag-to-set-range)
    var srBlock = (isA && aBlk && aBlk.mode === 'shapes_range') ? aBlk : null;
    // Pre-collect ALL shapes_range blocks for arc display (visible even outside assign mode)
    var srBlocks = [];
    for (var sbi = 0; sbi < blocks.length; sbi++) {
        if (blocks[sbi].mode === 'shapes_range' && blocks[sbi].enabled !== false) srBlocks.push(blocks[sbi]);
    }
    for (var i = 0; i < pb.params.length; i++) {
        var p = pb.params[i];
        if (filter && p.name.toLowerCase().indexOf(filter) === -1) continue;
        var isTgt = isA && aBlk && aBlk.targets.has(p.id);
        var row = document.createElement('div');
        row.className = 'pr' + (p.lk ? ' locked' : '') + (isA && !p.lk ? ' assign-highlight' : '') + (selectedParams.has(p.id) ? ' selected' : '');
        row.setAttribute('data-pid', p.id);
        if (!p.lk) row.setAttribute('draggable', 'true');
        if (isTgt) { row.style.background = aCol + '18'; row.style.borderColor = aCol + '66'; }
        var dots = ''; for (var bi = 0; bi < blocks.length; bi++) { if (blocks[bi].targets.has(p.id)) dots += '<span class="pr-dot" style="background:' + bColor(blocks[bi].colorIdx) + '"></span>'; }
        // SVG rotary knob — with optional range arc for shapes_range
        // Show arc from assign-mode block (priority) OR from any active shapes_range block targeting this param
        var rangeInfo = null;
        if (srBlock && isTgt) {
            var rng = srBlock.targetRanges && srBlock.targetRanges[p.id] !== undefined ? srBlock.targetRanges[p.id] : 0;
            var base = srBlock.targetRangeBases && srBlock.targetRangeBases[p.id] !== undefined ? srBlock.targetRangeBases[p.id] : p.v;
            rangeInfo = { range: rng, base: base, color: aCol, polarity: srBlock.shapePolarity || 'bipolar' };
        } else if (!srBlock) {
            // Not in assign mode — show arc from any shapes_range block targeting this param
            for (var sri = 0; sri < srBlocks.length; sri++) {
                var sb = srBlocks[sri];
                if (sb.targets.has(p.id)) {
                    var rng = sb.targetRanges && sb.targetRanges[p.id] !== undefined ? sb.targetRanges[p.id] : 0;
                    if (Math.abs(rng) > 0.001) {
                        var base = sb.targetRangeBases && sb.targetRangeBases[p.id] !== undefined ? sb.targetRangeBases[p.id] : p.v;
                        rangeInfo = { range: rng, base: base, color: bColor(sb.colorIdx), polarity: sb.shapePolarity || 'bipolar' };
                    }
                    break; // first match wins
                }
            }
        }
        var knobSvg = buildParamKnob(p.v, 30, rangeInfo);
        var grip = p.lk ? '' : '<span class="pr-grip" title="Drag to logic block">⠿</span>';
        row.innerHTML = grip + '<div class="pr-knob" data-pid="' + p.id + '" data-hid="' + (p.hostId !== undefined ? p.hostId : '') + '" data-ri="' + (p.realIndex !== undefined ? p.realIndex : '') + '">' + knobSvg + '</div><span class="pr-name">' + p.name + '</span><div class="pr-dots">' + dots + '</div><span class="pr-val">' + (p.disp || ((p.v * 100).toFixed(0) + '%')) + '</span><div class="pr-bar"><div class="pr-bar-f" style="width:' + (p.v * 100) + '%"></div></div>' + (p.lk ? '<span class="pr-lock">' + (p.alk ? '&#9888;' : '&#128274;') + '</span>' : '');
        paramC.appendChild(row);
    }
}
// Build a small SVG arc knob for value 0..1, with optional range arc
// rangeInfo: { range: 0..1, color: '#hex', polarity: 'up'|'down'|'bipolar' }
function buildParamKnob(val, size, rangeInfo) {
    var r = size / 2, cx = r, cy = r;
    var ir = r - 3; // inner radius for arc
    var startAngle = 135 * Math.PI / 180; // 7 o'clock
    var endAngle = 405 * Math.PI / 180;   // 5 o'clock
    var span = endAngle - startAngle;      // 270°
    // Background track arc
    var ts = startAngle, te = endAngle;
    var tPath = describeArc(cx, cy, ir, ts, te);
    // Value arc
    var va = startAngle + val * span;
    var vPath = val > 0.005 ? describeArc(cx, cy, ir, ts, va) : '';
    // Indicator dot position
    var dx = cx + ir * Math.cos(va), dy = cy + ir * Math.sin(va);
    var svg = '<svg width="' + size + '" height="' + size + '" viewBox="0 0 ' + size + ' ' + size + '">';
    svg += '<path d="' + tPath + '" fill="none" stroke="var(--knob-track)" stroke-width="2.5" stroke-linecap="round"/>';
    if (vPath) svg += '<path d="' + vPath + '" fill="none" stroke="var(--knob-value)" stroke-width="2.5" stroke-linecap="round"/>';
    // Range arc (for shapes_range mode) — anchored at base position, not current val
    if (rangeInfo && Math.abs(rangeInfo.range) > 0.001) {
        var rng = rangeInfo.range;
        var absRng = Math.abs(rng);
        var base = rangeInfo.base !== undefined ? rangeInfo.base : val;
        var pol = rangeInfo.polarity || 'bipolar';
        var rStart, rEnd;
        if (pol === 'bipolar') {
            rStart = Math.max(base - absRng, 0);
            rEnd = Math.min(base + absRng, 1);
        } else {
            // Unipolar (drag direction): follow the sign of rng
            if (rng > 0) {
                rStart = base;
                rEnd = Math.min(base + rng, 1);
            } else {
                rStart = Math.max(base + rng, 0);
                rEnd = base;
            }
        }
        var raStart = startAngle + rStart * span;
        var raEnd = startAngle + rEnd * span;
        if (raEnd > raStart + 0.01) {
            var rPath = describeArc(cx, cy, ir + 1, raStart, raEnd);
            // Contrast color: outer ring arc distinct from knob fill
            svg += '<path d="' + rPath + '" fill="none" stroke="var(--range-arc, #ff8c42)" stroke-width="2" stroke-linecap="round" style="opacity:0.85"/>';
        }
    }
    svg += '<circle cx="' + dx.toFixed(1) + '" cy="' + dy.toFixed(1) + '" r="2.5" fill="var(--knob-dot)"/>';
    svg += '</svg>';
    return svg;
}
function describeArc(cx, cy, r, start, end) {
    var sx = cx + r * Math.cos(start), sy = cy + r * Math.sin(start);
    var ex = cx + r * Math.cos(end), ey = cy + r * Math.sin(end);
    var large = (end - start > Math.PI) ? 1 : 0;
    return 'M ' + sx.toFixed(2) + ' ' + sy.toFixed(2) + ' A ' + r + ' ' + r + ' 0 ' + large + ' 1 ' + ex.toFixed(2) + ' ' + ey.toFixed(2);
}
// Stamp for detecting structural changes (plugin add/remove/reorder)
var _pluginStamp = '';
var _expectedChildCount = 0;
function getPluginStamp() { return pluginBlocks.map(function (pb) { return pb.id + ':' + (pb.busId || 0); }).join(',') + '|' + (assignMode !== null ? assignMode : '') + '|' + routingMode + '|' + busMutes.join(',') + '|' + busSolos.join(',') + '|' + busCollapsed.join(','); }
// dB <-> linear helpers for bus volume
function linToDb(lin) { return lin <= 0.001 ? -60 : 20 * Math.log10(lin); }
function dbToLin(db) { return db <= -59.9 ? 0 : Math.pow(10, db / 20); }
function fmtDb(db) { return db <= -59.9 ? '-\u221E' : (db >= 0 ? '+' : '') + db.toFixed(1); }

function renderAllPlugins() {
    var c = document.getElementById('pluginScroll');
    var isA = assignMode !== null, aBlk = isA ? findBlock(assignMode) : null, aCol = isA && aBlk ? bColor(aBlk.colorIdx) : '';
    var newStamp = getPluginStamp();

    // STRUCTURAL CHANGE: different plugins or order — full rebuild
    if (newStamp !== _pluginStamp || c.childElementCount !== _expectedChildCount) {
        _pluginStamp = newStamp;
        c.innerHTML = '';

        if (routingMode === 1) {
            // PARALLEL MODE: group plugins by bus, add bus header before each group
            var busGroups = {};
            for (var pi = 0; pi < pluginBlocks.length; pi++) {
                var bid = pluginBlocks[pi].busId || 0;
                if (!busGroups[bid]) busGroups[bid] = [];
                busGroups[bid].push(pi);
            }
            var sortedBuses = Object.keys(busGroups).map(Number).sort();
            for (var bi = 0; bi < sortedBuses.length; bi++) {
                var bus = sortedBuses[bi];
                var col = BUS_COLORS[bus % BUS_COLORS.length];
                var linVol = busVolumes[bus] != null ? busVolumes[bus] : 1;
                var dbVal = linToDb(linVol);
                var muted = busMutes[bus] || false;
                var soloed = busSolos[bus] || false;
                var collapsed = busCollapsed[bus] || false;
                var plugCount = busGroups[bus].length;
                // Bus group container
                var grp = document.createElement('div');
                grp.className = 'bus-group' + (muted ? ' bus-muted' : '');
                grp.style.borderLeftColor = col;
                grp.style.setProperty('--bus-tint', col);
                // Bus header strip
                var hdr = document.createElement('div');
                hdr.className = 'bus-header' + (soloed ? ' bus-soloed' : '');
                hdr.dataset.bus = bus;
                hdr.innerHTML = '<span class="bus-chev' + (collapsed ? '' : ' open') + '">&#9654;</span>' +
                    '<span class="bus-color-dot" style="background:' + col + '"></span>' +
                    '<span class="bus-name">Bus ' + (bus + 1) + (collapsed ? ' <span class="bus-count">(' + plugCount + ')</span>' : '') + '</span>' +
                    '<input type="range" class="bus-vol-slider" min="-60" max="6" step="0.1" value="' + dbVal.toFixed(1) + '" data-busvol="' + bus + '" title="' + fmtDb(dbVal) + ' dB">' +
                    '<span class="bus-vol-label" data-busvolval="' + bus + '">' + fmtDb(dbVal) + '</span>' +
                    '<button class="bus-mute-btn' + (muted ? ' on' : '') + '" data-busmute="' + bus + '">M</button>' +
                    '<button class="bus-solo-btn' + (soloed ? ' on' : '') + '" data-bussolo="' + bus + '">S</button>';
                grp.appendChild(hdr);
                // Plugins in this bus (hidden when collapsed)
                for (var gi = 0; gi < busGroups[bus].length; gi++) {
                    var idx = busGroups[bus][gi];
                    var card = buildPluginCard(pluginBlocks[idx], idx, isA, aBlk, aCol);
                    if (collapsed) card.style.display = 'none';
                    grp.appendChild(card);
                }
                c.appendChild(grp);
            }
        } else {
            // SEQUENTIAL MODE: flat list
            for (var pi = 0; pi < pluginBlocks.length; pi++) {
                c.appendChild(buildPluginCard(pluginBlocks[pi], pi, isA, aBlk, aCol));
            }
        }

        _expectedChildCount = c.childElementCount;
        wirePluginCards(); wireBusHeaders(); updateAssignBanner();
        // Restore bypass visual
        for (var bpi = 0; bpi < pluginBlocks.length; bpi++) {
            if (pluginBlocks[bpi].bypassed) {
                var bc2 = c.querySelector('[data-plugid="' + pluginBlocks[bpi].id + '"]');
                if (bc2) bc2.closest('.pcard').classList.add('bypassed');
            }
        }
        return;
    }

    // PATCH: same structure — update each card in-place
    for (var pi = 0; pi < pluginBlocks.length; pi++) {
        var pb = pluginBlocks[pi];
        var card = c.querySelector('.pcard[data-plugid="' + pb.id + '"]');
        if (!card) continue;

        // Update data-plugidx (may shift after drag reorder)
        card.setAttribute('data-plugidx', pi);

        // Patch expand/collapse state
        var chev = card.querySelector('.lchev');
        var body = card.querySelector('.pcard-body');
        if (chev) { if (pb.expanded) chev.classList.add('open'); else chev.classList.remove('open'); }
        if (body) { if (pb.expanded) body.classList.remove('hide'); else body.classList.add('hide'); }

        // Reset any lingering browser drag styling
        card.style.opacity = '';
        card.classList.remove('dragging', 'drag-over-top', 'drag-over-bottom');

        // Patch bypass visual
        if (pb.bypassed) card.classList.add('bypassed'); else card.classList.remove('bypassed');

        // Patch param rows (search filter or assign state change)
        var paramC = card.querySelector('[data-plugparams="' + pb.id + '"]');
        if (paramC) fillPluginParams(paramC, pb, isA, aBlk, aCol);

        // Restore search input value (fillPluginParams doesn't touch it)
        var searchInp = card.querySelector('[data-plugsearch="' + pb.id + '"]');
        if (searchInp && searchInp.value !== (pb.searchFilter || '')) searchInp.value = pb.searchFilter || '';
    }
    // Re-wire only needs to update assign highlights and event listeners
    wirePluginCards(); wireBusHeaders(); updateAssignBanner();
}
function wirePluginCards() {
    document.querySelectorAll('.pcard-head').forEach(function (h) {
        h.onclick = function (e) {
            if (e.target.closest('[data-plugrm]') || e.target.closest('[data-pluged]') || e.target.closest('[data-plugbulk]') || e.target.closest('[data-plugpreset]') || e.target.closest('.pcard-bus-sel')) return;
            var id = parseInt(h.dataset.plugid);
            var pb = null;
            for (var i = 0; i < pluginBlocks.length; i++) {
                if (pluginBlocks[i].id === id) { pb = pluginBlocks[i]; pb.expanded = !pb.expanded; break; }
            }
            // When expanding, force-dirty all params so visible rows repaint with current values
            if (pb && pb.expanded) dirtyPluginParams(id);
            renderAllPlugins();
            syncExpandedPlugins();
        };
        h.addEventListener('contextmenu', function (e) {
            e.preventDefault(); e.stopPropagation();
            var id = parseInt(h.dataset.plugid);
            plugCtxPluginId = id;
            showPlugCtx(e.clientX, e.clientY, id);
        });
    });
    // Bus dropdown — change bus assignment
    document.querySelectorAll('.pcard-bus-sel').forEach(function (sel) {
        sel.onchange = function (e) {
            e.stopPropagation();
            var pid = parseInt(sel.dataset.plugbus);
            var pb; for (var i = 0; i < pluginBlocks.length; i++) { if (pluginBlocks[i].id === pid) { pb = pluginBlocks[i]; break; } }
            if (!pb) return;
            var next = parseInt(sel.value);
            pb.busId = next;
            if (window.__JUCE__ && window.__JUCE__.backend) {
                var fn = window.__juceGetNativeFunction('setPluginBus');
                fn(pb.hostId || pid, next);
            }
            renderAllPlugins(); saveUiStateToHost();
        };
        // Prevent header collapse when clicking the select
        sel.onclick = function (e) { e.stopPropagation(); };
    });
    document.querySelectorAll('[data-plugrm]').forEach(function (b) { b.onclick = function (e) { e.stopPropagation(); removePlugin(parseInt(b.dataset.plugrm)); }; });
    document.querySelectorAll('[data-pluged]').forEach(function (b) {
        b.onclick = function (e) {
            e.stopPropagation();
            var id = parseInt(b.dataset.pluged);
            if (window.__JUCE__ && window.__JUCE__.backend) {
                var fn = window.__juceGetNativeFunction('openPluginEditor');
                fn(id);
            }
        };
    });
    document.querySelectorAll('[data-plugpreset]').forEach(function (b) {
        b.onclick = function (e) {
            e.stopPropagation();
            openPresetBrowser(parseInt(b.dataset.plugpreset));
        };
    });
    document.querySelectorAll('[data-plugsearch]').forEach(function (inp) {
        inp.onclick = function (e) { e.stopPropagation(); };
        inp.oninput = function () {
            var id = parseInt(inp.dataset.plugsearch);
            for (var i = 0; i < pluginBlocks.length; i++) { if (pluginBlocks[i].id === id) { pluginBlocks[i].searchFilter = inp.value; break; } }
            renderAllPlugins();
            var ni = document.querySelector('[data-plugsearch="' + id + '"]');
            if (ni) { ni.focus(); ni.selectionStart = ni.selectionEnd = ni.value.length; }
        };
    });
    // Scroll listener on param containers — repaint newly visible rows
    document.querySelectorAll('.pcard-params').forEach(function (container) {
        var scrollTimer = null;
        container.addEventListener('scroll', function () {
            if (scrollTimer) return; // debounce ~60ms
            scrollTimer = setTimeout(function () {
                scrollTimer = null;
                var plugId = parseInt(container.getAttribute('data-plugparams'));
                dirtyPluginParams(plugId);
                requestAnimationFrame(refreshParamDisplay);
            }, 60);
        }, { passive: true });
    });
    // Drag and drop reordering
    var dragSrcIdx = null;
    document.querySelectorAll('.pcard').forEach(function (card) {
        card.addEventListener('dragstart', function (e) {
            // If the drag originates from a param row (.pr), skip plugin reorder drag
            if (e.target.closest('.pr')) return;
            dragSrcIdx = parseInt(card.dataset.plugidx);
            card.classList.add('dragging');
            e.dataTransfer.effectAllowed = 'move';
            e.dataTransfer.setData('text/plain', dragSrcIdx);
        });
        card.addEventListener('dragend', function () {
            card.classList.remove('dragging');
            dragSrcIdx = null;
            document.querySelectorAll('.pcard').forEach(function (c) {
                c.classList.remove('dragging', 'drag-over-top', 'drag-over-bottom');
            });
        });
        card.addEventListener('dragover', function (e) {
            e.preventDefault();
            e.dataTransfer.dropEffect = 'move';
            var rect = card.getBoundingClientRect();
            var midY = rect.top + rect.height / 2;
            document.querySelectorAll('.pcard').forEach(function (c) {
                c.classList.remove('drag-over-top', 'drag-over-bottom');
            });
            if (e.clientY < midY) card.classList.add('drag-over-top');
            else card.classList.add('drag-over-bottom');
        });
        card.addEventListener('dragleave', function () {
            card.classList.remove('drag-over-top', 'drag-over-bottom');
        });
        card.addEventListener('drop', function (e) {
            e.preventDefault();
            var fromIdx = parseInt(e.dataTransfer.getData('text/plain'));
            var toIdx = parseInt(card.dataset.plugidx);
            if (isNaN(fromIdx) || isNaN(toIdx) || fromIdx === toIdx) return;
            var rect = card.getBoundingClientRect();
            var midY = rect.top + rect.height / 2;
            if (e.clientY > midY && toIdx < fromIdx) toIdx++;
            if (e.clientY < midY && toIdx > fromIdx) toIdx--;
            var moved = pluginBlocks.splice(fromIdx, 1)[0];
            pluginBlocks.splice(toIdx, 0, moved);
            // In parallel mode: adopt target's bus assignment if different
            if (routingMode === 1) {
                var targetPb = pluginBlocks[toIdx === 0 ? 1 : toIdx - 1] || pluginBlocks[toIdx + 1];
                if (targetPb && (moved.busId || 0) !== (targetPb.busId || 0)) {
                    moved.busId = targetPb.busId || 0;
                    if (window.__JUCE__ && window.__JUCE__.backend) {
                        var busFn = window.__juceGetNativeFunction('setPluginBus');
                        busFn(moved.hostId || moved.id, moved.busId);
                    }
                }
            }
            // Sync new order to C++ so audio processing matches visual order
            var reorderFn = (window.__JUCE__ && window.__JUCE__.backend) ? window.__juceGetNativeFunction('reorderPlugins') : null;
            if (reorderFn) {
                var ids = pluginBlocks.map(function (pb) { return pb.id; });
                reorderFn(ids);
            }
            renderAllPlugins();
            saveUiStateToHost();
        });
    });
}
// Wire bus header controls (volume, mute, solo)
function wireBusHeaders() {
    // Volume sliders
    document.querySelectorAll('[data-busvol]').forEach(function (sl) {
        sl.oninput = function () {
            var bus = parseInt(sl.dataset.busvol);
            var db = parseFloat(sl.value);
            var lin = dbToLin(db);
            busVolumes[bus] = lin;
            var lbl = document.querySelector('[data-busvolval="' + bus + '"]');
            if (lbl) lbl.textContent = fmtDb(db);
            sl.title = fmtDb(db) + ' dB';
            if (window.__JUCE__ && window.__JUCE__.backend) {
                var fn = window.__juceGetNativeFunction('setBusVolume');
                fn(bus, lin);
            }
        };
        sl.onclick = function (e) { e.stopPropagation(); };
        sl.onchange = function () { saveUiStateToHost(); };
        // Double-click to reset to 0 dB
        sl.ondblclick = function (e) {
            e.stopPropagation();
            sl.value = '0';
            sl.oninput();
            saveUiStateToHost();
        };
    });
    // Mute buttons
    document.querySelectorAll('[data-busmute]').forEach(function (btn) {
        btn.onclick = function (e) {
            e.stopPropagation();
            var bus = parseInt(btn.dataset.busmute);
            busMutes[bus] = !busMutes[bus];
            if (window.__JUCE__ && window.__JUCE__.backend) {
                var fn = window.__juceGetNativeFunction('setBusMute');
                fn(bus, busMutes[bus]);
            }
            renderAllPlugins(); saveUiStateToHost();
        };
    });
    // Solo buttons
    document.querySelectorAll('[data-bussolo]').forEach(function (btn) {
        btn.onclick = function (e) {
            e.stopPropagation();
            var bus = parseInt(btn.dataset.bussolo);
            busSolos[bus] = !busSolos[bus];
            if (window.__JUCE__ && window.__JUCE__.backend) {
                var fn = window.__juceGetNativeFunction('setBusSolo');
                fn(bus, busSolos[bus]);
            }
            renderAllPlugins(); saveUiStateToHost();
        };
    });
    // Bus header click — toggle collapse
    document.querySelectorAll('.bus-header').forEach(function (hdr) {
        hdr.onclick = function (e) {
            if (e.target.closest('[data-busvol]') || e.target.closest('[data-busmute]') || e.target.closest('[data-bussolo]')) return;
            e.stopPropagation();
            var bus = parseInt(hdr.dataset.bus);
            busCollapsed[bus] = !busCollapsed[bus];
            renderAllPlugins(); saveUiStateToHost();
        };
    });
}
// Param click delegation
var pse = document.getElementById('pluginScroll');
var lastClickedPid = null; // track for Shift+Click range selection
var lastClickedAction = 'add'; // 'add' or 'remove' — Shift+Click mirrors this
pse.addEventListener('click', function (e) {
    // Bulk All/None buttons
    var bulkBtn = e.target.closest('[data-plugbulk]');
    if (bulkBtn && assignMode) {
        e.stopPropagation();
        var plugId = parseInt(bulkBtn.dataset.plugbulk);
        var mode = bulkBtn.dataset.bulkmode; // 'all' or 'none'
        var b = findBlock(assignMode);
        var pb = null;
        for (var i = 0; i < pluginBlocks.length; i++) { if (pluginBlocks[i].id === plugId) { pb = pluginBlocks[i]; break; } }
        if (b && pb) {
            pb.params.forEach(function (p) {
                if (p.lk) return; // skip locked
                if (mode === 'all') {
                    assignTarget(b, p.id);
                    // For shapes_range, set default range = current param value
                    if (b.mode === 'shapes_range') {
                        if (!b.targetRanges) b.targetRanges = {};
                        if (!b.targetRangeBases) b.targetRangeBases = {};
                        if (b.targetRanges[p.id] === undefined) { b.targetRanges[p.id] = 0; b.targetRangeBases[p.id] = p.v; }
                    }
                } else {
                    b.targets.delete(p.id);
                    if (b.mode === 'shapes_range') { if (b.targetRanges) delete b.targetRanges[p.id]; if (b.targetRangeBases) delete b.targetRangeBases[p.id]; }
                }
            });
            renderAllPlugins(); renderBlocks(); syncBlocksToHost();
        }
        return;
    }
    var row = e.target.closest('.pr'); if (!row) return;
    var pid = row.getAttribute('data-pid'); if (!pid) return;
    var pp = PMap[pid]; if (!pp) return;

    if (assignMode) {
        // === ASSIGN MODE: toggle targets on active block ===
        if (pp.lk) return; // locked params can't be assigned
        var b = findBlock(assignMode);
        if (!b) return;

        // Shapes Range: assign with range=0 (no arc until dragged)
        if (b.mode === 'shapes_range') {
            if (b.targets.has(pid)) {
                b.targets.delete(pid);
                if (b.targetRanges) delete b.targetRanges[pid];
                if (b.targetRangeBases) delete b.targetRangeBases[pid];
                lastClickedAction = 'remove';
            } else {
                assignTarget(b, pid);
                if (!b.targetRanges) b.targetRanges = {};
                if (!b.targetRangeBases) b.targetRangeBases = {};
                b.targetRanges[pid] = 0;
                b.targetRangeBases[pid] = pp.v; // anchor = current position
                lastClickedAction = 'add';
            }
        } else if (e.shiftKey && lastClickedPid) {
            var allRows = Array.prototype.slice.call(pse.querySelectorAll('.pr[data-pid]'));
            var startIdx = -1, endIdx = -1;
            for (var ri = 0; ri < allRows.length; ri++) {
                var rpid = allRows[ri].getAttribute('data-pid');
                if (rpid === lastClickedPid) startIdx = ri;
                if (rpid === pid) endIdx = ri;
            }
            if (startIdx !== -1 && endIdx !== -1) {
                var lo = Math.min(startIdx, endIdx), hi = Math.max(startIdx, endIdx);
                for (var ri = lo; ri <= hi; ri++) {
                    var rpid = allRows[ri].getAttribute('data-pid');
                    var rp = PMap[rpid];
                    if (rp && !rp.lk) {
                        if (lastClickedAction === 'add') {
                            assignTarget(b, rpid);
                            if (b.mode === 'shapes_range') {
                                if (!b.targetRanges) b.targetRanges = {};
                                if (!b.targetRangeBases) b.targetRangeBases = {};
                                if (b.targetRanges[rpid] === undefined) { b.targetRanges[rpid] = 0; b.targetRangeBases[rpid] = rp.v; }
                            }
                        } else {
                            b.targets.delete(rpid);
                            if (b.mode === 'shapes_range') { if (b.targetRanges) delete b.targetRanges[rpid]; if (b.targetRangeBases) delete b.targetRangeBases[rpid]; }
                        }
                    }
                }
            }
        } else if (e.ctrlKey || e.metaKey) {
            if (b.targets.has(pid)) { b.targets.delete(pid); if (b.mode === 'shapes_range') { if (b.targetRanges) delete b.targetRanges[pid]; if (b.targetRangeBases) delete b.targetRangeBases[pid]; } lastClickedAction = 'remove'; }
            else { assignTarget(b, pid); if (b.mode === 'shapes_range') { if (!b.targetRanges) b.targetRanges = {}; if (!b.targetRangeBases) b.targetRangeBases = {}; if (b.targetRanges[pid] === undefined) { b.targetRanges[pid] = 0; b.targetRangeBases[pid] = pp.v; } } lastClickedAction = 'add'; }
        } else {
            if (b.targets.has(pid)) { b.targets.delete(pid); if (b.mode === 'shapes_range') { if (b.targetRanges) delete b.targetRanges[pid]; if (b.targetRangeBases) delete b.targetRangeBases[pid]; } lastClickedAction = 'remove'; }
            else { assignTarget(b, pid); if (b.mode === 'shapes_range') { if (!b.targetRanges) b.targetRanges = {}; if (!b.targetRangeBases) b.targetRangeBases = {}; if (b.targetRanges[pid] === undefined) { b.targetRanges[pid] = 0; b.targetRangeBases[pid] = pp.v; } } lastClickedAction = 'add'; }
        }
        lastClickedPid = pid;
        renderAllPlugins();
        clearTimeout(renderAllPlugins._bt);
        renderAllPlugins._bt = setTimeout(function () { renderBlocks(); syncBlocksToHost(); }, 80);
    } else {
        // === SELECTION MODE: select params for drag/right-click assign ===
        // Locked params CAN be selected here (for batch unlock via context menu)
        if (e.shiftKey && lastClickedPid) {
            var allRows = Array.prototype.slice.call(pse.querySelectorAll('.pr[data-pid]'));
            var startIdx = -1, endIdx = -1;
            for (var ri = 0; ri < allRows.length; ri++) {
                var rpid = allRows[ri].getAttribute('data-pid');
                if (rpid === lastClickedPid) startIdx = ri;
                if (rpid === pid) endIdx = ri;
            }
            if (startIdx !== -1 && endIdx !== -1) {
                var lo = Math.min(startIdx, endIdx), hi = Math.max(startIdx, endIdx);
                for (var ri = lo; ri <= hi; ri++) {
                    var rpid = allRows[ri].getAttribute('data-pid');
                    var rp = PMap[rpid];
                    if (rp) {
                        if (lastClickedAction === 'add') selectedParams.add(rpid);
                        else selectedParams.delete(rpid);
                    }
                }
            }
        } else if (e.ctrlKey || e.metaKey) {
            if (selectedParams.has(pid)) { selectedParams.delete(pid); lastClickedAction = 'remove'; }
            else { selectedParams.add(pid); lastClickedAction = 'add'; }
        } else {
            // Plain click: clear selection and select just this one
            selectedParams.clear();
            selectedParams.add(pid);
            lastClickedAction = 'add';
        }
        lastClickedPid = pid;
        renderAllPlugins();
    }
});
// Drag from selected params
pse.addEventListener('dragstart', function (e) {
    var row = e.target.closest('.pr'); if (!row) return;
    var pid = row.getAttribute('data-pid'); if (!pid) return;
    // If dragging a non-selected param, select just that one
    if (!selectedParams.has(pid)) {
        selectedParams.clear();
        selectedParams.add(pid);
        // Don't call renderAllPlugins() here — it destroys the drag source mid-drag.
        // Instead, just toggle class directly on the row:
        pse.querySelectorAll('.pr.selected').forEach(function (r) { r.classList.remove('selected'); });
        row.classList.add('selected');
    }
    e.dataTransfer.effectAllowed = 'copy';
    e.dataTransfer.setData('text/plain', 'params:' + Array.from(selectedParams).join(','));
});
pse.addEventListener('dragend', function () {
    // Re-render after drag completes to sync visual state
    renderAllPlugins();
});
pse.addEventListener('contextmenu', function (e) {
    var row = e.target.closest('.pr'); if (!row) return;
    var pid = row.getAttribute('data-pid'); if (!pid) return;
    var pp = PMap[pid]; if (!pp) return; e.preventDefault();
    // If right-clicking on a non-selected param, select just it
    if (!selectedParams.has(pid)) {
        selectedParams.clear();
        selectedParams.add(pid);
        renderAllPlugins();
    }
    ctxP = pp; showCtx(e.clientX, e.clientY, pp);
});

// ── Knob drag interaction ──
(function () {
    var _setParamFn = null;
    function getSetParam() {
        if (!_setParamFn && window.__JUCE__ && window.__JUCE__.backend)
            _setParamFn = window.__juceGetNativeFunction('setParam');
        return _setParamFn;
    }
    var _touchParamFn = null, _untouchParamFn = null;
    function getTouchParam() {
        if (!_touchParamFn && window.__juceGetNativeFunction)
            _touchParamFn = window.__juceGetNativeFunction('touchParam');
        return _touchParamFn;
    }
    function getUntouchParam() {
        if (!_untouchParamFn && window.__juceGetNativeFunction)
            _untouchParamFn = window.__juceGetNativeFunction('untouchParam');
        return _untouchParamFn;
    }
    document.addEventListener('mousedown', function (e) {
        var knob = e.target.closest('.pr-knob');
        if (!knob) return;
        e.preventDefault();
        e.stopPropagation();
        var pid = knob.getAttribute('data-pid');
        var hid = parseInt(knob.getAttribute('data-hid'));
        var ri = parseInt(knob.getAttribute('data-ri'));
        var p = PMap[pid];
        if (!p || isNaN(hid) || isNaN(ri)) return;

        // ── SHAPES RANGE: drag to set range instead of value ──
        if (assignMode) {
            var srBlk = findBlock(assignMode);
            if (srBlk && srBlk.mode === 'shapes_range') {
                // Auto-assign if not yet assigned
                if (!srBlk.targets.has(pid)) {
                    assignTarget(srBlk, pid);
                    if (!srBlk.targetRanges) srBlk.targetRanges = {};
                    if (!srBlk.targetRangeBases) srBlk.targetRangeBases = {};
                    srBlk.targetRanges[pid] = 0;
                    srBlk.targetRangeBases[pid] = p.v; // capture base position
                }
                // Ensure base exists
                if (!srBlk.targetRangeBases) srBlk.targetRangeBases = {};
                if (srBlk.targetRangeBases[pid] === undefined) srBlk.targetRangeBases[pid] = p.v;
                var baseVal = srBlk.targetRangeBases[pid];
                var startY = e.clientY;
                var startRange = srBlk.targetRanges[pid] !== undefined ? srBlk.targetRanges[pid] : 0;
                var aCol = bColor(srBlk.colorIdx);
                function onMoveRange(me) {
                    var dy = startY - me.clientY; // positive = drag up = positive range
                    var newRange = startRange + dy / 200;
                    // Clamp so base + range stays within 0..1
                    if (newRange > 0) {
                        newRange = Math.min(newRange, 1 - baseVal);
                    } else {
                        newRange = Math.max(newRange, -baseVal);
                    }
                    srBlk.targetRanges[pid] = newRange;
                    var ri2 = { range: newRange, base: baseVal, color: aCol, polarity: srBlk.shapePolarity || 'bipolar' };
                    knob.innerHTML = buildParamKnob(p.v, 30, ri2);
                }
                function onUpRange() {
                    document.removeEventListener('mousemove', onMoveRange);
                    document.removeEventListener('mouseup', onUpRange);
                    renderAllPlugins(); renderBlocks(); syncBlocksToHost();
                }
                document.addEventListener('mousemove', onMoveRange);
                document.addEventListener('mouseup', onUpRange);
                return;
            }
        }

        // ── Normal knob drag (value adjustment) ──
        // Signal C++ to suspend modulation on this param
        var tfn = getTouchParam();
        if (tfn) tfn(hid, ri);
        // Block polling updates for this param during drag
        _touchedByUI.add(pid);
        var startY = e.clientY;
        var startVal = p.v;
        var sensitivity = 200; // pixels for full 0→1 range
        // Pre-find any shapes_range blocks targeting this param for live arc
        var _srDragBlocks = [];
        for (var sbi = 0; sbi < blocks.length; sbi++) {
            var sb = blocks[sbi];
            if (sb.mode === 'shapes_range' && sb.enabled !== false && sb.targets.has(pid)) {
                _srDragBlocks.push(sb);
            }
        }
        function onMove(me) {
            var dy = startY - me.clientY;
            var newVal = Math.max(0, Math.min(1, startVal + dy / sensitivity));
            p.v = newVal;
            var fn = getSetParam();
            if (fn) fn(hid, ri, newVal);
            // Continuously update shapes_range base so arc follows the knob
            for (var sri = 0; sri < _srDragBlocks.length; sri++) {
                var srb = _srDragBlocks[sri];
                if (!srb.targetRangeBases) srb.targetRangeBases = {};
                srb.targetRangeBases[pid] = newVal;
            }
            // Build knob with live range arc
            var ri2 = null;
            if (_srDragBlocks.length > 0) {
                var srb = _srDragBlocks[0];
                var rng = srb.targetRanges && srb.targetRanges[pid] !== undefined ? srb.targetRanges[pid] : 0;
                if (Math.abs(rng) > 0.001) {
                    ri2 = { range: rng, base: newVal, color: bColor(srb.colorIdx), polarity: srb.shapePolarity || 'bipolar' };
                }
            }
            knob.innerHTML = buildParamKnob(newVal, 30, ri2);
            var row = knob.closest('.pr');
            if (row) {
                var ve = row.querySelector('.pr-val');
                if (ve) ve.textContent = p.disp || ((newVal * 100).toFixed(0) + '%');
                var bf = row.querySelector('.pr-bar-f');
                if (bf) bf.style.width = (newVal * 100) + '%';
            }
        }
        function onUp() {
            document.removeEventListener('mousemove', onMove);
            document.removeEventListener('mouseup', onUp);
            _touchedByUI.delete(pid);
            // Record granular undo for just this param
            if (p.v !== startVal) {
                pushParamUndo(pid, startVal);
            }
            // Signal C++ to resume modulation from the new value
            var ufn = getUntouchParam();
            if (ufn) ufn(hid, ri);
            // Sync blocks to host so C++ picks up the updated bases
            if (p.v !== startVal && _srDragBlocks.length > 0) {
                syncBlocksToHost();
                renderAllPlugins();
            }
        }
        document.addEventListener('mousemove', onMove);
        document.addEventListener('mouseup', onUp);
    }, true); // capture phase to beat row click

    // ── Scroll wheel on param knobs ──
    document.addEventListener('wheel', function (e) {
        var knob = e.target.closest('.pr-knob');
        if (!knob) return;
        e.preventDefault();
        var pid = knob.getAttribute('data-pid');
        var hid = parseInt(knob.getAttribute('data-hid'));
        var ri = parseInt(knob.getAttribute('data-ri'));
        var p = PMap[pid];
        if (!p || p.lk || isNaN(hid) || isNaN(ri)) return;
        // Skip when in shapes_range assign mode (knob drag sets range, not value)
        if (assignMode) {
            var srBlk = findBlock(assignMode);
            if (srBlk && srBlk.mode === 'shapes_range') return;
        }
        var step = e.shiftKey ? 0.002 : 0.01; // Shift = fine control
        var delta = e.deltaY < 0 ? step : -step;
        var oldVal = p.v;
        var newVal = Math.max(0, Math.min(1, p.v + delta));
        if (newVal === oldVal) return;
        p.v = newVal;
        var fn = getSetParam();
        if (fn) fn(hid, ri, newVal);
        // Update knob visual inline (no full re-render)
        knob.innerHTML = buildParamKnob(newVal, 30, null);
        var row = knob.closest('.pr');
        if (row) {
            var ve = row.querySelector('.pr-val');
            if (ve) ve.textContent = p.disp || ((newVal * 100).toFixed(0) + '%');
            var bf = row.querySelector('.pr-bar-f');
            if (bf) bf.style.width = (newVal * 100) + '%';
        }
        // Debounced undo push — collect scroll ticks into one undo entry
        if (!knob._wheelUndoTimer) {
            knob._wheelOldVal = oldVal;
        } else {
            clearTimeout(knob._wheelUndoTimer);
        }
        knob._wheelUndoTimer = setTimeout(function () {
            if (p.v !== knob._wheelOldVal) pushParamUndo(pid, knob._wheelOldVal);
            knob._wheelUndoTimer = null;
        }, 400);
    }, { passive: false });

    // ── Double-click to reset param knob to default (0.5) ──
    document.addEventListener('dblclick', function (e) {
        var knob = e.target.closest('.pr-knob');
        if (!knob) return;
        e.preventDefault(); e.stopPropagation();
        var pid = knob.getAttribute('data-pid');
        var hid = parseInt(knob.getAttribute('data-hid'));
        var ri = parseInt(knob.getAttribute('data-ri'));
        var p = PMap[pid];
        if (!p || p.lk || isNaN(hid) || isNaN(ri)) return;
        var oldVal = p.v;
        var defaultVal = 0.5; // center position — universal default
        if (oldVal === defaultVal) return;
        p.v = defaultVal;
        var fn = getSetParam();
        if (fn) fn(hid, ri, defaultVal);
        pushParamUndo(pid, oldVal);
        // Update visuals
        knob.innerHTML = buildParamKnob(defaultVal, 30, null);
        var row = knob.closest('.pr');
        if (row) {
            var ve = row.querySelector('.pr-val');
            if (ve) ve.textContent = p.disp || ((defaultVal * 100).toFixed(0) + '%');
            var bf = row.querySelector('.pr-bar-f');
            if (bf) bf.style.width = '50%';
        }
    }, true);
})();

// ── Plugin card footer toolbar handlers ──
document.addEventListener('click', function (e) {
    // Randomize All
    var randBtn = e.target.closest('[data-pfrand]');
    if (randBtn) {
        e.stopPropagation();
        var pid = parseInt(randBtn.dataset.pfrand);
        var pb = null;
        for (var i = 0; i < pluginBlocks.length; i++) { if (pluginBlocks[i].id === pid) { pb = pluginBlocks[i]; break; } }
        if (!pb) return;
        var oldVals = [];
        pb.params.forEach(function (p) { if (!p.lk && !p.alk) oldVals.push({ id: p.id, val: p.v }); });
        var setFn = (window.__JUCE__ && window.__JUCE__.backend) ? window.__juceGetNativeFunction('setParam') : null;
        pb.params.forEach(function (p) {
            if (p.lk || p.alk) return;
            var nv = Math.random();
            p.v = nv;
            if (setFn && p.hostId !== undefined) setFn(p.hostId, p.realIndex, nv);
        });
        pushMultiParamUndo(oldVals);
        renderAllPlugins();
        return;
    }
    // Bypass toggle
    var bypBtn = e.target.closest('[data-pfbypass]');
    if (bypBtn) {
        e.stopPropagation();
        var pid = parseInt(bypBtn.dataset.pfbypass);
        var pb = null;
        for (var i = 0; i < pluginBlocks.length; i++) { if (pluginBlocks[i].id === pid) { pb = pluginBlocks[i]; break; } }
        if (!pb) return;
        pb.bypassed = !pb.bypassed;
        if (window.__JUCE__ && window.__JUCE__.backend) {
            var fn = window.__juceGetNativeFunction('setPluginBypass');
            fn(pb.hostId, pb.bypassed);
        }
        renderAllPlugins(); saveUiStateToHost();
        return;
    }
    // Snapshot dropdown toggle — build menu dynamically
    var snapBtn = e.target.closest('[data-pfsnap]');
    if (snapBtn) {
        e.stopPropagation();
        document.querySelectorAll('.pf-snap-menu.vis').forEach(function (m) { m.classList.remove('vis'); });
        var plugId = snapBtn.dataset.pfsnap;
        var menu = snapBtn.parentElement.querySelector('.pf-snap-menu');
        if (!menu) return;
        // Build menu content from current morph pad blocks
        var morphBlocks = (typeof getMorphBlocks === 'function') ? getMorphBlocks() : [];
        var mh = '';
        if (morphBlocks.length === 0) {
            mh = '<div class="pf-snap-item disabled">No morph pads</div>';
        } else {
            for (var mi = 0; mi < morphBlocks.length; mi++) {
                var mb = morphBlocks[mi];
                var full = mb.snapCount >= 12;
                mh += '<div class="pf-snap-item' + (full ? ' disabled' : '') + '" data-pfsnapblock="' + mb.id + '" data-pfsnappid="' + plugId + '"><span class="pf-dot" style="background:' + bColor(mb.colorIdx) + '"></span>Pad ' + (mb.idx + 1) + ' (' + mb.snapCount + '/12)' + (full ? ' Full' : '') + '</div>';
            }
        }
        menu.innerHTML = mh;
        // Position and show
        var rect = snapBtn.getBoundingClientRect();
        menu.style.left = (rect.left + window.scrollX) + 'px';
        menu.classList.add('vis');
        var menuH = menu.offsetHeight;
        if (rect.top - menuH - 4 > 0) {
            menu.style.top = (rect.top + window.scrollY - menuH - 4) + 'px';
        } else {
            menu.style.top = (rect.bottom + window.scrollY + 4) + 'px';
        }
        return;
    }
    // Snapshot select
    var snapItem = e.target.closest('[data-pfsnapblock]');
    if (snapItem && !snapItem.classList.contains('disabled')) {
        e.stopPropagation();
        var bid = parseInt(snapItem.dataset.pfsnapblock);
        var pid = parseInt(snapItem.dataset.pfsnappid);
        if (typeof addSnapshotToMorphBlock === 'function') addSnapshotToMorphBlock(bid, pid);
        var menu = snapItem.closest('.pf-snap-menu');
        if (menu) menu.classList.remove('vis');
        renderAllPlugins();
        return;
    }
    // Assign dropdown
    var assignBtn = e.target.closest('[data-pfassign]');
    if (assignBtn) {
        e.stopPropagation();
        document.querySelectorAll('.pf-snap-menu.vis').forEach(function (m) { m.classList.remove('vis'); });
        var plugId = assignBtn.dataset.pfassign;
        var menu = assignBtn.parentElement.querySelector('[data-pfassignmenu]');
        if (!menu || blocks.length === 0) return;
        var mh = '';
        for (var bi = 0; bi < blocks.length; bi++) {
            var bl = blocks[bi];
            mh += '<div class="pf-snap-item" data-pfassignblk="' + bl.id + '" data-pfassignplug="' + plugId + '"><span class="pf-dot" style="background:' + bColor(bl.colorIdx) + '"></span>Block ' + (bi + 1) + ' (' + bl.mode + ')</div>';
        }
        menu.innerHTML = mh;
        var rect = assignBtn.getBoundingClientRect();
        menu.style.left = (rect.left + window.scrollX) + 'px';
        menu.classList.add('vis');
        var menuH = menu.offsetHeight;
        menu.style.top = (rect.top - menuH - 4 > 0) ? (rect.top + window.scrollY - menuH - 4) + 'px' : (rect.bottom + window.scrollY + 4) + 'px';
        return;
    }
    // Assign select
    var assignItem = e.target.closest('[data-pfassignblk]');
    if (assignItem) {
        e.stopPropagation();
        var bid = parseInt(assignItem.dataset.pfassignblk);
        var plugId = parseInt(assignItem.dataset.pfassignplug);
        var bl = findBlock(bid);
        var pb = null;
        for (var i = 0; i < pluginBlocks.length; i++) { if (pluginBlocks[i].id === plugId) { pb = pluginBlocks[i]; break; } }
        if (bl && pb) {
            var pids = selectedParams.size > 0 ? Array.from(selectedParams) : pb.params.filter(function (p) { return !p.lk; }).map(function (p) { return p.id; });
            pids.forEach(function (pid) { var pp = PMap[pid]; if (pp && !pp.lk) assignTarget(bl, pid); });
            selectedParams.clear();
            renderAllPlugins(); renderBlocks(); syncBlocksToHost();
        }
        var menu = assignItem.closest('.pf-snap-menu');
        if (menu) menu.classList.remove('vis');
        return;
    }
    // Unassign dropdown
    var unassignBtn = e.target.closest('[data-pfunassign]');
    if (unassignBtn) {
        e.stopPropagation();
        document.querySelectorAll('.pf-snap-menu.vis').forEach(function (m) { m.classList.remove('vis'); });
        var plugId = unassignBtn.dataset.pfunassign;
        var menu = unassignBtn.parentElement.querySelector('[data-pfunassignmenu]');
        if (!menu || blocks.length === 0) return;
        var mh = '';
        for (var bi = 0; bi < blocks.length; bi++) {
            var bl = blocks[bi];
            mh += '<div class="pf-snap-item" data-pfunassignblk="' + bl.id + '" data-pfunassignplug="' + plugId + '"><span class="pf-dot" style="background:' + bColor(bl.colorIdx) + '"></span>Block ' + (bi + 1) + ' (' + bl.mode + ')</div>';
        }
        menu.innerHTML = mh;
        var rect = unassignBtn.getBoundingClientRect();
        menu.style.left = (rect.left + window.scrollX) + 'px';
        menu.classList.add('vis');
        var menuH = menu.offsetHeight;
        menu.style.top = (rect.top - menuH - 4 > 0) ? (rect.top + window.scrollY - menuH - 4) + 'px' : (rect.bottom + window.scrollY + 4) + 'px';
        return;
    }
    // Unassign select
    var unassignItem = e.target.closest('[data-pfunassignblk]');
    if (unassignItem) {
        e.stopPropagation();
        var bid = parseInt(unassignItem.dataset.pfunassignblk);
        var plugId = parseInt(unassignItem.dataset.pfunassignplug);
        var bl = findBlock(bid);
        var pb = null;
        for (var i = 0; i < pluginBlocks.length; i++) { if (pluginBlocks[i].id === plugId) { pb = pluginBlocks[i]; break; } }
        if (bl && pb) {
            var pids = selectedParams.size > 0 ? Array.from(selectedParams) : pb.params.map(function (p) { return p.id; });
            pids.forEach(function (pid) { bl.targets.delete(pid); });
            selectedParams.clear();
            renderAllPlugins(); renderBlocks(); syncBlocksToHost();
        }
        var menu = unassignItem.closest('.pf-snap-menu');
        if (menu) menu.classList.remove('vis');
        return;
    }
    // Close any open dropdown menus
    document.querySelectorAll('.pf-snap-menu.vis').forEach(function (m) { m.classList.remove('vis'); });
});
