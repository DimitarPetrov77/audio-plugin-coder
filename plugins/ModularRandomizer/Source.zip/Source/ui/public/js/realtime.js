var _lastBpmDisplay = 0, _bpmThrottle = 0, _lastLocateTime = 0;
function processRealTimeData() {
    // Clear consumed MIDI events
    rtData.midi = [];

    // Update live BPM display (~4 Hz throttle)
    if (++_bpmThrottle >= 15) {
        _bpmThrottle = 0;
        var bpm = Math.round(rtData.bpm || 0);
        if (bpm !== _lastBpmDisplay) {
            _lastBpmDisplay = bpm;
            var el = document.getElementById('bpmDisplay');
            if (el) el.textContent = (bpm > 0 ? bpm : '\u2014') + ' BPM';
        }
    }

    requestAnimationFrame(processRealTimeData);
}

// Fast display update — ONLY touches param rows that actually changed
// dirtyParams: Set of PIDs that changed since last refresh
var _dirtyParams = new Set();
// Params currently being dragged via our UI knobs — skip polling updates
var _touchedByUI = new Set();

function refreshParamDisplay() {
    if (_dirtyParams.size === 0) return;

    // Pre-compute shapes_range info for arc display
    var srBlk = null, srCol = '';
    if (assignMode) {
        var ab = findBlock(assignMode);
        if (ab && ab.mode === 'shapes_range') {
            srBlk = ab;
            srCol = bColor(ab.colorIdx);
        }
    }
    var srBlocks = [];
    if (!srBlk) {
        for (var sbi = 0; sbi < blocks.length; sbi++) {
            if (blocks[sbi].mode === 'shapes_range' && blocks[sbi].enabled !== false) srBlocks.push(blocks[sbi]);
        }
    }

    // ── Build the set of PIDs that are actually visible on screen ──
    // This walks each expanded plugin's scroll container ONCE,
    // checking only children in the viewport. Collapsed plugins = 0 work.
    // Result: _visPids contains only the ~6-8 PIDs the user can see.
    var _visPids = new Set();
    if (typeof pluginBlocks !== 'undefined') {
        for (var pi = 0; pi < pluginBlocks.length; pi++) {
            var pb = pluginBlocks[pi];
            if (!pb.expanded) continue; // collapsed → zero visible rows

            var container = document.querySelector('[data-plugparams="' + pb.id + '"]');
            if (!container) continue;

            var st = container.scrollTop;
            var ch = container.clientHeight;
            if (ch <= 0) continue;

            // Walk children (param rows). position:relative on container means
            // child.offsetTop is relative to the container's padding edge.
            // Children are in DOM order = visual order. Once past the bottom, stop.
            var children = container.children;
            for (var ci = 0; ci < children.length; ci++) {
                var child = children[ci];
                // Skip search-filtered rows (display:none → zero height → skip)
                if (child.offsetHeight === 0) continue;
                var ot = child.offsetTop;
                if (ot + child.offsetHeight < st) continue; // above viewport
                if (ot > st + ch) break; // below viewport — all remaining are too
                var cpid = child.getAttribute('data-pid');
                if (cpid) _visPids.add(cpid);
            }
        }
    }

    // ── Update only visible dirty params ──
    // For non-visible PIDs: PMap is already updated, so when they scroll into
    // view or card expands, dirtyPluginParams() will repaint them.
    _dirtyParams.forEach(function (pid) {
        if (!_visPids.has(pid)) return; // not visible → skip all DOM work

        var p = PMap[pid];
        if (!p) return;

        var row = document.querySelector('.pr[data-pid="' + pid + '"]');
        if (!row) return;

        // Update value text
        var ve = row.querySelector('.pr-val');
        if (ve) ve.textContent = p.disp || ((p.v * 100).toFixed(0) + '%');

        // Update knob SVG
        var knobEl = row.querySelector('.pr-knob');
        if (knobEl && typeof buildParamKnob === 'function') {
            var ri = null;
            if (srBlk && srBlk.targets.has(pid)) {
                var rng = srBlk.targetRanges && srBlk.targetRanges[pid] !== undefined ? srBlk.targetRanges[pid] : 0;
                var base = srBlk.targetRangeBases && srBlk.targetRangeBases[pid] !== undefined ? srBlk.targetRangeBases[pid] : p.v;
                ri = { range: rng, base: base, color: srCol, polarity: srBlk.shapePolarity || 'bipolar' };
            } else if (!srBlk) {
                for (var sri = 0; sri < srBlocks.length; sri++) {
                    var sb = srBlocks[sri];
                    if (sb.targets.has(pid)) {
                        var rng = sb.targetRanges && sb.targetRanges[pid] !== undefined ? sb.targetRanges[pid] : 0;
                        if (Math.abs(rng) > 0.001) {
                            var base = sb.targetRangeBases && sb.targetRangeBases[pid] !== undefined ? sb.targetRangeBases[pid] : p.v;
                            ri = { range: rng, base: base, color: bColor(sb.colorIdx), polarity: sb.shapePolarity || 'bipolar' };
                        }
                        break;
                    }
                }
            }
            knobEl.innerHTML = buildParamKnob(p.v, 30, ri);
        }

        // Update bar
        var be = row.querySelector('.pr-bar-f');
        if (be) be.style.width = (p.v * 100) + '%';
    });

    _dirtyParams.clear();
}

// Listen for real-time data from C++ backend
function setupRtDataListener() {
    if (window.__JUCE__ && window.__JUCE__.backend) {
        window.__JUCE__.backend.addEventListener('__rt_data__', function (data) {
            if (data) {
                rtData.rms = data.rms || 0;
                rtData.scRms = data.scRms || 0;
                rtData.bpm = data.bpm || 120;
                rtData.playing = data.playing || false;
                rtData.ppq = data.ppq || 0;
                if (data.midi && data.midi.length) {
                    rtData.midi = rtData.midi.concat(data.midi);
                }

                // Envelope follower levels from C++ (visual display)
                if (data.envLevels && data.envLevels.length) {
                    for (var ei = 0; ei < data.envLevels.length; ei++) {
                        var en = data.envLevels[ei];
                        var cl = Math.max(0, Math.min(1, en.level));
                        var pct = (cl * 100);
                        // Fill bar — direct set, no CSS transition
                        var fl = document.getElementById('envFill-' + en.id);
                        if (fl) fl.style.height = pct + '%';
                        // Label
                        var lb = document.getElementById('envLbl-' + en.id);
                        if (lb) lb.textContent = pct.toFixed(0) + '%';
                        // Peak hold line — jumps up instantly, decays slowly via CSS transition
                        var pk = document.getElementById('envPeak-' + en.id);
                        if (pk) {
                            var curPeak = parseFloat(pk._peak || 0);
                            if (pct >= curPeak) {
                                // New peak — snap up instantly (disable transition momentarily)
                                pk.style.transition = 'none';
                                pk.style.bottom = pct + '%';
                                pk.style.opacity = '0.9';
                                pk._peak = pct;
                                pk._peakTime = Date.now();
                                // Force reflow then re-enable transition for decay
                                void pk.offsetWidth;
                                pk.style.transition = 'bottom 1.2s ease-out, opacity 1.5s ease-out';
                            } else if (Date.now() - (pk._peakTime || 0) > 300) {
                                // Hold for 300ms then start decay
                                pk._peak = pct;
                                pk.style.bottom = pct + '%';
                                pk.style.opacity = '0.3';
                            }
                        }
                        // Active dot — brightness driven by actual level
                        var dot = document.getElementById('envDot-' + en.id);
                        if (dot) dot.style.opacity = (0.3 + cl * 0.7).toFixed(2);
                    }
                }

                // Sample playhead positions from C++
                if (data.sampleHeads && data.sampleHeads.length) {
                    for (var si = 0; si < data.sampleHeads.length; si++) {
                        var sh = data.sampleHeads[si];
                        var head = document.getElementById('waveHead-' + sh.id);
                        if (head) {
                            // Use cached parent width to avoid layout reflow every frame
                            if (!head._pw) {
                                var cv = document.getElementById('waveCv-' + sh.id);
                                head._pw = cv ? cv.width : 260;
                            }
                            head.style.transform = 'translateX(' + (sh.pos * head._pw).toFixed(1) + 'px)';
                        }
                    }
                }

                // Trigger fire events from C++ (visual flash + undo snapshot)
                if (data.trigFired && data.trigFired.length) {
                    // Capture old values of affected params before they're updated
                    var oldVals = [];
                    data.trigFired.forEach(function (tf) {
                        var blk = findBlock(tf.id || tf);
                        if (blk && blk.targets) {
                            blk.targets.forEach(function (pid) {
                                var p = PMap[pid];
                                if (p && !p.lk && !p.alk) oldVals.push({ id: pid, val: p.v });
                            });
                        }
                    });
                    if (oldVals.length) pushMultiParamUndo(oldVals);
                    data.trigFired.forEach(function () { flashDot('midiD'); });
                }

                // Sync hosted plugin parameter values into PMap
                // C++ is the single source of truth for all param values
                if (data.params && data.params.length) {
                    for (var i = 0; i < data.params.length; i++) {
                        var up = data.params[i];
                        var p = PMap[up.id];
                        if (!p) continue;
                        var isTouched = _touchedByUI.has(up.id);
                        var changed = false;
                        // Skip VALUE update for params being dragged (prevents snapping)
                        // but always accept display text so we show real values during drag
                        if (!isTouched && Math.abs(p.v - up.v) > 0.001) {
                            p.v = up.v;
                            changed = true;
                        }
                        // Always sync display text from C++ (plugin is source of truth)
                        if (up.disp !== undefined && up.disp !== p.disp) {
                            p.disp = up.disp;
                            changed = true;
                        }
                        if (changed) _dirtyParams.add(up.id);
                    }
                    if (_dirtyParams.size > 0) refreshParamDisplay();
                }

                // Auto-locate: scroll to and flash the touched param
                if (autoLocate && data.touchedParam && !assignMode) {
                    var pid = data.touchedParam;
                    var now = Date.now();
                    if (now - _lastLocateTime > 200) {
                        _lastLocateTime = now;
                        // Ensure the plugin card containing this param is expanded
                        var pp = PMap[pid];
                        if (pp) {
                            for (var pbi = 0; pbi < pluginBlocks.length; pbi++) {
                                var pb = pluginBlocks[pbi];
                                if (pb.id === pp.hostId && !pb.expanded) {
                                    pb.expanded = true;
                                    renderAllPlugins();
                                    break;
                                }
                            }
                        }
                        // Find the row and scroll + flash
                        var row = document.querySelector('.pr[data-pid="' + pid + '"]');
                        if (row) {
                            row.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
                            row.classList.remove('touched');
                            void row.offsetWidth; // force reflow to restart animation
                            row.classList.add('touched');
                        }
                    }
                }
                // Morph pad playhead readback
                if (data.morphHeads) {
                    for (var mi = 0; mi < data.morphHeads.length; mi++) {
                        var mh = data.morphHeads[mi];
                        var mb = findBlock(mh.id);
                        if (mb && mb.mode === 'morph_pad' && mb.morphMode !== 'manual') {
                            mb.playheadX = mh.x;
                            mb.playheadY = mh.y;
                            var dot = document.getElementById('morphHead-' + mh.id);
                            if (dot) {
                                dot.style.left = (mh.x * 100) + '%';
                                dot.style.top = ((1 - mh.y) * 100) + '%';
                            }
                            // Sync SVG rotation with actual C++ rotation angle
                            if (mh.rot !== undefined) {
                                var svg = document.querySelector('.morph-pad[data-b="' + mh.id + '"]:not(.shapes-pad) .lfo-path-svg');
                                if (svg) {
                                    var deg = (mh.rot * 180 / Math.PI) * -1;
                                    svg.style.transform = 'rotate(' + deg.toFixed(1) + 'deg)';
                                }
                            }
                        }
                        // Shapes block dot + SVG rotation + readout line
                        if (mb && (mb.mode === 'shapes' || mb.mode === 'shapes_range')) {
                            var dot = document.getElementById('shapeHead-' + mh.id);
                            if (dot) {
                                dot.style.left = (mh.x * 100) + '%';
                                dot.style.top = ((1 - mh.y) * 100) + '%';
                            }
                            if (mh.rot !== undefined) {
                                var svg = document.querySelector('.shapes-pad[data-b="' + mh.id + '"] .lfo-path-svg');
                                if (svg) {
                                    var deg = (mh.rot * 180 / Math.PI) * -1;
                                    svg.style.transform = 'rotate(' + deg.toFixed(1) + 'deg)';
                                }
                            }
                            // Update readout line position
                            var readout = document.getElementById('shapeReadout-' + mh.id);
                            if (readout) {
                                var tracking = mb.shapeTracking || 'horizontal';
                                if (tracking === 'horizontal') {
                                    readout.style.left = (mh.x * 100) + '%';
                                } else if (tracking === 'vertical') {
                                    readout.style.top = ((1 - mh.y) * 100) + '%';
                                } else {
                                    // Distance: circle radius = distance from center
                                    var ddx = mh.x - 0.5, ddy = mh.y - 0.5;
                                    var dist = Math.sqrt(ddx * ddx + ddy * ddy) * 2; // diameter as fraction
                                    var pxSize = dist * 200; // pad is 200px
                                    readout.style.width = pxSize + 'px';
                                    readout.style.height = pxSize + 'px';
                                }
                            }
                        }
                    }
                }
                // Lane playhead readback — pixel-exact, no transitions
                if (data.laneHeads) {
                    for (var li = 0; li < data.laneHeads.length; li++) {
                        var lh = data.laneHeads[li];
                        var ph = document.getElementById('lph-' + lh.id + '-' + lh.li);
                        if (ph) {
                            // Cache parent width to avoid layout reflow every frame
                            if (!ph._wPx) {
                                var wrap = ph.parentElement;
                                ph._wPx = wrap ? wrap.clientWidth : 300;
                            }
                            ph.style.transform = 'translateX(' + (lh.ph * ph._wPx) + 'px)';
                        }
                        var vi = document.getElementById('lvi-' + lh.id + '-' + lh.li);
                        if (vi) vi.style.height = (lh.val * 100) + '%';
                    }
                }
            }
        });
        return true;
    }
    return false;
}
if (!setupRtDataListener()) {
    var rtRetry = setInterval(function () { if (setupRtDataListener()) clearInterval(rtRetry); }, 100);
}

// ============================================================
// CRASH NOTIFICATION LISTENER
// Shows a toast when a hosted plugin crashes during audio processing
// ============================================================
function setupCrashListener() {
    if (window.__JUCE__ && window.__JUCE__.backend) {
        window.__JUCE__.backend.addEventListener('__plugin_crashed__', function (data) {
            if (!data) return;
            showCrashToast(data.pluginId, data.pluginName, data.reason);
        });
        return true;
    }
    return false;
}

function showCrashToast(pluginId, pluginName, reason) {
    // Create toast container if it doesn't exist
    var container = document.getElementById('crash-toast-container');
    if (!container) {
        container = document.createElement('div');
        container.id = 'crash-toast-container';
        container.style.cssText = 'position:fixed;top:12px;right:12px;z-index:99999;display:flex;flex-direction:column;gap:8px;pointer-events:none;';
        document.body.appendChild(container);
    }

    var toast = document.createElement('div');
    toast.className = 'crash-toast';
    toast.style.cssText = 'pointer-events:auto;background:linear-gradient(135deg,#4a1010,#2a0808);border:1px solid #ff3333;border-radius:8px;padding:12px 16px;color:#fff;font-size:12px;font-family:inherit;box-shadow:0 4px 24px rgba(255,0,0,0.3);display:flex;align-items:center;gap:10px;animation:crashSlideIn 0.3s ease-out;max-width:380px;';

    var icon = document.createElement('span');
    icon.textContent = '\u26A0';
    icon.style.cssText = 'font-size:20px;color:#ff4444;flex-shrink:0;';

    var textDiv = document.createElement('div');
    textDiv.style.cssText = 'flex:1;';

    var title = document.createElement('div');
    title.style.cssText = 'font-weight:600;font-size:13px;color:#ff6666;margin-bottom:3px;';
    title.textContent = pluginName + ' crashed';

    var body = document.createElement('div');
    body.style.cssText = 'font-size:11px;color:#ccc;line-height:1.3;';
    body.textContent = 'Auto-bypassed to protect your session.';

    textDiv.appendChild(title);
    textDiv.appendChild(body);

    var btnWrap = document.createElement('div');
    btnWrap.style.cssText = 'display:flex;gap:6px;flex-shrink:0;';

    var reEnBtn = document.createElement('button');
    reEnBtn.textContent = 'Re-enable';
    reEnBtn.style.cssText = 'background:#333;border:1px solid #ff6666;color:#ff8888;border-radius:4px;padding:4px 10px;cursor:pointer;font-size:11px;font-family:inherit;';
    reEnBtn.onmouseenter = function () { reEnBtn.style.background = '#4a1515'; };
    reEnBtn.onmouseleave = function () { reEnBtn.style.background = '#333'; };
    reEnBtn.onclick = function () {
        var fn = window.__juceGetNativeFunction('resetPluginCrash');
        if (fn) fn(pluginId);
        toast.style.animation = 'crashSlideOut 0.2s ease-in forwards';
        setTimeout(function () { if (toast.parentNode) toast.parentNode.removeChild(toast); }, 200);
    };

    var dismissBtn = document.createElement('button');
    dismissBtn.textContent = '\u2715';
    dismissBtn.style.cssText = 'background:none;border:none;color:#888;cursor:pointer;font-size:16px;padding:0 4px;line-height:1;';
    dismissBtn.onclick = function () {
        toast.style.animation = 'crashSlideOut 0.2s ease-in forwards';
        setTimeout(function () { if (toast.parentNode) toast.parentNode.removeChild(toast); }, 200);
    };

    btnWrap.appendChild(reEnBtn);
    btnWrap.appendChild(dismissBtn);

    toast.appendChild(icon);
    toast.appendChild(textDiv);
    toast.appendChild(btnWrap);
    container.appendChild(toast);

    // Auto-dismiss after 10s
    setTimeout(function () {
        if (toast.parentNode) {
            toast.style.animation = 'crashSlideOut 0.2s ease-in forwards';
            setTimeout(function () { if (toast.parentNode) toast.parentNode.removeChild(toast); }, 200);
        }
    }, 10000);
}

// Inject crash toast animation keyframes
(function () {
    var style = document.createElement('style');
    style.textContent = '@keyframes crashSlideIn{from{transform:translateX(100%);opacity:0}to{transform:translateX(0);opacity:1}}@keyframes crashSlideOut{from{transform:translateX(0);opacity:1}to{transform:translateX(100%);opacity:0}}';
    document.head.appendChild(style);
})();

if (!setupCrashListener()) {
    var crashRetry = setInterval(function () { if (setupCrashListener()) clearInterval(crashRetry); }, 100);
}
