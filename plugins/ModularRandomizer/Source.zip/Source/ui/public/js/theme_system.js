// ============================================================
// THEME SYSTEM
// Theme definitions and switching logic
// ============================================================

var THEMES = {
    earthy: {
        name: 'Earthy',
        vars: {
            '--bg-app': '#1E1610', '--bg-panel': '#2C2418', '--bg-cell': '#3C3228',
            '--bg-cell-hover': '#4A3E34', '--bg-inset': '#141008',
            '--border': '#5C4E3C', '--border-strong': '#7A6A54', '--border-focus': '#9A8870',
            '--text-primary': '#F8F4EC', '--text-secondary': '#DCD0BC', '--text-muted': '#B8A888',
            '--input-text': '#F8F4EC',
            '--accent': '#E8A244', '--accent-hover': '#D48E38',
            '--accent-light': 'rgba(232,162,68,0.20)', '--accent-border': 'rgba(232,162,68,0.55)',
            '--locked-bg': 'rgba(200,65,50,0.22)', '--locked-border': 'rgba(200,65,50,0.50)',
            '--locked-icon': '#E05848',
            '--auto-lock-bg': 'rgba(210,180,60,0.18)', '--auto-lock-border': 'rgba(210,180,60,0.42)',
            '--midi-dot': '#78CC60', '--rand-color': '#E8A244',
            '--env-color': '#D4B83C', '--sample-color': '#CC6240',
            '--morph-color': '#5C6BC0',
            '--thumb-color': '#F4ECD8',
            '--knob-track': '#5C4E3C', '--knob-value': '#E8A244', '--knob-dot': '#F4D090',
            '--pf-bg': '#2A2014', '--pf-border': '#5C4E3C', '--pf-text': '#C8B898',
            '--ph-bg': '#2A2014', '--ph-border': '#5C4E3C', '--ph-text': '#F8F4EC',
            '--shapes-color': '#A070D0',
            '--lk-rand-track': '#5C4E3C', '--lk-rand-value': '#E8A244', '--lk-rand-dot': '#F4D090',
            '--lk-env-track': '#4A4020', '--lk-env-value': '#D4B83C', '--lk-env-dot': '#E8D070',
            '--lk-smp-track': '#4A2820', '--lk-smp-value': '#CC6240', '--lk-smp-dot': '#E09070',
            '--lk-morph-track': '#34305A', '--lk-morph-value': '#5C6BC0', '--lk-morph-dot': '#8890D8',
            '--lk-shapes-track': '#443060', '--lk-shapes-value': '#A070D0', '--lk-shapes-dot': '#C098E0',
            '--si-rand-bg': 'rgba(232,162,68,0.25)', '--si-env-bg': 'rgba(212,184,60,0.25)', '--si-smp-bg': 'rgba(204,98,64,0.25)', '--si-morph-bg': 'rgba(92,107,192,0.25)', '--si-shapes-bg': 'rgba(160,112,208,0.25)',
            '--fire-text': '#1E1610', '--fire-active-bg': '#C08030',
            '--arc-color': '#E8A244', '--arc-opacity': '0.45',
            '--slider-track': '#7A6A54', '--slider-thumb': '#F4ECD8',
            '--bar-track': '#3C3020', '--bar-fill': '#D4943A',
            '--card-btn-bg': '#2A2014', '--card-btn-border': '#5C4E3C', '--card-btn-text': '#C8B898', '--card-btn-hover': '#3A3024',
            '--snap-ring-color': '#5C6BC0', '--snap-ring-opacity': '0.6',
            '--lane-color': '#B89050', '--lane-grid': 'rgba(248,244,236,0.08)', '--lane-grid-label': 'rgba(248,244,236,0.15)',
            '--lane-playhead': 'rgba(248,244,236,0.65)', '--lane-active': '#78CC60',
            '--range-arc': '#E8A244', '--scrollbar-thumb': '#5C4E3C', '--scrollbar-track': 'transparent',
            '--bus-mute-bg': '#CC4444', '--bus-mute-text': '#fff',
            '--bus-solo-bg': '#CCAA33', '--bus-solo-text': '#1a1a1a',
            '--bus-group-tint': '6%', '--bus-header-tint': '12%',
            '--toast-success-bg': 'linear-gradient(135deg,#1A2E12,#102008)', '--toast-success-border': '#78CC60',
            '--toast-error-bg': 'linear-gradient(135deg,#3A1810,#2A0808)', '--toast-error-border': '#E05848',
            '--toast-info-bg': 'linear-gradient(135deg,#1A2014,#0E1408)', '--toast-info-border': '#E8A244',
            '--toast-text': '#F8F4EC',
            '--preset-flash-color': '#78CC60', '--preset-flash-glow': 'rgba(120,204,96,0.5)'
        },
        bcolors: ['#E8A244', '#78CC60', '#CC6240', '#70A0C4', '#D48430', '#68A878', '#C47858', '#88B058'],
        busColors: ['#888', '#4ECDC4', '#D4884C', '#78B060', '#C4885C', '#D0A848', '#9C7CB8'],
        swatches: ['#1E1610', '#3C3228', '#E8A244', '#D4B83C', '#CC6240']
    },
    // ═══════════════════════════════════════════════════════════
    // MODULAR RANDOMIZER — DAW HIERARCHY THEME
    //
    // LAYER MODEL (darkest → brightest):
    //   L0 #0C1416  app chrome / background — recedes completely
    //   L1 #182022  panel surfaces — plugin blocks, block headers
    //   L2 #1E2A2C  content areas — lane canvas bg, param lists
    //   L3 #263436  interactive cells — hovered rows, active cells
    //   L4 #0A1214  inset / sunken — dark wells, below-surface
    //
    // COLOR ROLES (one meaning per color):
    //   #00C8B4  teal    → primary action / brand / rand mode
    //   #E8A030  amber   → envelope mode / time-based / warm
    //   #4AC8E8  sky     → sample mode / digital / cool
    //   #A0D860  lime    → morph mode / organic transition
    //   #E87040  coral   → shapes mode / geometric
    //   #44DD66  green   → status good / running / active handle
    //   #EE5555  red     → error / locked / mute
    //   #C8A000  yellow  → solo / warning
    //   #FFFFFF  white   → playhead (highest-contrast element when playing)
    // ═══════════════════════════════════════════════════════════

    daw_teal: {
        name: 'DAW Teal',
        vars: {
            // BACKGROUNDS
            '--bg-app': '#0C1416',   // L0 — outer chrome, recedes
            '--bg-panel': '#182022',   // L1 — panel surfaces
            '--bg-cell': '#1E2A2C',   // L2 — content, canvas bg
            '--bg-cell-hover': '#263436',   // L3 — hovered rows
            '--bg-inset': '#0A1214',   // L4 — sunken/inset wells

            // BORDERS — #627476 = 3.37:1 on panel (WCAG 1.4.11 non-text chrome ✅)
            '--border': '#627476',   // structural dividers
            '--border-strong': '#748E90',   // 4.74:1 — section edges, emphasized separators
            '--border-focus': '#00C8B4',   // teal focus ring — focused inputs only

            // TEXT — all verified 4.5:1+
            '--text-primary': '#E8F4F4',   // 14.72:1 on panel ✅
            '--text-secondary': '#8ABCBE',   //  7.90:1 on panel ✅
            '--text-muted': '#7A9496',   //  5.13:1 on panel, 4.57:1 on cell ✅
            '--input-text': '#E8F4F4',

            // ACCENT — teal, ONE role: primary interactive action
            '--accent': '#00C8B4',   // 7.82:1 on panel ✅
            '--accent-hover': '#00E8D0',
            '--accent-light': 'rgba(0,200,180,0.10)',
            '--accent-border': 'rgba(0,200,180,0.35)',

            // STATUS
            '--midi-dot': '#44DD66',   // green — running/synced

            '--locked-bg': 'rgba(238,85,85,0.12)',
            '--locked-border': 'rgba(238,85,85,0.35)',
            '--locked-icon': '#EE5555',   // 5.61:1 on locked-bg ✅

            '--auto-lock-bg': 'rgba(232,160,48,0.12)',
            '--auto-lock-border': 'rgba(232,160,48,0.35)',

            // MODE COLORS — all 4.5:1+ on bg-panel, distinct hue families
            '--rand-color': '#00C8B4',   //  7.82:1 teal
            '--env-color': '#E8A030',   //  7.49:1 amber
            '--sample-color': '#4AC8E8',   //  8.45:1 sky blue
            '--morph-color': '#A0D860',   //  9.84:1 lime
            '--shapes-color': '#E87040',   //  5.38:1 coral

            '--thumb-color': '#B8D0D0',

            // KNOBS
            '--knob-track': '#1A2C2E',   // dark tinted base
            '--knob-value': '#00C8B4',   // teal arc
            '--knob-dot': '#80EEE0',   // bright tip

            // PLUGIN CARD
            '--pf-bg': '#0E1A1C',   // darker than panel — card chrome recedes
            '--pf-border': '#627476',
            '--pf-text': '#8ABCBE',   // 8.47:1 on pf-bg ✅

            '--ph-bg': '#0E1A1C',
            '--ph-border': '#627476',
            '--ph-text': '#E8F4F4',   // 15.79:1 ✅

            // PER-MODE LINKED KNOBS
            '--lk-rand-track': '#0E1E1C', '--lk-rand-value': '#00C8B4', '--lk-rand-dot': '#60EED8',
            '--lk-env-track': '#1E1808', '--lk-env-value': '#E8A030', '--lk-env-dot': '#FFCC70',
            '--lk-smp-track': '#0C1820', '--lk-smp-value': '#4AC8E8', '--lk-smp-dot': '#90E4F8',
            '--lk-morph-track': '#141C08', '--lk-morph-value': '#A0D860', '--lk-morph-dot': '#C8F080',
            '--lk-shapes-track': '#1C1008', '--lk-shapes-value': '#E87040', '--lk-shapes-dot': '#FFA070',

            // SOURCE INDICATORS
            '--si-rand-bg': 'rgba(0,200,180,0.12)',
            '--si-env-bg': 'rgba(232,160,48,0.12)',
            '--si-smp-bg': 'rgba(74,200,232,0.12)',
            '--si-morph-bg': 'rgba(160,216,96,0.12)',
            '--si-shapes-bg': 'rgba(232,112,64,0.12)',

            // FIRE BUTTON
            '--fire-text': '#0A1414',   // 8.83:1 on teal ✅
            '--fire-active-bg': '#00C8B4',

            // ARC / RANGE
            '--arc-color': '#00C8B4',
            '--arc-opacity': '0.50',

            // SLIDER
            '--slider-track': '#3A5C60',
            '--slider-thumb': '#D0E8E8',

            // PARAM BAR
            '--bar-track': '#0E1E20',
            '--bar-fill': '#00A898',

            // CARD BUTTONS
            '--card-btn-bg': '#0E1A1C',
            '--card-btn-border': '#627476',
            '--card-btn-text': '#8ABCBE',
            '--card-btn-hover': '#182428',

            // SNAP RING
            '--snap-ring-color': '#00C8B4',
            '--snap-ring-opacity': '0.55',

            // LANE / AUTOMATION
            // Canvas is DARKER than panel — like Ableton arrangement view.
            // The curve pops out of the dark field.
            // Playhead is the BRIGHTEST element — near white at 80% opacity.
            '--lane-color': '#4AC8E8',               // sky blue curve — distinct from teal accent
            '--lane-grid': 'rgba(232,244,244,0.06)', // barely visible grid
            '--lane-grid-label': 'rgba(232,244,244,0.18)', // slightly more visible bar numbers
            '--lane-playhead': 'rgba(255,255,255,0.80)', // near-white — most visible when playing
            '--lane-active': '#44DD66',                // green control point — distinct from curve

            // RANGE ARC
            '--range-arc': '#00C8B4',

            // SCROLLBAR
            '--scrollbar-thumb': '#627476',
            '--scrollbar-track': 'transparent',

            // BUS CONTROLS — universal DAW conventions
            '--bus-mute-bg': '#CC2222',  // red mute — always red in every DAW
            '--bus-mute-text': '#FFFFFF',  // 5.50:1 ✅
            '--bus-solo-bg': '#C8A000',  // yellow solo — always yellow in every DAW
            '--bus-solo-text': '#000000',  // 8.48:1 ✅
            '--bus-group-tint': '8%',
            '--bus-header-tint': '16%',

            // TOAST / FLASH
            '--toast-success-bg': 'linear-gradient(135deg,#0A2018,#061410)',
            '--toast-success-border': '#44DD66',
            '--toast-error-bg': 'linear-gradient(135deg,#2A0808,#1A0404)',
            '--toast-error-border': '#EE5555',
            '--toast-info-bg': 'linear-gradient(135deg,#081820,#041014)',
            '--toast-info-border': '#00C8B4',
            '--toast-text': '#E8F4F4',
            '--preset-flash-color': '#44DD66',
            '--preset-flash-glow': 'rgba(68,221,102,0.45)',
        },

        bcolors: [
            '#00C8B4',  // teal   — rand
            '#E8A030',  // amber  — envelope
            '#4AC8E8',  // sky    — sample
            '#A0D860',  // lime   — morph
            '#E87040',  // coral  — shapes
            '#44DD66',  // green  — active
            '#8ABCBE',  // muted teal
            '#C8D8D8',  // near-white
        ],

        busColors: [
            '#2A3C3E',  // neutral
            '#00C8B4',  // teal
            '#CC2222',  // red
            '#4AC8E8',  // sky
            '#E8A030',  // amber
            '#A0D860',  // lime
            '#E87040',  // coral
        ],

        swatches: ['#0C1416', '#1E2A2C', '#E8F4F4', '#00C8B4', '#E8A030']
    },
    grey: {
        name: 'Grey',
        vars: {
            '--bg-app': '#A8A8A8', '--bg-panel': '#C0C0C0', '--bg-cell': '#E8E8E8',
            '--bg-cell-hover': '#DEDEDE', '--bg-inset': '#D0D0D0',
            '--border': '#6E6E6E', '--border-strong': '#525252', '--border-focus': '#333333',
            '--text-primary': '#111111', '--text-secondary': '#2A2A2A', '--text-muted': '#585858',
            '--input-text': '#111111',
            '--accent': '#3A6E94', '--accent-hover': '#2E5E84',
            '--accent-light': 'rgba(58,110,148,0.22)', '--accent-border': 'rgba(58,110,148,0.45)',
            '--locked-bg': 'rgba(200,30,30,0.14)', '--locked-border': 'rgba(200,30,30,0.35)',
            '--locked-icon': '#AA1818',
            '--auto-lock-bg': 'rgba(90,110,140,0.16)', '--auto-lock-border': 'rgba(90,110,140,0.35)',
            '--midi-dot': '#1E8E1E', '--rand-color': '#3A6E94',
            '--env-color': '#2E7A6A', '--sample-color': '#7A48A0',
            '--morph-color': '#3090E0',
            '--thumb-color': '#FFFFFF',
            '--knob-track': '#888888', '--knob-value': '#3A6E94', '--knob-dot': '#5088B0',
            '--pf-bg': '#CACACA', '--pf-border': '#787878', '--pf-text': '#555555',
            '--ph-bg': '#D8D8D8', '--ph-border': '#6E6E6E', '--ph-text': '#111111',
            '--shapes-color': '#111111',
            '--lk-rand-track': '#949494', '--lk-rand-value': '#3A6E94', '--lk-rand-dot': '#5088B0',
            '--lk-env-track': '#80A090', '--lk-env-value': '#2E7A6A', '--lk-env-dot': '#48988A',
            '--lk-smp-track': '#907898', '--lk-smp-value': '#7A48A0', '--lk-smp-dot': '#9868B8',
            '--lk-morph-track': '#7898B8', '--lk-morph-value': '#3090E0', '--lk-morph-dot': '#58A8F0',
            '--lk-shapes-track': '#887898', '--lk-shapes-value': '#7A48A0', '--lk-shapes-dot': '#9868B0',
            '--si-rand-bg': 'rgba(58,110,148,0.28)', '--si-env-bg': 'rgba(46,122,106,0.28)', '--si-smp-bg': 'rgba(122,72,160,0.28)', '--si-morph-bg': 'rgba(48,144,224,0.28)', '--si-shapes-bg': 'rgba(122,72,160,0.28)',
            '--fire-text': '#FFFFFF', '--fire-active-bg': '#2A5A78',
            '--arc-color': '#3A6E94', '--arc-opacity': '0.50',
            '--slider-track': '#999999', '--slider-thumb': '#FFFFFF',
            '--bar-track': '#C0C0C0', '--bar-fill': '#4A7FA5',
            '--card-btn-bg': '#D0D0D0', '--card-btn-border': '#787878', '--card-btn-text': '#444444', '--card-btn-hover': '#DEDEDE',
            '--snap-ring-color': '#3090E0', '--snap-ring-opacity': '0.5',
            '--lane-color': '#3A8A7A', '--lane-grid': 'rgba(17,17,17,0.10)', '--lane-grid-label': 'rgba(17,17,17,0.18)',
            '--lane-playhead': 'rgba(17,17,17,0.55)', '--lane-active': '#1E8E1E',
            '--range-arc': '#3A6E94', '--scrollbar-thumb': '#888888', '--scrollbar-track': '#C0C0C0',
            '--bus-mute-bg': '#BB2222', '--bus-mute-text': '#fff',
            '--bus-solo-bg': '#CC9900', '--bus-solo-text': '#fff',
            '--bus-group-tint': '4%', '--bus-header-tint': '8%',
            '--toast-success-bg': 'linear-gradient(135deg,#D8F0D8,#C8E8C8)', '--toast-success-border': '#1E8E1E',
            '--toast-error-bg': 'linear-gradient(135deg,#F8E0E0,#F0D0D0)', '--toast-error-border': '#BB2222',
            '--toast-info-bg': 'linear-gradient(135deg,#D8E0F0,#C8D8E8)', '--toast-info-border': '#3A6E94',
            '--toast-text': '#111111',
            '--preset-flash-color': '#1E8E1E', '--preset-flash-glow': 'rgba(30,142,30,0.4)'
        },
        bcolors: ['#4A7FA5', '#3A8A7A', '#8856A8', '#BB2222', '#2E7A4A', '#6A6AAA', '#A06030', '#2850B0'],
        busColors: ['#888', '#4A7FA5', '#BB2222', '#3A8A7A', '#8856A8', '#CC9900', '#2850B0'],
        swatches: ['#B0B0B0', '#F0F0F0', '#111111', '#4A7FA5', '#3A8A7A']
    },
    light: {
        name: 'Light',
        vars: {
            '--bg-app': '#F0F0F0', '--bg-panel': '#FAFAFA', '--bg-cell': '#FFFFFF',
            '--bg-cell-hover': '#F5F5F5', '--bg-inset': '#E8E8E8',
            '--border': '#DEDEDE', '--border-strong': '#C0C0C0', '--border-focus': '#999999',
            '--text-primary': '#333333', '--text-secondary': '#777777', '--text-muted': '#AAAAAA',
            '--input-text': '#333333',
            '--accent': '#FF5500', '--accent-hover': '#E64D00',
            '--accent-light': '#FFF0E6', '--accent-border': '#FFB380',
            '--locked-bg': '#FFF0F0', '--locked-border': '#FFCCCC',
            '--locked-icon': '#CC3333',
            '--auto-lock-bg': '#FFF5E6', '--auto-lock-border': '#FFD699',
            '--midi-dot': '#33CC33', '--rand-color': '#FF5500',
            '--env-color': '#22AAFF', '--sample-color': '#AA44FF',
            '--morph-color': '#7C4DFF',
            '--thumb-color': '#FFFFFF',
            '--knob-track': '#D0D0D0', '--knob-value': '#FF5500', '--knob-dot': '#FF8844',
            '--pf-bg': '#F2F2F2', '--pf-border': '#D0D0D0', '--pf-text': '#888888',
            '--ph-bg': '#F8F8F8', '--ph-border': '#DEDEDE', '--ph-text': '#333333',
            '--shapes-color': '#AA44FF',
            '--lk-rand-track': '#E0D0C0', '--lk-rand-value': '#FF5500', '--lk-rand-dot': '#FF8844',
            '--lk-env-track': '#B8D8E8', '--lk-env-value': '#22AAFF', '--lk-env-dot': '#55BBFF',
            '--lk-smp-track': '#D8C0E0', '--lk-smp-value': '#AA44FF', '--lk-smp-dot': '#CC77FF',
            '--lk-morph-track': '#C8B0E0', '--lk-morph-value': '#7C4DFF', '--lk-morph-dot': '#A070FF',
            '--lk-shapes-track': '#D0C0E0', '--lk-shapes-value': '#AA44FF', '--lk-shapes-dot': '#CC77FF',
            '--si-rand-bg': 'rgba(255,85,0,0.18)', '--si-env-bg': 'rgba(34,170,255,0.18)', '--si-smp-bg': 'rgba(170,68,255,0.18)', '--si-morph-bg': 'rgba(124,77,255,0.18)', '--si-shapes-bg': 'rgba(170,68,255,0.18)',
            '--fire-text': '#FFFFFF', '--fire-active-bg': '#CC4400',
            '--arc-color': '#FF5500', '--arc-opacity': '0.40',
            '--slider-track': '#B0B0B0', '--slider-thumb': '#FFFFFF',
            '--bar-track': '#E0E0E0', '--bar-fill': '#E06020',
            '--card-btn-bg': '#F2F2F2', '--card-btn-border': '#D0D0D0', '--card-btn-text': '#888888', '--card-btn-hover': '#E8E8E8',
            '--snap-ring-color': '#7C4DFF', '--snap-ring-opacity': '0.5',
            '--lane-color': '#FF5500', '--lane-grid': 'rgba(51,51,51,0.08)', '--lane-grid-label': 'rgba(51,51,51,0.15)',
            '--lane-playhead': 'rgba(51,51,51,0.50)', '--lane-active': '#33CC33',
            '--range-arc': '#FF5500', '--scrollbar-thumb': '#C0C0C0', '--scrollbar-track': '#E8E8E8',
            '--bus-mute-bg': '#DD3333', '--bus-mute-text': '#fff',
            '--bus-solo-bg': '#CC9900', '--bus-solo-text': '#fff',
            '--bus-group-tint': '3%', '--bus-header-tint': '6%',
            '--toast-success-bg': 'linear-gradient(135deg,#E8F8E8,#D8F0D8)', '--toast-success-border': '#33CC33',
            '--toast-error-bg': 'linear-gradient(135deg,#FFF0F0,#FFE0E0)', '--toast-error-border': '#DD3333',
            '--toast-info-bg': 'linear-gradient(135deg,#E8F0FF,#D8E8FF)', '--toast-info-border': '#FF5500',
            '--toast-text': '#333333',
            '--preset-flash-color': '#33CC33', '--preset-flash-glow': 'rgba(51,204,51,0.4)'
        },
        bcolors: ['#FF5500', '#22AAFF', '#33CC33', '#CC33CC', '#CC8800', '#FF3366', '#3399CC', '#88AA22'],
        busColors: ['#999', '#FF5500', '#22AAFF', '#33CC33', '#CC33CC', '#CC8800', '#3399CC'],
        swatches: ['#F0F0F0', '#FFFFFF', '#333333', '#FF5500', '#22AAFF']
    },
    grey: {
        name: 'Grey',
        vars: {
            // Backgrounds — clear separation between each layer
            '--bg-app': '#C8C8C8',  // cool mid grey — the outer shell
            '--bg-panel': '#E8E8E8',  // light panel surface
            '--bg-cell': '#F4F4F4',  // input fields, cells
            '--bg-cell-hover': '#EEEEEE',
            '--bg-inset': '#DEDEDE',  // inset boxes, slightly recessed

            // Borders — strong enough to actually define structure
            '--border': '#AAAAAA',  // default — clearly visible
            '--border-strong': '#787878',  // separators, emphasized edges
            '--border-focus': '#1A1A1A',  // focus ring — near black

            // Text — maximum contrast on light surfaces
            '--text-primary': '#0A0A0A',  // near black — crisp
            '--text-secondary': '#3A3A3A',  // dark grey — readable
            '--text-muted': '#787878',  // mid grey — secondary labels
            '--input-text': '#0A0A0A',

            // Accent — steel blue, the only color allowed
            // Desaturated enough to feel expensive, saturated enough to be clear
            '--accent': '#1F5FA6',
            '--accent-hover': '#174E8C',
            '--accent-light': 'rgba(31,95,166,0.10)',
            '--accent-border': 'rgba(31,95,166,0.35)',

            // States
            '--locked-bg': 'rgba(160,20,20,0.10)',
            '--locked-border': 'rgba(160,20,20,0.30)',
            '--locked-icon': '#991212',

            '--auto-lock-bg': 'rgba(140,100,0,0.10)',
            '--auto-lock-border': 'rgba(140,100,0,0.28)',

            // Interface indicators — steel blue family only
            '--midi-dot': '#1F5FA6',
            '--rand-color': '#1F5FA6',

            // Mode colors — all desaturated, no purple, no pink
            // Each is a distinct but muted hue from the steel/slate family
            '--env-color': '#1A6E5A',  // deep teal-green — clinical, precise
            '--sample-color': '#C05000',  // burnt sienna — warm but not loud
            '--morph-color': '#1F5FA6',  // same steel blue as accent — consistent
            '--shapes-color': '#0A0A0A',  // near black

            '--thumb-color': '#F4F4F4',

            // Knobs — dark track for contrast on light bg
            '--knob-track': '#AAAAAA',
            '--knob-value': '#1F5FA6',
            '--knob-dot': '#3A7CC4',

            // Plugin frame
            '--pf-bg': '#DEDEDE',
            '--pf-border': '#AAAAAA',
            '--pf-text': '#646464',

            '--ph-bg': '#E8E8E8',
            '--ph-border': '#AAAAAA',
            '--ph-text': '#0A0A0A',

            // Per-mode knob colors — no purple, no pink
            '--lk-rand-track': '#AAAAAA', '--lk-rand-value': '#1F5FA6', '--lk-rand-dot': '#3A7CC4',
            '--lk-env-track': '#8AB0A8', '--lk-env-value': '#1A6E5A', '--lk-env-dot': '#2A8870',
            '--lk-smp-track': '#C09878', '--lk-smp-value': '#C05000', '--lk-smp-dot': '#D86A20',
            '--lk-morph-track': '#8AAAC8', '--lk-morph-value': '#1F5FA6', '--lk-morph-dot': '#3A7CC4',
            '--lk-shapes-track': '#AAAAAA', '--lk-shapes-value': '#1F5FA6', '--lk-shapes-dot': '#3A7CC4',

            // Mode selection indicator backgrounds
            '--si-rand-bg': 'rgba(31,95,166,0.14)',
            '--si-env-bg': 'rgba(26,110,90,0.14)',
            '--si-smp-bg': 'rgba(192,80,0,0.12)',
            '--si-morph-bg': 'rgba(31,95,166,0.14)',
            '--si-shapes-bg': 'rgba(10,10,10,0.10)',

            // Fire button
            '--fire-text': '#F4F4F4',
            '--fire-active-bg': '#1A4F8A',

            // Arc / range indicator
            '--arc-color': '#1F5FA6',
            '--arc-opacity': '0.55',

            // Slider
            '--slider-track': '#909090',
            '--slider-thumb': '#F0F0F0',
            '--bar-track': '#C8C8C8',
            '--bar-fill': '#2A5A8A',

            // Card buttons
            '--card-btn-bg': '#E8E8E8',
            '--card-btn-border': '#AAAAAA',
            '--card-btn-text': '#3A3A3A',
            '--card-btn-hover': '#F0F0F0',

            // Snap ring
            '--snap-ring-color': '#1F5FA6',
            '--snap-ring-opacity': '0.45',

            // Lane block
            '--lane-color': '#1A6E5A',
            '--lane-grid': 'rgba(10,10,10,0.08)',
            '--lane-grid-label': 'rgba(10,10,10,0.20)',
            '--lane-playhead': 'rgba(10,10,10,0.60)',
            '--lane-active': '#1F5FA6',

            // Range arc
            '--range-arc': '#1F5FA6',

            // Scrollbar
            '--scrollbar-thumb': '#AAAAAA',
            '--scrollbar-track': '#D8D8D8',
            // Bus
            '--bus-mute-bg': '#AA1818', '--bus-mute-text': '#fff',
            '--bus-solo-bg': '#B08800', '--bus-solo-text': '#fff',
            '--bus-group-tint': '4%', '--bus-header-tint': '7%',
            '--toast-success-bg': 'linear-gradient(135deg,#E0F0E0,#D0E8D0)', '--toast-success-border': '#1F5FA6',
            '--toast-error-bg': 'linear-gradient(135deg,#F4E0E0,#E8D0D0)', '--toast-error-border': '#991212',
            '--toast-info-bg': 'linear-gradient(135deg,#E0E8F4,#D4DCE8)', '--toast-info-border': '#1F5FA6',
            '--toast-text': '#0A0A0A',
            '--preset-flash-color': '#1F5FA6', '--preset-flash-glow': 'rgba(31,95,166,0.4)'
        },
        bcolors: [
            '#1F5FA6',  // steel blue — primary
            '#1A6E5A',  // deep teal
            '#C05000',  // burnt sienna
            '#2A2A2A',  // near black
            '#4A8AB0',  // sky steel
            '#5A7A40',  // olive
            '#8A6030',  // bronze
            '#0A4A7A',  // deep navy
        ],
        busColors: ['#787878', '#1F5FA6', '#C05000', '#1A6E5A', '#4A8AB0', '#B08800', '#8A6030'],
        swatches: ['#C8C8C8', '#E8E8E8', '#0A0A0A', '#1F5FA6', '#1A6E5A']
    },
    medical_vintage: {
        name: 'Medical Vintage',
        vars: {
            // Aged instrument housing — wider tonal range for contrast
            '--bg-app': '#1E1E1C', '--bg-panel': '#2C2C2A', '--bg-cell': '#383835',
            '--bg-cell-hover': '#424240', '--bg-inset': '#181816',
            '--border': '#505050', '--border-strong': '#787870', '--border-focus': '#C8B890',

            // ↑ Text contrast boosted significantly
            '--text-primary': '#F0E8D0',       // brighter ivory — readable on all dark panels
            '--text-secondary': '#C0B090',     // was #A89E88, now much more legible
            '--text-muted': '#8A8070',         // was #686458 — dark panels need this lighter
            '--input-text': '#F0E8D0',

            // Accent: phosphor chartreuse — unchanged, already punchy
            '--accent': '#B8C840', '--accent-hover': '#A0B030',
            '--accent-light': 'rgba(184,200,64,0.14)', '--accent-border': '#8A9A30',

            // Locked: faded warning red
            '--locked-bg': '#38201E', '--locked-border': '#783030',
            '--locked-icon': '#DD6644',

            // Auto-lock: dim amber caution lamp
            '--auto-lock-bg': '#38280E', '--auto-lock-border': '#785020',

            // Signal colors — kept, they read well
            '--midi-dot': '#88CC44',
            '--rand-color': '#B8C840',
            '--env-color': '#D4943A',
            '--sample-color': '#7ABCCC',
            '--morph-color': '#C8785A',

            '--thumb-color': '#D8D0B8',
            '--knob-track': '#202020', '--knob-value': '#B8C840', '--knob-dot': '#D4E050',

            // Plugin card: darker header + footer, light text over them
            '--pf-bg': '#141412',              // card footer — noticeably darker than panel
            '--pf-border': '#505050',
            '--pf-text': '#B0A888',            // was #686458 — now readable on dark bg
            '--ph-bg': '#141412', '--ph-border': '#505050', '--ph-text': '#F0E8D0',

            '--shapes-color': '#C8785A',

            // Linked knob tracks
            '--lk-rand-track': '#383A24', '--lk-rand-value': '#B8C840', '--lk-rand-dot': '#D4E050',
            '--lk-env-track': '#382E18', '--lk-env-value': '#D4943A', '--lk-env-dot': '#EAB060',
            '--lk-smp-track': '#1E2E38', '--lk-smp-value': '#7ABCCC', '--lk-smp-dot': '#A0D4E0',
            '--lk-morph-track': '#362420', '--lk-morph-value': '#C8785A', '--lk-morph-dot': '#E09878',
            '--lk-shapes-track': '#362420', '--lk-shapes-value': '#C8785A', '--lk-shapes-dot': '#E09878',

            // Source indicators
            '--si-rand-bg': 'rgba(184,200,64,0.14)',
            '--si-env-bg': 'rgba(212,148,58,0.14)',
            '--si-smp-bg': 'rgba(122,188,204,0.14)',
            '--si-morph-bg': 'rgba(200,120,90,0.14)',
            '--si-shapes-bg': 'rgba(200,120,90,0.14)',

            // Fire/active states — dark text on chartreuse pill
            '--fire-text': '#1A1A18', '--fire-active-bg': '#A0B030',
            '--arc-color': '#B8C840', '--arc-opacity': '0.45',
            '--slider-track': '#444438', '--slider-thumb': '#E0D8C0',
            '--bar-track': '#1A1A18', '--bar-fill': '#A0B830',
            '--card-btn-bg': '#141412', '--card-btn-border': '#505050', '--card-btn-text': '#B0A888', '--card-btn-hover': '#242420',
            '--snap-ring-color': '#C8785A', '--snap-ring-opacity': '0.6',
            '--lane-color': '#7ABCCC', '--lane-grid': 'rgba(240,232,208,0.07)', '--lane-grid-label': 'rgba(240,232,208,0.14)',
            '--lane-playhead': 'rgba(240,232,208,0.6)', '--lane-active': '#88CC44',
            '--range-arc': '#B8C840', '--scrollbar-thumb': '#505050', '--scrollbar-track': 'transparent',
            '--bus-mute-bg': '#AA3322', '--bus-mute-text': '#F0E8D0',
            '--bus-solo-bg': '#B8A020', '--bus-solo-text': '#1A1A18',
            '--bus-group-tint': '7%', '--bus-header-tint': '12%',
            '--toast-success-bg': 'linear-gradient(135deg,#1A2810,#0E1808)', '--toast-success-border': '#88CC44',
            '--toast-error-bg': 'linear-gradient(135deg,#3A1810,#2A0808)', '--toast-error-border': '#DD6644',
            '--toast-info-bg': 'linear-gradient(135deg,#1C1A0C,#100E06)', '--toast-info-border': '#B8C840',
            '--toast-text': '#F0E8D0',
            '--preset-flash-color': '#88CC44', '--preset-flash-glow': 'rgba(136,204,68,0.45)'
        },
        bcolors: ['#B8C840', '#D4943A', '#7ABCCC', '#CC6644', '#C8785A', '#88CC44', '#C0B090', '#D8D0B8'],
        busColors: ['#686858', '#B8C840', '#D4943A', '#7ABCCC', '#CC6644', '#88CC44', '#C8785A'],
        swatches: ['#1E1E1C', '#383835', '#F0E8D0', '#B8C840', '#D4943A']
    },
    slate_studio: {
        name: 'Slate Studio',
        vars: {
            '--bg-app': '#111116',  // L0 — almost black, recedes
            '--bg-panel': '#1A1A1E',  // L1 — panel surfaces
            '--bg-cell': '#222228',  // L2 — content / canvas bg
            '--bg-cell-hover': '#2A2A32',  // L3 — hovered rows
            '--bg-inset': '#0E0E12',  // L4 — sunken wells

            '--border': '#7A7A90',  // 4.14:1 on panel ✅ non-text chrome
            '--border-strong': '#909098',  // 5.6:1 — section edges
            '--border-focus': '#D4A840',  // gold focus ring

            '--text-primary': '#F0EEF8',  // 15.1:1 ✅
            '--text-secondary': '#9090A8',  // 5.57:1 ✅
            '--text-muted': '#888898',  // 4.98:1 panel, 4.54:1 cell ✅ ✅
            '--input-text': '#F0EEF8',

            // Gold accent — transport, primary action, focused controls
            '--accent': '#D4A840',  // 7.83:1 ✅
            '--accent-hover': '#F0C050',
            '--accent-light': 'rgba(212,168,64,0.10)',
            '--accent-border': 'rgba(212,168,64,0.35)',

            '--midi-dot': '#44DD66',  // green = running

            '--locked-bg': 'rgba(220,60,60,0.12)',
            '--locked-border': 'rgba(220,60,60,0.35)',
            '--locked-icon': '#EE5050',

            '--auto-lock-bg': 'rgba(220,160,40,0.12)',
            '--auto-lock-border': 'rgba(220,160,40,0.35)',

            // Mode colors — all 4.5:1+ on bg-panel, all distinct hue families
            '--rand-color': '#D4A840',  //  7.83 gold      — randomize = chance
            '--env-color': '#E85A30',  //  4.90 vermillion — envelope = heat/attack
            '--sample-color': '#3AAAE0',  //  6.61 sky blue   — sample = digital
            '--morph-color': '#50D890',  //  9.56 mint       — morph = organic
            '--shapes-color': '#D050C8',  //  4.68 magenta    — shapes = geometric pop

            '--thumb-color': '#B0B0C8',

            '--knob-track': '#1E1E24',
            '--knob-value': '#D4A840',
            '--knob-dot': '#F0CC70',

            '--pf-bg': '#111116',
            '--pf-border': '#7A7A90',
            '--pf-text': '#9090A8',

            '--ph-bg': '#111116',
            '--ph-border': '#7A7A90',
            '--ph-text': '#F0EEF8',

            '--lk-rand-track': '#201C08', '--lk-rand-value': '#D4A840', '--lk-rand-dot': '#F0CC70',
            '--lk-env-track': '#201008', '--lk-env-value': '#E85A30', '--lk-env-dot': '#FF8860',
            '--lk-smp-track': '#081820', '--lk-smp-value': '#3AAAE0', '--lk-smp-dot': '#70CCF8',
            '--lk-morph-track': '#0C201A', '--lk-morph-value': '#50D890', '--lk-morph-dot': '#88F8B8',
            '--lk-shapes-track': '#1E0820', '--lk-shapes-value': '#D050C8', '--lk-shapes-dot': '#F080E8',

            '--si-rand-bg': 'rgba(212,168,64,0.12)',
            '--si-env-bg': 'rgba(232,90,48,0.12)',
            '--si-smp-bg': 'rgba(58,170,224,0.12)',
            '--si-morph-bg': 'rgba(80,216,144,0.12)',
            '--si-shapes-bg': 'rgba(208,80,200,0.12)',

            '--fire-text': '#111110',
            '--fire-active-bg': '#D4A840',

            '--arc-color': '#D4A840',
            '--arc-opacity': '0.50',

            '--slider-track': '#3A3A48',
            '--slider-thumb': '#C8C8E0',
            '--bar-track': '#141418',
            '--bar-fill': '#B89030',

            '--card-btn-bg': '#111116',
            '--card-btn-border': '#7A7A90',
            '--card-btn-text': '#9090A8',
            '--card-btn-hover': '#1A1A22',

            '--snap-ring-color': '#D4A840',
            '--snap-ring-opacity': '0.55',

            '--lane-color': '#3AAAE0',
            '--lane-grid': 'rgba(240,238,248,0.05)',
            '--lane-grid-label': 'rgba(240,238,248,0.16)',
            '--lane-playhead': 'rgba(255,255,255,0.82)',
            '--lane-active': '#44DD66',

            '--range-arc': '#D4A840',
            '--scrollbar-thumb': '#7A7A90',
            '--scrollbar-track': 'transparent',

            '--bus-mute-bg': '#CC2222', '--bus-mute-text': '#FFFFFF',
            '--bus-solo-bg': '#C8A000', '--bus-solo-text': '#000000',
            '--bus-group-tint': '8%', '--bus-header-tint': '16%',
            '--toast-success-bg': 'linear-gradient(135deg,#0C1C10,#061008)', '--toast-success-border': '#44DD66',
            '--toast-error-bg': 'linear-gradient(135deg,#2A0808,#1A0404)', '--toast-error-border': '#EE5050',
            '--toast-info-bg': 'linear-gradient(135deg,#181410,#0E0A04)', '--toast-info-border': '#D4A840',
            '--toast-text': '#F0EEF8',
            '--preset-flash-color': '#44DD66', '--preset-flash-glow': 'rgba(68,221,102,0.45)',
        },
        bcolors: ['#D4A840', '#E85A30', '#3AAAE0', '#50D890', '#D050C8', '#44DD66', '#9090A8', '#E0E0F0'],
        busColors: ['#2A2A38', '#D4A840', '#CC2222', '#3AAAE0', '#E85A30', '#50D890', '#D050C8'],
        swatches: ['#111116', '#222228', '#F0EEF8', '#D4A840', '#E85A30'],
    },


    // ─────────────────────────────────────────────────────────────────
    // 2. VINTAGE CONSOLE
    //    Concept: 1970s broadcast console — Neve 8078, SSL 4000.
    //    Warm ivory on dark walnut. Amber VU needle as accent.
    //    Every surface has a slight warm cast — this is tape and iron.
    // ─────────────────────────────────────────────────────────────────
    vintage_console: {
        name: 'Vintage Console',
        vars: {
            '--bg-app': '#120E08',  // L0 — dark walnut void
            '--bg-panel': '#1C1810',  // L1 — panel surface, warm dark
            '--bg-cell': '#252018',  // L2 — content areas
            '--bg-cell-hover': '#2E2820',  // L3
            '--bg-inset': '#0E0A06',  // L4 — deep inset

            '--border': '#787060',  // 3.61:1 on panel ✅ non-text chrome
            '--border-strong': '#908070',  // 5.1:1 ✅
            '--border-focus': '#C8781E',  // amber focus ring

            '--text-primary': '#F0E8C8',  // 14.38:1 ✅
            '--text-secondary': '#B8A878',  //  7.50:1 ✅
            '--text-muted': '#9A8A60',  //  5.20:1 ✅
            '--input-text': '#F0E8C8',

            // Amber-orange — VU needle, peak indicator, primary action
            '--accent': '#C8781E',  // 5.19:1 ✅
            '--accent-hover': '#E89030',
            '--accent-light': 'rgba(200,120,30,0.12)',
            '--accent-border': 'rgba(200,120,30,0.38)',

            '--midi-dot': '#88CC44',  // phosphor green = signal present

            '--locked-bg': 'rgba(200,40,40,0.12)',
            '--locked-border': 'rgba(200,40,40,0.35)',
            '--locked-icon': '#EE5544',

            '--auto-lock-bg': 'rgba(200,160,40,0.10)',
            '--auto-lock-border': 'rgba(200,160,40,0.30)',

            // Mode colors — warm analog palette, no digital-looking hues
            '--rand-color': '#C8781E',  //  5.19 amber     — randomize = chance
            '--env-color': '#D4A030',  //  7.42 warm gold — envelope = time/attack
            '--sample-color': '#78BCCC',  //  8.31 slate blue — sample = tape head
            '--morph-color': '#A0C840',  //  9.12 phosphor  — morph = oscilloscope
            '--shapes-color': '#D46050',  //  4.71 terracotta — shapes = warm red

            '--thumb-color': '#C8B888',

            '--knob-track': '#201808',
            '--knob-value': '#C8781E',
            '--knob-dot': '#F0A050',

            '--pf-bg': '#100C06',
            '--pf-border': '#787060',
            '--pf-text': '#9A8A60',

            '--ph-bg': '#100C06',
            '--ph-border': '#787060',
            '--ph-text': '#F0E8C8',

            '--lk-rand-track': '#201408', '--lk-rand-value': '#C8781E', '--lk-rand-dot': '#F0A050',
            '--lk-env-track': '#201808', '--lk-env-value': '#D4A030', '--lk-env-dot': '#F0C860',
            '--lk-smp-track': '#0C1820', '--lk-smp-value': '#78BCCC', '--lk-smp-dot': '#A8D8E8',
            '--lk-morph-track': '#141C06', '--lk-morph-value': '#A0C840', '--lk-morph-dot': '#C8EE60',
            '--lk-shapes-track': '#1C100A', '--lk-shapes-value': '#D46050', '--lk-shapes-dot': '#F09078',

            '--si-rand-bg': 'rgba(200,120,30,0.12)',
            '--si-env-bg': 'rgba(212,160,48,0.12)',
            '--si-smp-bg': 'rgba(120,188,204,0.12)',
            '--si-morph-bg': 'rgba(160,200,64,0.12)',
            '--si-shapes-bg': 'rgba(212,96,80,0.12)',

            '--fire-text': '#100C06',
            '--fire-active-bg': '#C8781E',

            '--arc-color': '#C8781E',
            '--arc-opacity': '0.50',

            '--slider-track': '#4A3820',
            '--slider-thumb': '#D8C898',
            '--bar-track': '#181008',
            '--bar-fill': '#B06818',

            '--card-btn-bg': '#100C06',
            '--card-btn-border': '#787060',
            '--card-btn-text': '#9A8A60',
            '--card-btn-hover': '#1C1810',

            '--snap-ring-color': '#C8781E',
            '--snap-ring-opacity': '0.55',

            '--lane-color': '#78BCCC',
            '--lane-grid': 'rgba(240,232,200,0.06)',
            '--lane-grid-label': 'rgba(240,232,200,0.18)',
            '--lane-playhead': 'rgba(255,248,220,0.82)',
            '--lane-active': '#88CC44',

            '--range-arc': '#C8781E',
            '--scrollbar-thumb': '#787060',
            '--scrollbar-track': 'transparent',

            '--bus-mute-bg': '#BB2222', '--bus-mute-text': '#FFFFFF',
            '--bus-solo-bg': '#B89000', '--bus-solo-text': '#000000',
            '--bus-group-tint': '8%', '--bus-header-tint': '16%',
            '--toast-success-bg': 'linear-gradient(135deg,#0E1C08,#060E04)', '--toast-success-border': '#88CC44',
            '--toast-error-bg': 'linear-gradient(135deg,#3A1008,#2A0804)', '--toast-error-border': '#EE5544',
            '--toast-info-bg': 'linear-gradient(135deg,#1A1408,#0E0A04)', '--toast-info-border': '#C8781E',
            '--toast-text': '#F0E8C8',
            '--preset-flash-color': '#88CC44', '--preset-flash-glow': 'rgba(136,204,68,0.45)',
        },
        bcolors: ['#C8781E', '#D4A030', '#78BCCC', '#A0C840', '#D46050', '#88CC44', '#B8A878', '#F0E8C8'],
        busColors: ['#383020', '#C8781E', '#BB2222', '#78BCCC', '#D4A030', '#A0C840', '#D46050'],
        swatches: ['#120E08', '#252018', '#F0E8C8', '#C8781E', '#D4A030'],
    },


    // ─────────────────────────────────────────────────────────────────
    // 3. WIN98
    //    Concept: Windows 98 system palette, beveled chrome,
    //    title bar navy, silver dialogs, CGA mode colors.
    //    DAW hierarchy mapped to OS chrome conventions —
    //    plugin list = Explorer sidebar, logic blocks = main pane.
    // ─────────────────────────────────────────────────────────────────
    win98: {
        name: 'Win98',
        vars: {
            // Light theme — layer model inverted (lighter = more chrome)
            '--bg-app': '#008080',  // L0 — the teal desktop
            '--bg-panel': '#C0C0C0',  // L1 — silver dialog surface
            '--bg-cell': '#FFFFFF',  // L2 — white input fields / canvas
            '--bg-cell-hover': '#F0F0F0',  // L3
            '--bg-inset': '#808080',  // L4 — sunken/inset (dark bevel face)

            '--border': '#606060',  // 3.46:1 on silver ✅ non-text chrome
            '--border-strong': '#000000',  // 21:1 — outer bevel edge
            '--border-focus': '#000080',  // navy focus

            '--text-primary': '#000000',  // 21:1 ✅
            '--text-secondary': '#222222',  //  8.74:1 ✅ on silver
            '--text-muted': '#444444',  //  5.35:1 ✅
            '--input-text': '#000000',

            // Navy — active title bar, primary interactive
            '--accent': '#000080',  // 8.80:1 on silver ✅
            '--accent-hover': '#0000AA',
            '--accent-light': 'rgba(0,0,128,0.10)',
            '--accent-border': 'rgba(0,0,128,0.40)',

            '--midi-dot': '#008000',  // system green = signal on

            '--locked-bg': 'rgba(204,0,0,0.10)',
            '--locked-border': 'rgba(204,0,0,0.35)',
            '--locked-icon': '#CC0000',

            '--auto-lock-bg': 'rgba(128,128,0,0.10)',
            '--auto-lock-border': 'rgba(128,128,0,0.35)',

            // Mode colors — strict Windows system palette
            // All verified on both silver #C0C0C0 AND white #FFFFFF
            '--rand-color': '#000080',  //  8.80 navy    — randomize
            '--env-color': '#8B0000',  // 10.01 darkred  — envelope
            '--sample-color': '#004C4C',  //  5.40 darkteal — sample
            '--morph-color': '#3D5216',  //  8.69 darkolive — morph
            '--shapes-color': '#4B0082',  // 12.95 indigo   — shapes

            '--thumb-color': '#C0C0C0',

            '--knob-track': '#808080',
            '--knob-value': '#000080',
            '--knob-dot': '#FFFFFF',

            // Plugin card header — navy title bar = classic Win98
            '--pf-bg': '#C0C0C0',
            '--pf-border': '#000000',
            '--pf-text': '#000000',

            '--ph-bg': '#000080',   // active title bar
            '--ph-border': '#000000',
            '--ph-text': '#FFFFFF',   // 16.01:1 ✅

            '--lk-rand-track': '#D0D0E8', '--lk-rand-value': '#000080', '--lk-rand-dot': '#0000CC',
            '--lk-env-track': '#E8D0D0', '--lk-env-value': '#8B0000', '--lk-env-dot': '#CC0000',
            '--lk-smp-track': '#C8E0E0', '--lk-smp-value': '#004C4C', '--lk-smp-dot': '#006868',
            '--lk-morph-track': '#D8E0C8', '--lk-morph-value': '#3D5216', '--lk-morph-dot': '#556B2F',
            '--lk-shapes-track': '#DCD0E8', '--lk-shapes-value': '#4B0082', '--lk-shapes-dot': '#6A0DAD',

            '--si-rand-bg': 'rgba(0,0,128,0.10)',
            '--si-env-bg': 'rgba(139,0,0,0.10)',
            '--si-smp-bg': 'rgba(0,76,76,0.10)',
            '--si-morph-bg': 'rgba(61,82,22,0.10)',
            '--si-shapes-bg': 'rgba(75,0,130,0.10)',

            '--fire-text': '#FFFFFF',
            '--fire-active-bg': '#000080',

            '--arc-color': '#000080',
            '--arc-opacity': '0.55',

            '--slider-track': '#A0A0A0',
            '--slider-thumb': '#D0D0D0',
            '--bar-track': '#A0A0A0',
            '--bar-fill': '#000080',

            '--card-btn-bg': '#C0C0C0',
            '--card-btn-border': '#000000',
            '--card-btn-text': '#000000',
            '--card-btn-hover': '#D4D0C8',

            '--snap-ring-color': '#000080',
            '--snap-ring-opacity': '0.55',

            '--lane-color': '#000080',
            '--lane-grid': 'rgba(0,0,0,0.07)',
            '--lane-grid-label': 'rgba(0,0,0,0.22)',
            '--lane-playhead': 'rgba(0,0,0,0.70)',  // dark playhead on white canvas
            '--lane-active': '#008000',

            '--range-arc': '#000080',
            '--scrollbar-thumb': '#808080',
            '--scrollbar-track': '#C0C0C0',

            '--bus-mute-bg': '#CC0000', '--bus-mute-text': '#FFFFFF',
            '--bus-solo-bg': '#808000', '--bus-solo-text': '#FFFFFF',
            '--bus-group-tint': '8%', '--bus-header-tint': '14%',
            '--toast-success-bg': 'linear-gradient(135deg,#E0F0E0,#D0E8D0)', '--toast-success-border': '#008000',
            '--toast-error-bg': 'linear-gradient(135deg,#FFE0E0,#FFD0D0)', '--toast-error-border': '#CC0000',
            '--toast-info-bg': 'linear-gradient(135deg,#D8D8F4,#C8C8E8)', '--toast-info-border': '#000080',
            '--toast-text': '#000000',
            '--preset-flash-color': '#008000', '--preset-flash-glow': 'rgba(0,128,0,0.4)',
        },
        bcolors: ['#000080', '#8B0000', '#005F5F', '#3D5216', '#4B0082', '#008000', '#808080', '#000000'],
        busColors: ['#808080', '#000080', '#CC0000', '#005F5F', '#8B0000', '#3D5216', '#4B0082'],
        swatches: ['#008080', '#C0C0C0', '#000000', '#000080', '#8B0000'],
    },


    // ─────────────────────────────────────────────────────────────────
    // 5. WARM TAPE
    //    Concept: analog tape / Neve/SSL outboard / mastering suite.
    //    Dark mahogany panels, warm ivory text, VU yellow accent.
    //    Every color is found in real analog hardware — no digital hues.
    //    Think: Studer A800, SSL G-Bus, Pultec EQP-1A.
    // ─────────────────────────────────────────────────────────────────
    warm_tape: {
        name: 'Warm Tape',
        vars: {
            '--bg-app': '#160E06',  // L0 — dark mahogany
            '--bg-panel': '#211B12',  // L1 — panel surface
            '--bg-cell': '#2C2418',  // L2 — content areas
            '--bg-cell-hover': '#363020',  // L3
            '--bg-inset': '#120A04',  // L4 — deep inset

            '--border': '#887860',  // 3.99:1 on panel ✅ non-text chrome
            '--border-strong': '#A89070',  // 5.6:1 ✅
            '--border-focus': '#E8C040',  // VU yellow focus

            '--text-primary': '#F4ECD8',  // 14.50:1 ✅
            '--text-secondary': '#C0A870',  //  7.38:1 ✅
            '--text-muted': '#B09060',  //  5.69:1 panel, 5.10:1 cell ✅
            '--input-text': '#F4ECD8',

            // VU yellow — needle at peak, primary action, transport
            '--accent': '#E8C040',  // 9.79:1 ✅
            '--accent-hover': '#FFD850',
            '--accent-light': 'rgba(232,192,64,0.10)',
            '--accent-border': 'rgba(232,192,64,0.35)',

            '--midi-dot': '#88CC44',  // phosphor green = signal

            '--locked-bg': 'rgba(196,32,32,0.12)',
            '--locked-border': 'rgba(196,32,32,0.35)',
            '--locked-icon': '#E84040',

            '--auto-lock-bg': 'rgba(200,160,40,0.10)',
            '--auto-lock-border': 'rgba(200,160,40,0.30)',

            // Mode colors — all from real analog hardware color language
            '--rand-color': '#E8C040',  //  9.79 VU yellow    — randomize = chance
            '--env-color': '#E06828',  //  5.02 hot orange   — envelope = VCA attack
            '--sample-color': '#60B8D8',  //  7.60 steel blue   — sample = tape echo
            '--morph-color': '#98D058',  //  9.35 spring green — morph = phaser sweep
            '--shapes-color': '#D86848',  //  4.92 sienna       — shapes = warm red meter

            '--thumb-color': '#C0A870',

            '--knob-track': '#1C1408',
            '--knob-value': '#E8C040',
            '--knob-dot': '#FFE880',

            '--pf-bg': '#140C04',
            '--pf-border': '#887860',
            '--pf-text': '#B09060',

            '--ph-bg': '#140C04',
            '--ph-border': '#887860',
            '--ph-text': '#F4ECD8',

            '--lk-rand-track': '#201808', '--lk-rand-value': '#E8C040', '--lk-rand-dot': '#FFE880',
            '--lk-env-track': '#1C1008', '--lk-env-value': '#E06828', '--lk-env-dot': '#FF9858',
            '--lk-smp-track': '#0C1820', '--lk-smp-value': '#60B8D8', '--lk-smp-dot': '#98D8F0',
            '--lk-morph-track': '#141C08', '--lk-morph-value': '#98D058', '--lk-morph-dot': '#C8F078',
            '--lk-shapes-track': '#1C1008', '--lk-shapes-value': '#D86848', '--lk-shapes-dot': '#F89878',

            '--si-rand-bg': 'rgba(232,192,64,0.12)',
            '--si-env-bg': 'rgba(224,104,40,0.12)',
            '--si-smp-bg': 'rgba(96,184,216,0.12)',
            '--si-morph-bg': 'rgba(152,208,88,0.12)',
            '--si-shapes-bg': 'rgba(216,104,72,0.12)',

            '--fire-text': '#120A04',
            '--fire-active-bg': '#E8C040',

            '--arc-color': '#E8C040',
            '--arc-opacity': '0.50',

            '--slider-track': '#4A3818',
            '--slider-thumb': '#D8C090',
            '--bar-track': '#140C04',
            '--bar-fill': '#D0A830',

            '--card-btn-bg': '#140C04',
            '--card-btn-border': '#887860',
            '--card-btn-text': '#B09060',
            '--card-btn-hover': '#201810',

            '--snap-ring-color': '#E8C040',
            '--snap-ring-opacity': '0.55',

            '--lane-color': '#60B8D8',
            '--lane-grid': 'rgba(244,236,216,0.06)',
            '--lane-grid-label': 'rgba(244,236,216,0.18)',
            '--lane-playhead': 'rgba(255,248,220,0.85)',
            '--lane-active': '#88CC44',

            '--range-arc': '#E8C040',
            '--scrollbar-thumb': '#887860',
            '--scrollbar-track': 'transparent',

            '--bus-mute-bg': '#C42020', '--bus-mute-text': '#FFFFFF',
            '--bus-solo-bg': '#C8A000', '--bus-solo-text': '#000000',
            '--bus-group-tint': '8%', '--bus-header-tint': '16%',
            '--toast-success-bg': 'linear-gradient(135deg,#102008,#081004)', '--toast-success-border': '#88CC44',
            '--toast-error-bg': 'linear-gradient(135deg,#380808,#200404)', '--toast-error-border': '#E84040',
            '--toast-info-bg': 'linear-gradient(135deg,#1A1808,#100C04)', '--toast-info-border': '#E8C040',
            '--toast-text': '#F4ECD8',
            '--preset-flash-color': '#88CC44', '--preset-flash-glow': 'rgba(136,204,68,0.45)',
        },
        bcolors: ['#E8C040', '#E06828', '#60B8D8', '#98D058', '#D86848', '#88CC44', '#C0A870', '#F4ECD8'],
        busColors: ['#30261A', '#E8C040', '#C42020', '#60B8D8', '#E06828', '#98D058', '#D86848'],
        swatches: ['#160E06', '#2C2418', '#F4ECD8', '#E8C040', '#E06828'],
    }
};

var currentTheme = 'earthy';

function applyTheme(themeId) {
    var t = THEMES[themeId];
    if (!t) return;
    currentTheme = themeId;
    var root = document.documentElement;
    for (var k in t.vars) { root.style.setProperty(k, t.vars[k]); }
    BCOLORS = t.bcolors;
    if (t.busColors) BUS_COLORS = t.busColors;

    // Inject dynamic slider styles — WebView2 pseudo-elements don't reliably
    // inherit CSS custom properties, so we write hardcoded color values.
    // This is now the SOLE source of slider track/thumb styling.
    var sTrack = t.vars['--slider-track'] || t.vars['--border'] || '#555';
    var sThumb = t.vars['--slider-thumb'] || t.vars['--thumb-color'] || '#ccc';
    var sAccent = t.vars['--accent'] || '#E8A244';
    var sAccentL = t.vars['--accent-light'] || 'rgba(232,162,68,0.20)';
    var dynEl = document.getElementById('dyn-slider');
    if (!dynEl) {
        dynEl = document.createElement('style');
        dynEl.id = 'dyn-slider';
        document.head.appendChild(dynEl);
    }
    dynEl.textContent =
        // Track — 4px for visibility
        'input[type="range"]::-webkit-slider-runnable-track{' +
        'height:4px;background:' + sTrack + ';border-radius:2px}' +
        // Thumb — 14px circle with shadow for visibility
        'input[type="range"]::-webkit-slider-thumb{' +
        '-webkit-appearance:none;width:14px;height:14px;' +
        'background:' + sThumb + ';' +
        'border:2px solid ' + sTrack + ';' +
        'border-radius:50%;cursor:pointer;margin-top:-5px;' +
        'box-shadow:0 1px 3px rgba(0,0,0,0.3);' +
        'transition:border-color 80ms,box-shadow 80ms}' +
        // Hover — accent border + glow
        'input[type="range"]::-webkit-slider-thumb:hover{' +
        'border-color:' + sAccent + ';' +
        'box-shadow:0 1px 3px rgba(0,0,0,0.3),0 0 0 2px ' + sAccentL + '}' +
        // Active — stronger glow
        'input[type="range"]:active::-webkit-slider-thumb{' +
        'border-color:' + sAccent + ';' +
        'box-shadow:0 1px 3px rgba(0,0,0,0.3),0 0 0 3px ' + sAccentL + '}';

    // Update rendered blocks/plugins with new colors
    if (typeof renderBlocks === 'function') renderBlocks();
    if (typeof renderAllPlugins === 'function') renderAllPlugins();
    // Render theme cards to update active state
    renderThemeGrid();
    if (typeof saveUiStateToHost === 'function') saveUiStateToHost();
}

function renderThemeGrid() {
    var grid = document.getElementById('themeGrid');
    if (!grid) return;
    var h = '';
    for (var id in THEMES) {
        var t = THEMES[id];
        h += '<div class="theme-card' + (currentTheme === id ? ' active' : '') + '" data-theme="' + id + '">';
        h += '<div class="theme-swatch">';
        for (var si = 0; si < t.swatches.length; si++) {
            h += '<span style="background:' + t.swatches[si] + '"></span>';
        }
        h += '</div>';
        h += '<span class="theme-name">' + t.name + '</span>';
        h += '</div>';
    }
    grid.innerHTML = h;
    grid.querySelectorAll('.theme-card').forEach(function (card) {
        card.onclick = function () {
            applyTheme(this.getAttribute('data-theme'));
        };
    });
}

// Settings panel toggle
(function () {
    var btn = document.getElementById('settingsBtn');
    var drop = document.getElementById('settingsDrop');
    btn.onclick = function (e) {
        e.stopPropagation();
        drop.classList.toggle('vis');
    };
    document.addEventListener('click', function (e) {
        if (!drop.contains(e.target) && e.target !== btn) {
            drop.classList.remove('vis');
        }
    });
    renderThemeGrid();
})();
