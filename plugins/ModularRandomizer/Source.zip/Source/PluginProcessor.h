#pragma once

#ifdef _WIN32
#include <windows.h>
#endif

#include <juce_audio_processors/juce_audio_processors.h>
#include <juce_audio_utils/juce_audio_utils.h>
#include <juce_gui_extra/juce_gui_extra.h>
#include <atomic>
#include <array>
#include <mutex>
#include <fstream>

// Temp debug file logger (works in Release builds too)
#define LOG_TO_FILE(msg) do { \
    static std::ofstream logFile (juce::File::getSpecialLocation (juce::File::userDesktopDirectory) \
        .getChildFile ("modrand_debug.log").getFullPathName().toStdString(), std::ios::app); \
    logFile << msg << std::endl; logFile.flush(); \
} while(0)

//==============================================================================
/**
 * Modular Randomizer - Multi-Plugin Parameter Randomizer
 *
 * Hosts multiple VST3 plugins, exposes their parameters,
 * and allows randomization via the WebView UI.
 */

struct HostedPlugin
{
    int id = 0;
    juce::String name;
    juce::String path;
    std::unique_ptr<juce::AudioPluginInstance> instance;
    juce::PluginDescription description;
    bool prepared = false;
    bool bypassed = false;
    bool crashed  = false;      // true if plugin threw/faulted during processBlock
    int crashCount = 0;         // lifetime crash counter
    int busId = 0;              // parallel bus ID (0 = default/main)
};

/** SEH-guarded processBlock wrapper.
    Isolated as a free function because __try/__except cannot coexist
    with C++ objects that have destructors in the same function scope. */
bool sehGuardedProcessBlock (juce::AudioPluginInstance* instance,
                             juce::AudioBuffer<float>& buffer,
                             juce::MidiBuffer& midi);

/** A parameter with a dynamically changeable display name.
    Used for the proxy parameter pool so the DAW shows
    meaningful names like "Vital: Cutoff" instead of "Slot 1". */
class ProxyParameter : public juce::AudioParameterFloat
{
public:
    ProxyParameter (const juce::ParameterID& paramID, const juce::String& defaultName,
                    const juce::NormalisableRange<float>& range, float defaultVal)
        : juce::AudioParameterFloat (paramID, defaultName, range, defaultVal),
          dynamicName (defaultName) {}

    juce::String getName (int maxLen) const override
    {
        const juce::SpinLock::ScopedLockType sl (nameLock);
        return dynamicName.substring (0, maxLen);
    }

    void setDynamicName (const juce::String& newName)
    {
        const juce::SpinLock::ScopedLockType sl (nameLock);
        dynamicName = newName;
    }

private:
    mutable juce::SpinLock nameLock;
    juce::String dynamicName;
};

struct ScannedPlugin
{
    juce::String name;
    juce::String vendor;
    juce::String category;
    juce::String path;
    juce::String format;
    int numParams = 0;
};

/** Audio sample data loaded for Sample Modulator blocks.
    Shared via shared_ptr so audio thread can hold a reference
    while message thread replaces it. */
struct SampleData
{
    juce::AudioBuffer<float> buffer;    // mono, at original sample rate
    double sampleRate = 44100.0;
    juce::String filePath;
    juce::String fileName;
    std::vector<float> waveformPeaks;   // downsampled peak values for UI (~200 points)
    float durationSeconds = 0.0f;
};

class ModularRandomizerAudioProcessor : public juce::AudioProcessor,
                                        public juce::AudioProcessorValueTreeState::Listener
{
public:
    //==============================================================================
    ModularRandomizerAudioProcessor();
    ~ModularRandomizerAudioProcessor() override;

    //==============================================================================
    void prepareToPlay (double sampleRate, int samplesPerBlock) override;
    void releaseResources() override;

   #ifndef JucePlugin_PreferredChannelConfigurations
    bool isBusesLayoutSupported (const BusesLayout& layouts) const override;
   #endif

    void processBlock (juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    //==============================================================================
    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override;

    //==============================================================================
    const juce::String getName() const override;
    bool acceptsMidi() const override;
    bool producesMidi() const override;
    bool isMidiEffect() const override;
    double getTailLengthSeconds() const override;

    //==============================================================================
    int getNumPrograms() override;
    int getCurrentProgram() override;
    void setCurrentProgram (int index) override;
    const juce::String getProgramName (int index) override;
    void changeProgramName (int index, const juce::String& newName) override;

    //==============================================================================
    void getStateInformation (juce::MemoryBlock& destData) override;
    void setStateInformation (const void* data, int sizeInBytes) override;

    //==============================================================================
    juce::AudioProcessorValueTreeState& getAPVTS() { return apvts; }

    //==============================================================================
    // Plugin Hosting API (called from Editor via native functions)
    //==============================================================================

    /** Scan VST3 directories and return found plugins */
    std::vector<ScannedPlugin> scanForPlugins (const juce::StringArray& paths);

    /** Load a VST3 plugin by file path, returns the hosted plugin ID or -1 */
    int loadPlugin (const juce::String& pluginPath);

    /** Remove a hosted plugin by ID */
    void removePlugin (int pluginId);

    /** Garbage-collect dead plugin entries (call from message thread only) */
    void purgeDeadPlugins();

    /** Reorder hosted plugins to match the given ID order from the UI */
    void reorderPlugins (const std::vector<int>& orderedIds);

    /** Get parameter info for a hosted plugin */
    struct ParamInfo {
        int index;
        juce::String name;
        float value;        // normalised 0-1
        juce::String label;
        juce::String displayText;  // formatted value from plugin (e.g. "440 Hz", "50%")
        bool automatable;
    };
    std::vector<ParamInfo> getHostedParams (int pluginId);

    /** Set a parameter on a hosted plugin (instant, for UI knob turns) */
    void setHostedParam (int pluginId, int paramIndex, float normValue);

    /** Start a smooth parameter glide (called from JS, processed per-buffer in processBlock) */
    void startGlide (int pluginId, int paramIndex, float targetValue, float durationMs);

    /** Update logic blocks from UI JSON (called from Editor native function) */
    void updateLogicBlocks (const juce::String& jsonData);

    /** Lightweight morph playhead update (called from drag — avoids full JSON reparse) */
    void updateMorphPlayhead (int blockId, float x, float y);

    /** Randomize specific parameters on a hosted plugin */
    void randomizeParams (int pluginId, const std::vector<int>& paramIndices,
                          float minVal, float maxVal);

    /** Bypass or unbypass a hosted plugin (audio thread safe) */
    void setPluginBypass (int pluginId, bool bypass);

    /** Reset a crashed plugin so it can process again */
    void resetPluginCrash (int pluginId);

    /** Get the list of currently hosted plugins (for UI) */
    struct HostedPluginInfo {
        int id;
        juce::String name;
        juce::String path;
        int numParams;
        int busId;
    };
    std::vector<HostedPluginInfo> getHostedPluginList();

    /** Get a raw pointer to a hosted plugin instance (for opening its editor) */
    juce::AudioPluginInstance* getHostedPluginInstance (int pluginId);

    /** Set the parallel bus ID for a hosted plugin */
    void setPluginBusId (int pluginId, int busId);

    /** Routing mode: 0=sequential, 1=parallel */
    int  getRoutingMode() const    { return routingMode.load(); }
    void setRoutingMode (int mode) { routingMode.store (juce::jlimit (0, 1, mode)); }

    void setBusVolume (int bus, float vol);
    void setBusMute  (int bus, bool m);
    void setBusSolo  (int bus, bool s);

    /** UI state persistence — blocks, mappings, locks, order stored as JSON */
    void setUiState (const juce::String& json);
    juce::String getUiState() const;

    //==============================================================================
    // Sample Modulator API
    //==============================================================================

    /** Load an audio file for a specific logic block. Returns true on success. */
    bool loadSampleForBlock (int blockId, const juce::String& filePath);

    /** Get downsampled waveform peaks for UI display. */
    std::vector<float> getSampleWaveform (int blockId);

    /** Get the sample file name for a block (empty if none loaded). */
    juce::String getSampleFileName (int blockId);

private:
    //==============================================================================
    juce::AudioProcessorValueTreeState::ParameterLayout createParameterLayout();
    juce::AudioProcessorValueTreeState apvts;

    //==============================================================================
    // Plugin Hosting Engine
    //==============================================================================
    juce::AudioPluginFormatManager formatManager;
    juce::KnownPluginList knownPlugins;
    juce::AudioFormatManager audioFileFormatManager;  // WAV, AIFF, FLAC, etc.

    std::vector<std::unique_ptr<HostedPlugin>> hostedPlugins;
    std::mutex pluginMutex;
    int nextPluginId = 0;

    // Routing mode: 0 = sequential (chain), 1 = parallel (split/sum)
    std::atomic<int> routingMode { 0 };
    static constexpr int maxBuses = 8;
    juce::AudioBuffer<float> busBuffers[maxBuses];  // pre-allocated in prepareToPlay

    // Per-bus mixer state (parallel mode)
    std::atomic<float> busVolume[maxBuses]  { 1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f };
    std::atomic<bool>  busMute[maxBuses]    { false, false, false, false, false, false, false, false };
    std::atomic<bool>  busSolo[maxBuses]    { false, false, false, false, false, false, false, false };

    double currentSampleRate = 44100.0;
    int currentBlockSize = 512;

    // Pre-allocated scratch buffers (sized in prepareToPlay, never allocate on audio thread)
    juce::AudioBuffer<float> dryBuffer;    // dry signal copy for wet/dry mix
    struct MidiTrigEvent { int note; int vel; int ch; bool isCC; };
    std::vector<MidiTrigEvent> blockMidiEvents;  // MIDI events for trigger matching
    static constexpr int kMaxBlockMidi = 128;

public:
    /** Batch param apply — sets multiple params in a single call (avoids N IPC round-trips).
        Called from message thread. */
    void applyParamBatch (const juce::String& jsonBatch);

private:

public:
    //==============================================================================
    // Proxy Parameter Pool — exposes hosted params to DAW automation
    //==============================================================================
    static constexpr int proxyParamCount = 256;

    /** Drain proxy value cache from audio thread and call setValueNotifyingHost.
        Must be called from the message thread (editor timer). */
    void syncProxyCacheToHost();

private:

    struct ProxyMapping {
        int pluginId   = -1;   // -1 = unused slot
        int paramIndex = -1;
    };

    ProxyMapping                  proxyMap[proxyParamCount];
    ProxyParameter*               proxyParams[proxyParamCount] {};  // raw ptrs (owned by APVTS)
    std::atomic<bool>             proxySyncActive { false };        // prevents feedback loops
    int                           proxySyncCounter = 0;             // per-instance throttle counter

    /** Proxy value cache: audio thread writes, message thread reads + calls setValueNotifyingHost.
        Sentinel -999.0f = not yet written / no update pending. */
    std::atomic<float>            proxyValueCache[proxyParamCount];
    std::atomic<bool>             proxyDirty { false };             // true when cache has pending updates

    /** Assign proxy slots when a plugin is loaded, free them on remove */
    void assignProxySlotsForPlugin (int pluginId);
    void freeProxySlotsForPlugin   (int pluginId);

    /** Called by APVTS listener when a proxy param is automated from the DAW */
    void parameterChanged (const juce::String& parameterID, float newValue) override;

    //==============================================================================
    // UI State Persistence
    //==============================================================================
    mutable std::mutex uiStateMutex;
    juce::String uiStateJson;  // Full UI state as JSON (blocks, mappings, locks)

    //==============================================================================
    // Glide Engine — per-buffer parameter interpolation
    //==============================================================================

    /** Lock-free command FIFO: message thread writes, audio thread reads */
    struct GlideCommand {
        int pluginId    = 0;
        int paramIndex  = 0;
        float targetVal = 0.0f;
        float durationMs = 0.0f;
    };
    static constexpr int glideRingSize = 512;
    GlideCommand glideRing[glideRingSize];
    juce::AbstractFifo glideFifo { glideRingSize };

    /** Active glides being interpolated — only accessed on audio thread.
        Fixed-size pool: swap-to-end removal, no heap allocations. */
    struct ActiveGlide {
        int pluginId     = 0;
        int paramIndex   = 0;
        float currentVal = 0.0f;
        float targetVal  = 0.0f;
        float increment  = 0.0f;  // per-sample linear increment
        int samplesLeft  = 0;
    };
    static constexpr int kMaxGlides = 256;
    std::array<ActiveGlide, kMaxGlides> glidePool;
    int numActiveGlides = 0;  // only modified on audio thread

    //==============================================================================
    // Logic Block Engine — triggers, randomization, envelope followers
    // Runs in processBlock so it works even when the editor window is closed.
    //==============================================================================

    // ── Enum types for zero-alloc comparison in processBlock (H4 fix) ──
    enum class BlockMode : uint8_t { Randomize, Envelope, Sample, MorphPad, Shapes, ShapesRange, Lane, Unknown };
    enum class TriggerType : uint8_t { Manual, Tempo, Midi, Audio };
    enum class MidiTrigMode : uint8_t { AnyNote, SpecificNote, CC };
    enum class AudioSource : uint8_t { Main, Sidechain };
    enum class RangeMode : uint8_t { Absolute, Relative };
    enum class Movement : uint8_t { Instant, Glide };
    enum class Polarity : uint8_t { Bipolar, Up, Down, Unipolar };
    enum class ClockSource : uint8_t { Daw, Internal };
    enum class LoopMode : uint8_t { Oneshot, Loop, Pingpong };
    enum class JumpMode : uint8_t { Restart, Random };
    enum class MorphMode : uint8_t { Manual, Auto, Trigger };
    enum class ExploreMode : uint8_t { Wander, Bounce, Shapes, Orbit, Path };
    enum class LfoShape : uint8_t { Circle, Figure8, SweepX, SweepY, Triangle, Square, Hexagon, Pentagram, Hexagram, Rose4, Lissajous, Spiral };
    enum class MorphAction : uint8_t { Jump, Step };
    enum class StepOrder : uint8_t { Cycle, Random };
    enum class ShapeTracking : uint8_t { Horizontal, Vertical, Distance };
    enum class ShapeTrigger : uint8_t { Free, Midi };
    enum class LaneInterp : uint8_t { Smooth, Step, Linear };
    enum class LanePlayMode : uint8_t { Forward, Reverse, Pingpong, Random };

    // ── Enum parsers (called once in updateLogicBlocks, message thread) ──
    static BlockMode      parseBlockMode    (const juce::String& s);
    static TriggerType    parseTriggerType  (const juce::String& s);
    static MidiTrigMode   parseMidiTrigMode (const juce::String& s);
    static AudioSource    parseAudioSource  (const juce::String& s);
    static RangeMode      parseRangeMode    (const juce::String& s);
    static Movement       parseMovement     (const juce::String& s);
    static Polarity       parsePolarity     (const juce::String& s);
    static ClockSource    parseClockSource  (const juce::String& s);
    static LoopMode       parseLoopMode     (const juce::String& s);
    static JumpMode       parseJumpMode     (const juce::String& s);
    static MorphMode      parseMorphMode    (const juce::String& s);
    static ExploreMode    parseExploreMode  (const juce::String& s);
    static LfoShape       parseLfoShape     (const juce::String& s);
    static MorphAction    parseMorphAction  (const juce::String& s);
    static StepOrder      parseStepOrder    (const juce::String& s);
    static ShapeTracking  parseShapeTracking(const juce::String& s);
    static ShapeTrigger   parseShapeTrigger (const juce::String& s);
    static LaneInterp     parseLaneInterp   (const juce::String& s);
    static LanePlayMode   parseLanePlayMode (const juce::String& s);
    static float          parseBeatsPerDiv  (const juce::String& s);

    struct ParamTarget {
        int pluginId   = 0;
        int paramIndex = 0;
    };

    struct LogicBlock {
        int id = 0;
        juce::String mode;       // kept for serialization
        BlockMode modeE = BlockMode::Unknown;  // enum mirror for processBlock
        bool enabled = true;     // false = bypassed, skip processing
        std::vector<ParamTarget> targets;

        // Trigger
        juce::String trigger;
        TriggerType triggerE = TriggerType::Manual;
        juce::String beatDiv;
        float beatDivBeats = 1.0f;  // pre-computed beats-per-trigger
        juce::String midiMode;
        MidiTrigMode midiModeE = MidiTrigMode::AnyNote;
        int midiNote = 60;
        int midiCC   = 1;
        int midiCh   = 0;        // 0 = any channel
        float threshold = -12.0f;
        juce::String audioSrc;
        AudioSource audioSrcE = AudioSource::Main;

        // Range
        float rMin = 0.0f;
        float rMax = 1.0f;
        juce::String rangeMode;
        RangeMode rangeModeE = RangeMode::Absolute;
        bool quantize = false;
        int qSteps = 12;

        // Movement
        juce::String movement;
        Movement movementE = Movement::Instant;
        float glideMs = 200.0f;

        // Envelope follower (shared by envelope + sample modes)
        float envAtk = 10.0f;
        float envRel = 100.0f;
        float envSens = 50.0f;
        bool envInvert = false;

        // Polarity control
        juce::String polarity = "bipolar";
        Polarity polarityE = Polarity::Bipolar;

        // Clock source
        juce::String clockSource = "daw";
        ClockSource clockSourceE = ClockSource::Daw;
        float internalBpm = 120.0f;

        // Sample modulator settings
        juce::String loopMode;
        LoopMode loopModeE = LoopMode::Oneshot;
        float sampleSpeed = 1.0f;
        bool sampleReverse = false;
        juce::String jumpMode;
        JumpMode jumpModeE = JumpMode::Restart;

        // Runtime state (audio thread only, preserved across updateLogicBlocks)
        float currentEnvValue = 0.0f;
        int lastBeat = -1;
        double lastAudioTrigSample = 0.0;

        // Sample runtime state
        std::shared_ptr<SampleData> sampleData;
        double samplePlayhead = 0.0;
        int sampleDirection = 1;
        std::vector<float> targetBaseValues;
        std::vector<float> targetLastWritten;

        // ── Morph Pad ──
        struct MorphSnapshot {
            float x = 0.5f, y = 0.5f;
            std::vector<float> targetValues;
        };
        std::vector<MorphSnapshot> snapshots;
        float playheadX = 0.5f, playheadY = 0.5f;
        juce::String morphMode;
        MorphMode morphModeE = MorphMode::Manual;
        juce::String exploreMode;
        ExploreMode exploreModeE = ExploreMode::Wander;
        juce::String lfoShape;
        LfoShape lfoShapeE = LfoShape::Circle;
        float lfoDepth = 0.8f;
        float lfoRotation = 0.0f;
        float morphSpeed = 0.5f;
        juce::String morphAction;
        MorphAction morphActionE = MorphAction::Jump;
        juce::String stepOrder;
        StepOrder stepOrderE = StepOrder::Cycle;
        juce::String morphSource;
        float jitter = 0.0f;
        float morphGlide = 200.0f;
        bool  morphTempoSync = false;
        juce::String morphSyncDiv;
        float morphSyncDivBeats = 1.0f;  // pre-computed
        float snapRadius = 1.0f;

        // Morph runtime state (audio thread only, preserved across updateLogicBlocks)
        float morphVelX = 0.0f, morphVelY = 0.0f;
        float morphAngle = 0.0f;
        float morphLfoPhase = 0.0f;
        float lfoRotAngle = 0.0f;
        int morphStepIndex = 0;
        float morphSmoothX = 0.5f, morphSmoothY = 0.5f;
        float prevAppliedX = 0.5f, prevAppliedY = 0.5f;
        float morphNoisePhaseX = 0.0f, morphNoisePhaseY = 0.0f;
        float morphOrbitPhase = 0.0f;
        int   morphOrbitTarget = 0;
        float morphPathProgress = 0.0f;
        int   morphPathIndex = 0;

        // ── Shapes Block ──
        juce::String shapeType;
        LfoShape shapeTypeE = LfoShape::Circle;  // reuses LfoShape enum
        juce::String shapeTracking;
        ShapeTracking shapeTrackingE = ShapeTracking::Horizontal;
        float shapeSize = 0.8f;
        float shapeSpin = 0.0f;
        float shapeSpeed = 0.5f;
        float shapeDepth = 0.5f;
        juce::String shapeRange;
        RangeMode shapeRangeE = RangeMode::Absolute;
        juce::String shapePolarity;
        Polarity shapePolarityE = Polarity::Bipolar;
        bool shapeTempoSync = false;
        juce::String shapeSyncDiv;
        float shapeSyncDivBeats = 1.0f;  // pre-computed
        juce::String shapeTrigger;
        ShapeTrigger shapeTriggerE = ShapeTrigger::Free;
        // Per-param range values for shapes_range mode (aligned with targets)
        std::vector<float> targetRangeValues;
        std::vector<float> targetRangeBaseValues;
        std::vector<float> smoothedRangeValues;
        // Shapes runtime state
        float shapePhase = 0.0f;
        float shapeRotAngle = 0.0f;
        float smoothedShapeDepth = 0.0f;

        // ── Lane Clips ──
        struct LaneClip {
            struct LaneTarget { int pluginId = 0; int paramIndex = 0; };
            std::vector<LaneTarget> targets;
            struct Point { float x = 0.0f, y = 0.0f; };
            std::vector<Point> pts;
            juce::String loopLen;
            float loopLenBeats = 1.0f;  // pre-computed (0 = free mode)
            bool loopLenFree = false;   // true when loopLen == "free"
            float freeSecs = 4.0f;
            float phase = 0.0f;
            float depth = 1.0f;
            float slew  = 0.0f;
            float warp  = 0.0f;
            juce::String interp;
            LaneInterp interpE = LaneInterp::Smooth;
            juce::String playMode;
            LanePlayMode playModeE = LanePlayMode::Forward;
            bool synced = true;
            bool muted = false;
            // Runtime
            double playhead = 0.0;
            int direction = 1;
            float slewState = 0.5f;
        };
        std::vector<LaneClip> laneClips;
    };

    std::mutex blockMutex;                  // Protects logicBlocks; updateLogicBlocks holds it,
                                            // processBlock uses try_lock
    std::vector<LogicBlock> logicBlocks;
    juce::Random audioRandom;               // RNG for audio-thread randomization
    double sampleCounter = 0.0;             // Monotonic sample position for trigger cooldowns

    // ══════════════════════════════════════════════════════════════
    // Pre-allocated flat arrays — ZERO heap allocations on audio thread
    // ══════════════════════════════════════════════════════════════
    static constexpr int kMaxPlugins = 32;
    static constexpr int kMaxParams  = 1024;

    // O(1) plugin lookup by slot — avoids linear scan of hostedPlugins
    // Updated by rebuildPluginSlots() whenever plugins are added/removed
    HostedPlugin* pluginSlots[kMaxPlugins] = {};
    void rebuildPluginSlots();

    // Last value written to each param by ANY logic block.
    // Used by relative mode to distinguish "another block wrote this" from "user moved it".
    // Sentinel: -1.0f = never written.
    float paramWritten[kMaxPlugins][kMaxParams];

    // Params currently being touched (grabbed) by the user — skip modulation.
    // Atomic: written by UI thread, read by audio thread.
    std::atomic<bool> paramTouched[kMaxPlugins][kMaxParams];

    // Map pluginId → array slot index (pluginId % kMaxPlugins)
    int slotForId (int pluginId) const;


    /** Set a param directly on a hosted plugin (audio thread) */
    void setParamDirect (int pluginId, int paramIndex, float value);

public:
    /** Mark a param as touched (user grabbing it) — modulation suspends */
    void touchParam (int pluginId, int paramIndex)
    {
        int slot = slotForId (pluginId);
        if (slot >= 0 && paramIndex >= 0 && paramIndex < kMaxParams)
            paramTouched[slot][paramIndex].store (true, std::memory_order_release);
    }

    /** Release a touched param — modulation resumes, base updates to current value */
    void untouchParam (int pluginId, int paramIndex)
    {
        int slot = slotForId (pluginId);
        if (slot >= 0 && paramIndex >= 0 && paramIndex < kMaxParams)
        {
            paramTouched[slot][paramIndex].store (false, std::memory_order_release);
            // Update base values in all blocks that target this param
            float cur = getParamValue (pluginId, paramIndex);
            std::lock_guard<std::mutex> lock (blockMutex);
            for (auto& lb : logicBlocks)
            {
                for (size_t ti = 0; ti < lb.targets.size(); ++ti)
                {
                    if (lb.targets[ti].pluginId == pluginId && lb.targets[ti].paramIndex == paramIndex)
                    {
                        if (ti < lb.targetBaseValues.size())
                            lb.targetBaseValues[ti] = cur;
                        if (ti < lb.targetLastWritten.size())
                            lb.targetLastWritten[ti] = cur;
                    }
                }
            }
            paramWritten[slot][paramIndex] = cur;
        }
    }

    /** Read a param value from a hosted plugin (audio thread, pluginMutex already held) */
    float getParamValue (int pluginId, int paramIndex) const;

    /** Get the set of param keys (pluginId:paramIndex strings) currently targeted by any logic block.
        Used by the editor to prioritize polling of modulated params.
        Uses blockMutex (not pluginMutex), so safe to call from message thread. */
    std::unordered_set<std::string> getModulatedParamKeys()
    {
        std::unordered_set<std::string> result;
        std::lock_guard<std::mutex> lock (blockMutex);
        for (const auto& lb : logicBlocks)
        {
            if (!lb.enabled) continue;
            for (const auto& t : lb.targets)
                result.insert (std::to_string (t.pluginId) + ":" + std::to_string (t.paramIndex));
            for (const auto& lc : lb.laneClips)
                for (const auto& lt : lc.targets)
                    result.insert (std::to_string (lt.pluginId) + ":" + std::to_string (lt.paramIndex));
        }
        return result;
    }

    /** Fast single-param value read — lock-free, O(1) lookup!
        JUCE's AudioProcessorParameter::getValue() is already atomic internally.
        hostedPlugins vector is stable (pre-reserved, never erased during processing).
        This is how DAWs read params without blocking the audio thread. */
    float getParamValueFast (int pluginId, int paramIndex)
    {
        int slot = slotForId (pluginId);
        if (slot >= 0)
        {
            auto* hp = pluginSlots[slot];
            if (hp && hp->id == pluginId && hp->instance)
            {
                auto& params = hp->instance->getParameters();
                if (paramIndex >= 0 && paramIndex < params.size())
                    return params[paramIndex]->getValue();
            }
        }
        return -1.0f;
    }

    /** Fast single-param display text — lock-free, O(1) lookup! */
    juce::String getParamDisplayTextFast (int pluginId, int paramIndex)
    {
        int slot = slotForId (pluginId);
        if (slot >= 0)
        {
            auto* hp = pluginSlots[slot];
            if (hp && hp->id == pluginId && hp->instance)
            {
                auto& params = hp->instance->getParameters();
                if (paramIndex >= 0 && paramIndex < params.size())
                    return params[paramIndex]->getText (params[paramIndex]->getValue(), 32);
            }
        }
        return {};
    }

public:
    //==============================================================================
    // Real-time data for UI (written in processBlock, read from editor timer)
    //==============================================================================
    std::atomic<float> currentRmsLevel { 0.0f };   // Main input audio RMS (0..1)
    std::atomic<float> sidechainRmsLevel { 0.0f };  // Sidechain input RMS (0..1)
    std::atomic<double> currentBpm { 120.0 };       // DAW BPM
    std::atomic<bool> isPlaying { false };           // DAW transport playing
    std::atomic<double> ppqPosition { 0.0 };         // PPQ position for tempo sync

    // MIDI event buffer for UI (recent note-on/CC events)
    // Lock-free SPSC FIFO: audio thread writes, UI timer reads
    struct MidiEvent {
        int note     = 0; // MIDI note number (0-127) or CC number
        int velocity = 0; // velocity or CC value
        int channel  = 0; // MIDI channel (1-16)
        bool isCC    = false; // true if CC, false if note
    };
    static constexpr int midiRingSize = 256;
    MidiEvent midiRing[midiRingSize];
    juce::AbstractFifo midiFifo { midiRingSize };

    // Envelope follower levels for UI display (written by processBlock)
    static constexpr int maxEnvReadback = 16;
    struct EnvReadback {
        std::atomic<int>   blockId { -1 };
        std::atomic<float> level   { 0.0f };
    };
    EnvReadback envReadback[maxEnvReadback];
    std::atomic<int> numActiveEnvBlocks { 0 };

    // Sample modulator playhead positions for UI display
    static constexpr int maxSampleReadback = 16;
    struct SampleReadback {
        std::atomic<int>   blockId  { -1 };
        std::atomic<float> playhead { 0.0f };  // 0..1 normalised position
    };
    SampleReadback sampleReadback[maxSampleReadback];
    std::atomic<int> numActiveSampleBlocks { 0 };

    // Morph pad playhead positions for UI display
    static constexpr int maxMorphReadback = 8;
    struct MorphReadback {
        std::atomic<int>   blockId  { -1 };
        std::atomic<float> headX    { 0.5f };
        std::atomic<float> headY    { 0.5f };
        std::atomic<float> rotAngle { 0.0f };
    };
    MorphReadback morphReadback[maxMorphReadback];
    std::atomic<int> numActiveMorphBlocks { 0 };

    // Lane playhead positions for UI display
    static constexpr int maxLaneReadback = 32; // max lanes across all blocks
    struct LaneReadback {
        std::atomic<int>   blockId   { -1 };
        std::atomic<int>   laneIdx   { -1 };
        std::atomic<float> playhead  { 0.0f };
        std::atomic<float> value     { 0.5f }; // current evaluated value (0..1)
    };
    LaneReadback laneReadback[maxLaneReadback];
    std::atomic<int> numActiveLanes { 0 };

    // Trigger fire events for UI flash (lock-free FIFO)
    static constexpr int triggerRingSize = 64;
    int triggerRing[triggerRingSize] = {};
    juce::AbstractFifo triggerFifo { triggerRingSize };

    // Crash notification FIFO — audio thread writes, UI timer reads
    struct CrashEvent {
        int pluginId = 0;
        char pluginName[64] = {};
        char reason[128] = {};
    };
    static constexpr int crashRingSize = 16;
    CrashEvent crashRing[crashRingSize] = {};
    juce::AbstractFifo crashFifo { crashRingSize };

    // Self-write tracking for auto-locate filtering
    // Records pluginId:paramIndex pairs that OUR code wrote,
    // so the editor can exclude them from "touched by plugin UI" detection.
    struct SelfWriteEvent {
        int pluginId;
        int paramIndex;
    };
    static constexpr int selfWriteRingSize = 2048;
    SelfWriteEvent selfWriteRing[selfWriteRingSize] = {};
    juce::AbstractFifo selfWriteFifo { selfWriteRingSize };

    /** Record that we wrote a param (call from any thread, lock-free) */
    void recordSelfWrite (int pluginId, int paramIndex)
    {
        const auto scope = selfWriteFifo.write (1);
        if (scope.blockSize1 > 0)
            selfWriteRing[scope.startIndex1] = { pluginId, paramIndex };
    }

private:
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (ModularRandomizerAudioProcessor)
};
