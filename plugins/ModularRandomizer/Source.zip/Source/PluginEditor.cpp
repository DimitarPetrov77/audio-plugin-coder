/*
  ==============================================================================

    Modular Randomizer - PluginEditor
    WebView2-based UI with native function bridge

  ==============================================================================
*/

#include "PluginEditor.h"
#include <unordered_set>
#include <unordered_map>
#include "ParameterIDs.hpp"
#include <BinaryData.h>

//==============================================================================
ModularRandomizerAudioProcessorEditor::ModularRandomizerAudioProcessorEditor (
    ModularRandomizerAudioProcessor& p)
    : AudioProcessorEditor (&p),
      audioProcessor (p)
{
    DBG ("ModularRandomizer: Editor constructor started");

    //==========================================================================
    // CRITICAL: CREATION ORDER (matches CloudWash webview-004 fix)
    // 1. Relays already created (member initialization)
    // 2. Create attachments BEFORE WebView
    // 3. Create WebBrowserComponent with proper JUCE 8 API
    // 4. addAndMakeVisible LAST
    //==========================================================================

    // Create parameter attachments BEFORE creating WebView
    DBG ("ModularRandomizer: Creating parameter attachments");
    mixAttachment = std::make_unique<juce::WebSliderParameterAttachment> (
        *audioProcessor.getAPVTS().getParameter (ParameterIDs::MIX), mixRelay);

    bypassAttachment = std::make_unique<juce::WebToggleButtonParameterAttachment> (
        *audioProcessor.getAPVTS().getParameter (ParameterIDs::BYPASS), bypassRelay);

    // Create WebBrowserComponent with JUCE 8 proper API
    // CRITICAL: Attachments must be created BEFORE this point
    DBG ("ModularRandomizer: Creating WebView");
    webView = std::make_unique<juce::WebBrowserComponent> (
        juce::WebBrowserComponent::Options{}
            .withBackend (juce::WebBrowserComponent::Options::Backend::webview2)
            .withWinWebView2Options (
                juce::WebBrowserComponent::Options::WinWebView2{}
                    .withUserDataFolder (juce::File::getSpecialLocation (
                        juce::File::SpecialLocationType::tempDirectory))
            )
            .withNativeIntegrationEnabled()  // CRITICAL: Enable window.__JUCE__ backend
            .withResourceProvider ([this] (const auto& url) { return getResource (url); })
            .withOptionsFrom (mixRelay)
            .withOptionsFrom (bypassRelay)
            .withNativeFunction (
                "scanPlugins",
                [this] (const juce::Array<juce::var>& args,
                        juce::WebBrowserComponent::NativeFunctionCompletion completion)
                {
                    LOG_TO_FILE ("=== scanPlugins native function called, args count: " << args.size());

                    juce::StringArray paths;
                    if (args.size() > 0 && args[0].isArray())
                    {
                        for (int i = 0; i < args[0].size(); ++i)
                            paths.add (args[0][i].toString());
                    }

                    if (paths.isEmpty())
                        paths.add ("C:\\Program Files\\Common Files\\VST3");

                    LOG_TO_FILE ("  Launching background scan thread...");

                    // Move completion into a shared_ptr so it can be safely captured
                    auto sharedCompletion = std::make_shared<juce::WebBrowserComponent::NativeFunctionCompletion> (
                        std::move (completion));

                    juce::Thread::launch ([this, paths, sharedCompletion]()
                    {
                        LOG_TO_FILE ("  Background thread: starting scan");
                        auto results = audioProcessor.scanForPlugins (paths);
                        LOG_TO_FILE ("  Background thread: scan returned " << results.size() << " plugins");

                        juce::Array<juce::var> pluginList;
                        for (const auto& sp : results)
                        {
                            auto* obj = new juce::DynamicObject();
                            obj->setProperty ("name", sp.name);
                            obj->setProperty ("vendor", sp.vendor);
                            obj->setProperty ("category", sp.category);
                            obj->setProperty ("path", sp.path);
                            obj->setProperty ("format", sp.format);
                            pluginList.add (juce::var (obj));
                        }

                        LOG_TO_FILE ("  Background thread: calling completion with " << pluginList.size() << " items");
                        // NativeFunctionCompletion can be called from any thread
                        (*sharedCompletion) (juce::var (pluginList));
                        LOG_TO_FILE ("  Background thread: completion called successfully");
                    });
                }
            )
            .withNativeFunction (
                "saveUiState",
                [this] (const juce::Array<juce::var>& args,
                        juce::WebBrowserComponent::NativeFunctionCompletion completion)
                {
                    if (args.size() > 0)
                        audioProcessor.setUiState (args[0].toString());
                    completion (juce::var ("ok"));
                }
            )
            .withNativeFunction (
                "getFullState",
                [this] (const juce::Array<juce::var>&,
                        juce::WebBrowserComponent::NativeFunctionCompletion completion)
                {
                    // Build response: { plugins: [...], uiState: "..." }
                    auto* result = new juce::DynamicObject();

                    // Current hosted plugins (already loaded in processor)
                    juce::Array<juce::var> plugArr;
                    auto pluginList = audioProcessor.getHostedPluginList();
                    for (const auto& info : pluginList)
                    {
                        auto* pObj = new juce::DynamicObject();
                        pObj->setProperty ("id", info.id);
                        pObj->setProperty ("name", info.name);
                        pObj->setProperty ("path", info.path);

                        // Get current parameter values
                        auto params = audioProcessor.getHostedParams (info.id);
                        juce::Array<juce::var> paramArr;
                        for (const auto& p : params)
                        {
                            auto* paramObj = new juce::DynamicObject();
                            paramObj->setProperty ("index", p.index);
                            paramObj->setProperty ("name", p.name);
                            paramObj->setProperty ("value", (double) p.value);
                            paramObj->setProperty ("disp", p.displayText);
                            paramArr.add (juce::var (paramObj));
                        }
                        pObj->setProperty ("params", juce::var (paramArr));
                        pObj->setProperty ("busId", info.busId);
                        plugArr.add (juce::var (pObj));
                    }
                    result->setProperty ("plugins", juce::var (plugArr));
                    result->setProperty ("routingMode", audioProcessor.getRoutingMode());

                    // Saved UI state (blocks, mappings, locks)
                    auto uiState = audioProcessor.getUiState();
                    if (uiState.isNotEmpty())
                        result->setProperty ("uiState", uiState);

                    completion (juce::var (result));
                }
            )
            .withNativeFunction (
                "loadPlugin",
                [this] (const juce::Array<juce::var>& args,
                        juce::WebBrowserComponent::NativeFunctionCompletion completion)
                {
                    LOG_TO_FILE ("=== loadPlugin native function called, args count: " << args.size());

                    if (args.isEmpty())
                    {
                        LOG_TO_FILE ("  No args provided!");
                        completion (juce::var());
                        return;
                    }

                    auto pluginPath = args[0].toString();
                    LOG_TO_FILE ("  Received path from JS: " << pluginPath.toStdString());

                    // Load synchronously (VST3 COM requires message thread)
                    int pluginId = audioProcessor.loadPlugin (pluginPath);
                    LOG_TO_FILE ("  loadPlugin returned ID: " << pluginId);

                    if (pluginId < 0)
                    {
                        auto* err = new juce::DynamicObject();
                        err->setProperty ("error", "Failed to load plugin: " + pluginPath);
                        completion (juce::var (err));
                        return;
                    }

                    // Get the loaded plugin's parameters
                    auto params = audioProcessor.getHostedParams (pluginId);
                    DBG ("  Plugin has " + juce::String (params.size()) + " parameters");

                    auto* result = new juce::DynamicObject();
                    result->setProperty ("id", pluginId);

                    // Find name from hosted list
                    auto hosted = audioProcessor.getHostedPluginList();
                    for (auto& h : hosted)
                    {
                        if (h.id == pluginId)
                        {
                            result->setProperty ("name", h.name);
                            DBG ("  Plugin name: " + h.name);
                            break;
                        }
                    }

                    juce::Array<juce::var> paramList;
                    for (const auto& p : params)
                    {
                        auto* pObj = new juce::DynamicObject();
                        pObj->setProperty ("index", p.index);
                        pObj->setProperty ("name", p.name);
                        pObj->setProperty ("value", (double) p.value);
                        pObj->setProperty ("label", p.label);
                        pObj->setProperty ("disp", p.displayText);
                        pObj->setProperty ("automatable", p.automatable);
                        paramList.add (juce::var (pObj));
                    }
                    result->setProperty ("params", juce::var (paramList));

                    completion (juce::var (result));
                }
            )
            .withNativeFunction (
                "removePlugin",
                [this] (const juce::Array<juce::var>& args,
                        juce::WebBrowserComponent::NativeFunctionCompletion completion)
                {
                    try
                    {
                        if (args.size() > 0)
                        {
                            int pluginId = (int) args[0];

                            // Close editor window FIRST (prevents dangling pointer)
                            try {
                                auto it = pluginEditorWindows.find (pluginId);
                                if (it != pluginEditorWindows.end())
                                    pluginEditorWindows.erase (it);
                            } catch (...) {}

                            // Now remove from processor
                            try { audioProcessor.removePlugin (pluginId); } catch (...) {}
                        }
                    }
                    catch (...) {}
                    completion (juce::var ("ok"));
                }
            )
            .withNativeFunction (
                "setParam",
                [this] (const juce::Array<juce::var>& args,
                        juce::WebBrowserComponent::NativeFunctionCompletion completion)
                {
                    // args: [pluginId, paramIndex, normValue]
                    if (args.size() >= 3)
                    {
                        int pluginId = (int) args[0];
                        int paramIdx = (int) args[1];
                        float val = (float) (double) args[2];
                        audioProcessor.setHostedParam (pluginId, paramIdx, val);
                    }
                    completion (juce::var ("ok"));
                }
            )
            .withNativeFunction (
                "touchParam",
                [this] (const juce::Array<juce::var>& args,
                        juce::WebBrowserComponent::NativeFunctionCompletion completion)
                {
                    // args: [pluginId, paramIndex]
                    if (args.size() >= 2)
                        audioProcessor.touchParam ((int) args[0], (int) args[1]);
                    completion (juce::var ("ok"));
                }
            )
            .withNativeFunction (
                "untouchParam",
                [this] (const juce::Array<juce::var>& args,
                        juce::WebBrowserComponent::NativeFunctionCompletion completion)
                {
                    // args: [pluginId, paramIndex]
                    if (args.size() >= 2)
                        audioProcessor.untouchParam ((int) args[0], (int) args[1]);
                    completion (juce::var ("ok"));
                }
            )
            .withNativeFunction (
                "getParams",
                [this] (const juce::Array<juce::var>& args,
                        juce::WebBrowserComponent::NativeFunctionCompletion completion)
                {
                    // args: [pluginId]
                    if (args.isEmpty())
                    {
                        completion (juce::var());
                        return;
                    }

                    int pluginId = (int) args[0];
                    auto params = audioProcessor.getHostedParams (pluginId);

                    juce::Array<juce::var> paramList;
                    for (const auto& p : params)
                    {
                        auto pObj = new juce::DynamicObject();
                        pObj->setProperty ("index", p.index);
                        pObj->setProperty ("name", p.name);
                        pObj->setProperty ("value", (double) p.value);
                        pObj->setProperty ("label", p.label);
                        pObj->setProperty ("disp", p.displayText);
                        paramList.add (juce::var (pObj));
                    }
                    completion (juce::var (paramList));
                }
            )
            .withNativeFunction (
                "fireRandomize",
                [this] (const juce::Array<juce::var>& args,
                        juce::WebBrowserComponent::NativeFunctionCompletion completion)
                {
                    // args: [pluginId, paramIndicesArray, minVal, maxVal]
                    if (args.size() >= 4)
                    {
                        int pluginId = (int) args[0];
                        float minVal = (float) (double) args[2];
                        float maxVal = (float) (double) args[3];

                        std::vector<int> indices;
                        if (args[1].isArray())
                        {
                            for (int i = 0; i < args[1].size(); ++i)
                                indices.push_back ((int) args[1][i]);
                        }

                        audioProcessor.randomizeParams (pluginId, indices, minVal, maxVal);

                        // Return updated param values
                        auto params = audioProcessor.getHostedParams (pluginId);
                        juce::Array<juce::var> paramList;
                        for (const auto& p : params)
                        {
                            auto pObj = new juce::DynamicObject();
                            pObj->setProperty ("index", p.index);
                            pObj->setProperty ("name", p.name);
                            pObj->setProperty ("value", (double) p.value);
                            pObj->setProperty ("disp", p.displayText);
                            paramList.add (juce::var (pObj));
                        }
                        completion (juce::var (paramList));
                    }
                    else
                    {
                        completion (juce::var ("error: missing args"));
                    }
                }
            )
            .withNativeFunction (
                "updateBlocks",
                [this] (const juce::Array<juce::var>& args,
                        juce::WebBrowserComponent::NativeFunctionCompletion completion)
                {
                    // args: [jsonString]
                    if (args.size() > 0)
                    {
                        auto jsonStr = args[0].toString();
                        audioProcessor.updateLogicBlocks (jsonStr);
                    }
                    completion (juce::var ("ok"));
                }
            )
            .withNativeFunction (
                "updateMorphPlayhead",
                [this] (const juce::Array<juce::var>& args,
                        juce::WebBrowserComponent::NativeFunctionCompletion completion)
                {
                    // Lightweight playhead update — args: [blockId, x, y]
                    if (args.size() >= 3)
                    {
                        int blockId = (int) args[0];
                        float px = (float) (double) args[1];
                        float py = (float) (double) args[2];
                        audioProcessor.updateMorphPlayhead (blockId, px, py);
                    }
                    completion (juce::var ("ok"));
                }
            )
            .withNativeFunction (
                "startGlide",
                [this] (const juce::Array<juce::var>& args,
                        juce::WebBrowserComponent::NativeFunctionCompletion completion)
                {
                    // args: [pluginId, paramIndex, targetValue, durationMs]
                    if (args.size() >= 4)
                    {
                        int pluginId   = (int) args[0];
                        int paramIdx   = (int) args[1];
                        float target   = (float) (double) args[2];
                        float duration = (float) (double) args[3];
                        audioProcessor.startGlide (pluginId, paramIdx, target, duration);
                    }
                    completion (juce::var ("ok"));
                }
            )
            .withNativeFunction (
                "openPluginEditor",
                [this] (const juce::Array<juce::var>& args,
                        juce::WebBrowserComponent::NativeFunctionCompletion completion)
                {
                    if (args.size() > 0)
                    {
                        int pluginId = (int) args[0];
                        // Must run on message thread (creates GUI)
                        juce::Component::SafePointer<ModularRandomizerAudioProcessorEditor> safeThis (this);
                        juce::MessageManager::callAsync ([safeThis, pluginId]()
                        {
                            if (safeThis != nullptr)
                                safeThis->openPluginEditorWindow (pluginId);
                        });
                    }
                    completion (juce::var ("ok"));
                }
            )
            .withNativeFunction (
                "browseSample",
                [this] (const juce::Array<juce::var>& args,
                        juce::WebBrowserComponent::NativeFunctionCompletion completion)
                {
                    int blockId = args.size() > 0 ? (int) args[0] : -1;
                    if (blockId < 0)
                    {
                        completion (juce::var());
                        return;
                    }

                    auto sharedCompletion = std::make_shared<juce::WebBrowserComponent::NativeFunctionCompletion> (
                        std::move (completion));

                    auto chooser = std::make_shared<juce::FileChooser> (
                        "Select Audio File",
                        juce::File::getSpecialLocation (juce::File::userMusicDirectory),
                        "*.wav;*.aiff;*.aif;*.flac;*.mp3;*.ogg");

                    chooser->launchAsync (
                        juce::FileBrowserComponent::openMode | juce::FileBrowserComponent::canSelectFiles,
                        [this, blockId, chooser, sharedCompletion] (const juce::FileChooser& fc)
                        {
                            auto results = fc.getResults();
                            if (results.isEmpty())
                            {
                                (*sharedCompletion) (juce::var());
                                return;
                            }

                            auto filePath = results[0].getFullPathName();
                            bool ok = audioProcessor.loadSampleForBlock (blockId, filePath);

                            if (ok)
                            {
                                auto waveform = audioProcessor.getSampleWaveform (blockId);
                                auto* result = new juce::DynamicObject();
                                result->setProperty ("name", results[0].getFileName());
                                result->setProperty ("path", filePath);
                                result->setProperty ("duration",
                                    juce::var ((double) results[0].getSize() / 44100.0)); // rough estimate

                                juce::Array<juce::var> peaks;
                                for (float p : waveform)
                                    peaks.add ((double) p);
                                result->setProperty ("waveform", juce::var (peaks));

                                (*sharedCompletion) (juce::var (result));
                            }
                            else
                            {
                                (*sharedCompletion) (juce::var());
                            }
                        });
                }
            )
            .withNativeFunction (
                "setPluginBypass",
                [this] (const juce::Array<juce::var>& args,
                        juce::WebBrowserComponent::NativeFunctionCompletion completion)
                {
                    if (args.size() >= 2)
                        audioProcessor.setPluginBypass ((int) args[0], (bool) args[1]);
                    completion (juce::var ("ok"));
                }
            )
            .withNativeFunction (
                "resetPluginCrash",
                [this] (const juce::Array<juce::var>& args,
                        juce::WebBrowserComponent::NativeFunctionCompletion completion)
                {
                    // Re-enable a crashed plugin — user acknowledges the risk
                    if (args.size() >= 1)
                        audioProcessor.resetPluginCrash ((int) args[0]);
                    completion (juce::var ("ok"));
                }
            )
            .withNativeFunction (
                "savePluginPreset",
                [this] (const juce::Array<juce::var>& args,
                        juce::WebBrowserComponent::NativeFunctionCompletion completion)
                {
                    if (args.size() >= 3)
                    {
                        auto pluginName = args[0].toString();
                        auto presetName = args[1].toString();
                        auto jsonData   = args[2].toString();

                        auto presetsDir = juce::File::getSpecialLocation (juce::File::userApplicationDataDirectory)
                                              .getChildFile ("Noizefield/ModularRandomizer/Presets")
                                              .getChildFile (pluginName);
                        presetsDir.createDirectory();

                        auto presetFile = presetsDir.getChildFile (presetName + ".json");
                        presetFile.replaceWithText (jsonData);
                        completion (juce::var ("ok"));
                    }
                    else
                        completion (juce::var());
                }
            )
            .withNativeFunction (
                "getPluginPresets",
                [this] (const juce::Array<juce::var>& args,
                        juce::WebBrowserComponent::NativeFunctionCompletion completion)
                {
                    juce::Array<juce::var> presetNames;
                    if (args.size() >= 1)
                    {
                        auto pluginName = args[0].toString();
                        auto presetsDir = juce::File::getSpecialLocation (juce::File::userApplicationDataDirectory)
                                              .getChildFile ("Noizefield/ModularRandomizer/Presets")
                                              .getChildFile (pluginName);

                        if (presetsDir.isDirectory())
                        {
                            for (const auto& f : presetsDir.findChildFiles (juce::File::findFiles, false, "*.json"))
                                presetNames.add (f.getFileNameWithoutExtension());
                        }
                    }
                    completion (juce::var (presetNames));
                }
            )
            .withNativeFunction (
                "deletePluginPreset",
                [this] (const juce::Array<juce::var>& args,
                        juce::WebBrowserComponent::NativeFunctionCompletion completion)
                {
                    if (args.size() >= 2)
                    {
                        auto pluginName = args[0].toString();
                        auto presetName = args[1].toString();
                        auto presetsDir = juce::File::getSpecialLocation (juce::File::userApplicationDataDirectory)
                                              .getChildFile ("Noizefield/ModularRandomizer/Presets")
                                              .getChildFile (pluginName);
                        auto presetFile = presetsDir.getChildFile (presetName + ".json");
                        if (presetFile.existsAsFile())
                            presetFile.deleteFile();
                    }
                    completion (juce::var ("ok"));
                }
            )
            .withNativeFunction (
                "loadPluginPreset",
                [this] (const juce::Array<juce::var>& args,
                        juce::WebBrowserComponent::NativeFunctionCompletion completion)
                {
                    if (args.size() >= 2)
                    {
                        auto pluginName = args[0].toString();
                        auto presetName = args[1].toString();
                        auto presetsDir = juce::File::getSpecialLocation (juce::File::userApplicationDataDirectory)
                                              .getChildFile ("Noizefield/ModularRandomizer/Presets")
                                              .getChildFile (pluginName);
                        auto presetFile = presetsDir.getChildFile (presetName + ".json");
                        if (presetFile.existsAsFile())
                        {
                            completion (juce::var (presetFile.loadFileAsString()));
                            return;
                        }
                    }
                    completion (juce::var());
                }
            )
            .withNativeFunction (
                "saveGlobalPreset",
                [this] (const juce::Array<juce::var>& args,
                        juce::WebBrowserComponent::NativeFunctionCompletion completion)
                {
                    if (args.size() >= 2)
                    {
                        auto presetName = args[0].toString();
                        auto jsonData   = args[1].toString();
                        auto presetsDir = juce::File::getSpecialLocation (juce::File::userApplicationDataDirectory)
                                              .getChildFile ("Noizefield/ModularRandomizer/GlobalPresets");
                        presetsDir.createDirectory();
                        auto presetFile = presetsDir.getChildFile (presetName + ".json");
                        presetFile.replaceWithText (jsonData);
                    }
                    completion (juce::var ("ok"));
                }
            )
            .withNativeFunction (
                "getGlobalPresets",
                [this] (const juce::Array<juce::var>& args,
                        juce::WebBrowserComponent::NativeFunctionCompletion completion)
                {
                    juce::ignoreUnused (args);
                    juce::Array<juce::var> presetNames;
                    auto presetsDir = juce::File::getSpecialLocation (juce::File::userApplicationDataDirectory)
                                          .getChildFile ("Noizefield/ModularRandomizer/GlobalPresets");
                    if (presetsDir.isDirectory())
                    {
                        for (const auto& f : presetsDir.findChildFiles (juce::File::findFiles, false, "*.json"))
                            presetNames.add (f.getFileNameWithoutExtension());
                    }
                    completion (juce::var (presetNames));
                }
            )
            .withNativeFunction (
                "loadGlobalPreset",
                [this] (const juce::Array<juce::var>& args,
                        juce::WebBrowserComponent::NativeFunctionCompletion completion)
                {
                    if (args.size() >= 1)
                    {
                        auto presetName = args[0].toString();
                        auto presetsDir = juce::File::getSpecialLocation (juce::File::userApplicationDataDirectory)
                                              .getChildFile ("Noizefield/ModularRandomizer/GlobalPresets");
                        auto presetFile = presetsDir.getChildFile (presetName + ".json");
                        if (presetFile.existsAsFile())
                        {
                            completion (juce::var (presetFile.loadFileAsString()));
                            return;
                        }
                    }
                    completion (juce::var());
                }
            )
            .withNativeFunction (
                "deleteGlobalPreset",
                [this] (const juce::Array<juce::var>& args,
                        juce::WebBrowserComponent::NativeFunctionCompletion completion)
                {
                    if (args.size() >= 1)
                    {
                        auto presetName = args[0].toString();
                        auto presetsDir = juce::File::getSpecialLocation (juce::File::userApplicationDataDirectory)
                                              .getChildFile ("Noizefield/ModularRandomizer/GlobalPresets");
                        auto presetFile = presetsDir.getChildFile (presetName + ".json");
                        if (presetFile.existsAsFile())
                            presetFile.deleteFile();
                    }
                    completion (juce::var ("ok"));
                }
            )
            .withNativeFunction (
                "setEditorScale",
                [this] (const juce::Array<juce::var>& args,
                        juce::WebBrowserComponent::NativeFunctionCompletion completion)
                {
                    if (args.size() >= 1)
                    {
                        double scale = (double) args[0];
                        if (scale < 0.5) scale = 0.5;
                        if (scale > 2.0) scale = 2.0;
                        // Base UI size matches initial setSize
                        constexpr int baseW = 1060, baseH = 720;
                        int w = juce::roundToInt (baseW * scale);
                        int h = juce::roundToInt (baseH * scale);
                        juce::Component::SafePointer<ModularRandomizerAudioProcessorEditor> safeThis (this);
                        juce::MessageManager::callAsync ([safeThis, w, h]()
                        {
                            if (safeThis != nullptr)
                                safeThis->setSize (w, h);
                        });
                    }
                    completion (juce::var ("ok"));
                }
            )
            .withNativeFunction (
                "setRoutingMode",
                [this] (const juce::Array<juce::var>& args,
                        juce::WebBrowserComponent::NativeFunctionCompletion completion)
                {
                    if (args.size() >= 1)
                    {
                        int mode = (int) args[0];
                        audioProcessor.setRoutingMode (mode);
                    }
                    completion (juce::var ("ok"));
                }
            )
            .withNativeFunction (
                "setPluginBus",
                [this] (const juce::Array<juce::var>& args,
                        juce::WebBrowserComponent::NativeFunctionCompletion completion)
                {
                    if (args.size() >= 2)
                    {
                        int pluginId = (int) args[0];
                        int busId    = (int) args[1];
                        audioProcessor.setPluginBusId (pluginId, busId);
                    }
                    completion (juce::var ("ok"));
                }
            )
            .withNativeFunction (
                "setBusVolume",
                [this] (const juce::Array<juce::var>& args,
                        juce::WebBrowserComponent::NativeFunctionCompletion completion)
                {
                    if (args.size() >= 2)
                        audioProcessor.setBusVolume ((int) args[0], (float) (double) args[1]);
                    completion (juce::var ("ok"));
                }
            )
            .withNativeFunction (
                "setBusMute",
                [this] (const juce::Array<juce::var>& args,
                        juce::WebBrowserComponent::NativeFunctionCompletion completion)
                {
                    if (args.size() >= 2)
                        audioProcessor.setBusMute ((int) args[0], (bool) args[1]);
                    completion (juce::var ("ok"));
                }
            )
            .withNativeFunction (
                "setBusSolo",
                [this] (const juce::Array<juce::var>& args,
                        juce::WebBrowserComponent::NativeFunctionCompletion completion)
                {
                    if (args.size() >= 2)
                        audioProcessor.setBusSolo ((int) args[0], (bool) args[1]);
                    completion (juce::var ("ok"));
                }
            )
            .withNativeFunction (
                "reorderPlugins",
                [this] (const juce::Array<juce::var>& args,
                        juce::WebBrowserComponent::NativeFunctionCompletion completion)
                {
                    if (args.size() > 0 && args[0].isArray())
                    {
                        auto* arr = args[0].getArray();
                        std::vector<int> orderedIds;
                        orderedIds.reserve ((size_t) arr->size());
                        for (auto& v : *arr)
                            orderedIds.push_back ((int) v);
                        audioProcessor.reorderPlugins (orderedIds);
                    }
                    completion (juce::var ("ok"));
                }
            )
            .withNativeFunction (
                "applyParamBatch",
                [this] (const juce::Array<juce::var>& args,
                        juce::WebBrowserComponent::NativeFunctionCompletion completion)
                {
                    // Batch param apply — sets N params in a single IPC call.
                    // args: [jsonString] where json is [{"p":pluginId,"i":paramIndex,"v":value}, ...]
                    if (args.size() > 0)
                        audioProcessor.applyParamBatch (args[0].toString());
                    completion (juce::var ("ok"));
                }
            )
            .withNativeFunction (
                "setExpandedPlugins",
                [this] (const juce::Array<juce::var>& args,
                        juce::WebBrowserComponent::NativeFunctionCompletion completion)
                {
                    // Visibility culling: JS tells us which plugin IDs are expanded.
                    // We skip polling params from collapsed plugins.
                    std::unordered_set<int> newExpanded;
                    if (args.size() > 0 && args[0].isArray())
                    {
                        for (int i = 0; i < args[0].size(); ++i)
                            newExpanded.insert ((int) args[0][i]);
                    }

                    // Detect newly expanded plugins — clear their lastParamValues for full resync
                    for (int id : newExpanded)
                    {
                        if (expandedPluginIds.count (id) == 0)
                        {
                            // This plugin was just expanded — clear cached values so
                            // Tier 2 treats all its params as new and sends a full batch
                            for (auto it = lastParamValues.begin(); it != lastParamValues.end(); )
                            {
                                auto identIt = paramIdentCache.find (it->first);
                                if (identIt != paramIdentCache.end() && identIt->second.pluginId == id)
                                    it = lastParamValues.erase (it);
                                else
                                    ++it;
                            }
                        }
                    }

                    expandedPluginIds = std::move (newExpanded);
                    completion (juce::var ("ok"));
                }
            )
    );

    // CRITICAL: addAndMakeVisible AFTER attachments are created
    DBG ("ModularRandomizer: Adding WebView to component");
    addAndMakeVisible (*webView);

    // Navigate to resource provider root (serves index.html via root handler)
    DBG ("ModularRandomizer: Loading web content");
    webView->goToURL (juce::WebBrowserComponent::getResourceProviderRoot());

    // Set editor size
    setSize (1060, 720);

    // Start timer for periodic UI updates (30fps)
    startTimerHz (60);

#if JUCE_DEBUG
    DBG ("Resource provider root: " + juce::WebBrowserComponent::getResourceProviderRoot());
#endif

    DBG ("ModularRandomizer: Editor constructor completed");
}

ModularRandomizerAudioProcessorEditor::~ModularRandomizerAudioProcessorEditor()
{
    stopTimer();

    // Close all hosted plugin editor windows BEFORE destroying the WebView.
    // This prevents use-after-free from async close callbacks.
    pluginEditorWindows.clear();
}

//==============================================================================
void ModularRandomizerAudioProcessorEditor::paint (juce::Graphics& g)
{
    g.fillAll (juce::Colour (0xFF252018));
}

void ModularRandomizerAudioProcessorEditor::resized()
{
    if (webView != nullptr)
        webView->setBounds (getLocalBounds());
}

void ModularRandomizerAudioProcessorEditor::timerCallback()
{
    if (webView == nullptr) return;

    ++timerTickCount;

    // Build real-time data object for JS
    auto* data = new juce::DynamicObject();

    // Audio levels (0..1 RMS)
    data->setProperty ("rms", (double) audioProcessor.currentRmsLevel.load());
    data->setProperty ("scRms", (double) audioProcessor.sidechainRmsLevel.load());

    // Transport
    data->setProperty ("bpm", audioProcessor.currentBpm.load());
    data->setProperty ("playing", audioProcessor.isPlaying.load());
    data->setProperty ("ppq", audioProcessor.ppqPosition.load());

    // MIDI events since last tick (lock-free FIFO read)
    juce::Array<juce::var> midiArr;
    {
        const auto scope = audioProcessor.midiFifo.read (audioProcessor.midiFifo.getNumReady());
        for (int i = 0; i < scope.blockSize1; ++i)
        {
            const auto& ev = audioProcessor.midiRing[scope.startIndex1 + i];
            auto* mObj = new juce::DynamicObject();
            mObj->setProperty ("note", ev.note);
            mObj->setProperty ("vel", ev.velocity);
            mObj->setProperty ("ch", ev.channel);
            mObj->setProperty ("cc", ev.isCC);
            midiArr.add (juce::var (mObj));
        }
        for (int i = 0; i < scope.blockSize2; ++i)
        {
            const auto& ev = audioProcessor.midiRing[scope.startIndex2 + i];
            auto* mObj = new juce::DynamicObject();
            mObj->setProperty ("note", ev.note);
            mObj->setProperty ("vel", ev.velocity);
            mObj->setProperty ("ch", ev.channel);
            mObj->setProperty ("cc", ev.isCC);
            midiArr.add (juce::var (mObj));
        }
    }
    data->setProperty ("midi", juce::var (midiArr));

    // Envelope follower levels from C++ logic blocks
    {
        int numEnv = audioProcessor.numActiveEnvBlocks.load();
        if (numEnv > 0)
        {
            juce::Array<juce::var> envArr;
            for (int i = 0; i < numEnv && i < audioProcessor.maxEnvReadback; ++i)
            {
                auto* e = new juce::DynamicObject();
                e->setProperty ("id", audioProcessor.envReadback[i].blockId.load());
                e->setProperty ("level", (double) audioProcessor.envReadback[i].level.load());
                envArr.add (juce::var (e));
            }
            data->setProperty ("envLevels", juce::var (envArr));
        }
    }

    // Trigger fire events from C++ logic blocks
    {
        const auto tScope = audioProcessor.triggerFifo.read (audioProcessor.triggerFifo.getNumReady());
        if (tScope.blockSize1 > 0 || tScope.blockSize2 > 0)
        {
            juce::Array<juce::var> trigArr;
            for (int i = 0; i < tScope.blockSize1; ++i)
                trigArr.add (audioProcessor.triggerRing[tScope.startIndex1 + i]);
            for (int i = 0; i < tScope.blockSize2; ++i)
                trigArr.add (audioProcessor.triggerRing[tScope.startIndex2 + i]);
            data->setProperty ("trigFired", juce::var (trigArr));
        }
    }

    // Sample modulator playhead positions
    {
        int numSmp = audioProcessor.numActiveSampleBlocks.load();
        if (numSmp > 0)
        {
            juce::Array<juce::var> smpArr;
            for (int i = 0; i < numSmp && i < audioProcessor.maxSampleReadback; ++i)
            {
                auto* s = new juce::DynamicObject();
                s->setProperty ("id", audioProcessor.sampleReadback[i].blockId.load());
                s->setProperty ("pos", (double) audioProcessor.sampleReadback[i].playhead.load());
                smpArr.add (juce::var (s));
            }
            data->setProperty ("sampleHeads", juce::var (smpArr));
        }
    }

    // Morph pad playhead positions
    {
        int numMorph = audioProcessor.numActiveMorphBlocks.load();
        if (numMorph > 0)
        {
            juce::Array<juce::var> morphArr;
            for (int i = 0; i < numMorph && i < audioProcessor.maxMorphReadback; ++i)
            {
                auto* obj = new juce::DynamicObject();
                obj->setProperty ("id", audioProcessor.morphReadback[i].blockId.load());
                obj->setProperty ("x", (double) audioProcessor.morphReadback[i].headX.load());
                obj->setProperty ("y", (double) audioProcessor.morphReadback[i].headY.load());
                obj->setProperty ("rot", (double) audioProcessor.morphReadback[i].rotAngle.load());
                morphArr.add (juce::var (obj));
            }
            data->setProperty ("morphHeads", juce::var (morphArr));
        }
    }

    // Lane playhead positions
    {
        int numLanes = audioProcessor.numActiveLanes.load();
        if (numLanes > 0)
        {
            juce::Array<juce::var> laneArr;
            for (int i = 0; i < numLanes && i < audioProcessor.maxLaneReadback; ++i)
            {
                auto* obj = new juce::DynamicObject();
                obj->setProperty ("id", audioProcessor.laneReadback[i].blockId.load());
                obj->setProperty ("li", audioProcessor.laneReadback[i].laneIdx.load());
                obj->setProperty ("ph", (double) audioProcessor.laneReadback[i].playhead.load());
                obj->setProperty ("val", (double) audioProcessor.laneReadback[i].value.load());
                laneArr.add (juce::var (obj));
            }
            data->setProperty ("laneHeads", juce::var (laneArr));
        }
    }

    // ═══════════════════════════════════════════════════════════════
    // TWO-TIER PARAMETER POLLING
    // Modulated params (targeted by logic blocks): fast poll every tick (60Hz)
    // Idle params: slow poll every 15th tick (~4Hz)
    // This prevents 200+ param plugins like FabFilter Saturn from killing perf
    // ═══════════════════════════════════════════════════════════════
    {
        touchedParamId = {};

        // Drain self-write FIFO every tick (must keep up with audio thread)
        std::unordered_set<std::string> selfWritten;
        {
            const auto scope = audioProcessor.selfWriteFifo.read (
                audioProcessor.selfWriteFifo.getNumReady());
            for (int i = 0; i < scope.blockSize1; ++i)
            {
                auto& e = audioProcessor.selfWriteRing[scope.startIndex1 + i];
                selfWritten.insert (std::to_string (e.pluginId) + ":" + std::to_string (e.paramIndex));
            }
            for (int i = 0; i < scope.blockSize2; ++i)
            {
                auto& e = audioProcessor.selfWriteRing[scope.startIndex2 + i];
                selfWritten.insert (std::to_string (e.pluginId) + ":" + std::to_string (e.paramIndex));
            }
        }

        // Auto-promote self-written params to Tier 1 fast polling (60Hz)
        // — gives instant display text updates during knob drags
        for (const auto& key : selfWritten)
            recentlyChangedKeys[key] = 120; // 2 seconds at 60Hz

        // Refresh modulated param set periodically (every ~0.5s)
        if (timerTickCount % 30 == 0)
            modulatedParamKeys = audioProcessor.getModulatedParamKeys();

        juce::Array<juce::var> paramUpdates;
        float biggestDelta = 0.0f;

        // ── TIER 1: Modulated + recently-changed params — fast read every tick (60Hz) ──
        // Merge modulated and recently-changed keys for fast iteration
        auto tier1Keys = modulatedParamKeys; // copy
        for (auto& rc : recentlyChangedKeys)
            tier1Keys.insert (rc.first);

        if (!tier1Keys.empty())
        {
            for (const auto& key : tier1Keys)
            {
                auto idIt = paramIdentCache.find (key);
                if (idIt == paramIdentCache.end()) continue; // not yet cached by tier 2

                // Skip collapsed plugins — no point polling invisible params
                if (expandedPluginIds.count (idIt->second.pluginId) == 0) continue;

                float val = audioProcessor.getParamValueFast (idIt->second.pluginId, idIt->second.paramIndex);
                if (val < 0.0f) continue; // lock unavailable, skip

                auto lastIt = lastParamValues.find (key);
                bool changed = (lastIt == lastParamValues.end())
                            || (std::abs (val - lastIt->second) > 0.0005f);

                if (changed)
                {
                    auto* pObj = new juce::DynamicObject();
                    pObj->setProperty ("id", juce::String (key));
                    pObj->setProperty ("v", (double) val);
                    // Always send display text — plugin is source of truth
                    auto disp = audioProcessor.getParamDisplayTextFast (
                        idIt->second.pluginId, idIt->second.paramIndex);
                    pObj->setProperty ("disp", disp);
                    paramUpdates.add (juce::var (pObj));

                    // Keep recently-changed alive while still changing
                    if (modulatedParamKeys.count (key) == 0)
                        recentlyChangedKeys[key] = 120; // refresh TTL
                }

                // Modulated params NEVER trigger auto-locate
                // — they change constantly from logic blocks, not user interaction
                lastParamValues[key] = val;
            }
        }

        // Decrement TTLs on recently-changed keys, expire old ones
        for (auto it = recentlyChangedKeys.begin(); it != recentlyChangedKeys.end(); )
        {
            if (--(it->second) <= 0)
                it = recentlyChangedKeys.erase (it);
            else
                ++it;
        }

        // ── TIER 2: IDLE params — lock-free scan every 10th tick (~6Hz) ──
        // Uses getParamValueFast() + getParamDisplayTextFast() instead of getHostedParams()
        // to avoid pluginMutex contention and expensive getText() calls on unchanged params.
        if (timerTickCount % 10 == 0)
        {
            // Rebuild identity cache periodically (every 60 ticks = ~1s) to pick up new plugins
            bool rebuildCache = (timerTickCount % 60 == 0);
            if (rebuildCache)
            {
                // Use getHostedPluginList + getHostedParams ONLY for initial discovery
                auto pluginList = audioProcessor.getHostedPluginList();
                for (const auto& plugInfo : pluginList)
                {
                    auto params = audioProcessor.getHostedParams (plugInfo.id);
                    for (const auto& p : params)
                    {
                        auto paramId = juce::String (plugInfo.id) + ":" + juce::String (p.index);
                        auto key = paramId.toStdString();
                        paramIdentCache[key] = { plugInfo.id, p.index };
                    }
                }
            }

            // Fast scan through cached identities — lock-free!
            for (const auto& [key, ident] : paramIdentCache)
            {
                // Skip modulated params — Tier 1 handles them at 60Hz
                if (modulatedParamKeys.count (key) > 0)
                    continue;

                // Skip recently-changed keys — tier 1 handles them at 60Hz
                if (recentlyChangedKeys.count (key) > 0)
                    continue;

                // Skip collapsed plugins — no visible rows to update
                if (expandedPluginIds.count (ident.pluginId) == 0)
                    continue;

                float val = audioProcessor.getParamValueFast (ident.pluginId, ident.paramIndex);
                if (val < 0.0f) continue;

                auto lastIt = lastParamValues.find (key);
                bool changed = (lastIt == lastParamValues.end())
                            || (std::abs (val - lastIt->second) > 0.0005f);

                if (changed)
                {
                    auto* pObj = new juce::DynamicObject();
                    pObj->setProperty ("id", juce::String (key));
                    pObj->setProperty ("v", (double) val);
                    // Only call getText for params that actually changed — not all idle params
                    auto disp = audioProcessor.getParamDisplayTextFast (ident.pluginId, ident.paramIndex);
                    pObj->setProperty ("disp", disp);
                    paramUpdates.add (juce::var (pObj));

                    // Promote to fast poll — user is actively interacting
                    recentlyChangedKeys[key] = 120; // 2 seconds at 60Hz
                }

                // Auto-locate for idle params
                if (lastIt != lastParamValues.end() && selfWritten.count (key) == 0)
                {
                    float delta = std::abs (val - lastIt->second);
                    if (delta > 0.0005f && delta > biggestDelta)
                    {
                        biggestDelta = delta;
                        touchedParamId = juce::String (key);
                    }
                }
                lastParamValues[key] = val;
            }
        }

        if (paramUpdates.size() > 0)
            data->setProperty ("params", juce::var (paramUpdates));

        if (touchedParamId.isNotEmpty())
            data->setProperty ("touchedParam", touchedParamId);
    }

    // ── Proxy sync: read atomic cache from audio thread, apply on message thread ──
    audioProcessor.syncProxyCacheToHost();

    // Crash notifications from audio thread (lock-free FIFO read)
    {
        const auto cScope = audioProcessor.crashFifo.read (audioProcessor.crashFifo.getNumReady());
        for (int i = 0; i < cScope.blockSize1; ++i)
        {
            const auto& ce = audioProcessor.crashRing[cScope.startIndex1 + i];
            auto* cObj = new juce::DynamicObject();
            cObj->setProperty ("pluginId", ce.pluginId);
            cObj->setProperty ("pluginName", juce::String (ce.pluginName));
            cObj->setProperty ("reason", juce::String (ce.reason));
            webView->emitEventIfBrowserIsVisible ("__plugin_crashed__", juce::var (cObj));
        }
        for (int i = 0; i < cScope.blockSize2; ++i)
        {
            const auto& ce = audioProcessor.crashRing[cScope.startIndex2 + i];
            auto* cObj = new juce::DynamicObject();
            cObj->setProperty ("pluginId", ce.pluginId);
            cObj->setProperty ("pluginName", juce::String (ce.pluginName));
            cObj->setProperty ("reason", juce::String (ce.reason));
            webView->emitEventIfBrowserIsVisible ("__plugin_crashed__", juce::var (cObj));
        }
    }

    webView->emitEventIfBrowserIsVisible ("__rt_data__", juce::var (data));
}

std::optional<juce::WebBrowserComponent::Resource>
ModularRandomizerAudioProcessorEditor::getResource (const juce::String& url)
{
    const auto urlToRetrieve = url == "/" ? juce::String { "index.html" }
                                         : url.fromFirstOccurrenceOf ("/", false, false);

#if JUCE_DEBUG
    DBG ("Resource requested: " + url + " → resolved: " + urlToRetrieve);
#endif

    // Generic BinaryData lookup — iterate all registered resources
    for (int i = 0; i < BinaryData::namedResourceListSize; ++i)
    {
        const char* resourceName = BinaryData::namedResourceList[i];
        const char* originalFilename = BinaryData::getNamedResourceOriginalFilename (resourceName);

        if (originalFilename != nullptr && urlToRetrieve.endsWith (juce::String (originalFilename)))
        {
            int dataSize = 0;
            const char* data = BinaryData::getNamedResource (resourceName, dataSize);

            if (data != nullptr && dataSize > 0)
            {
                std::vector<std::byte> byteData (static_cast<size_t> (dataSize));
                std::memcpy (byteData.data(), data, static_cast<size_t> (dataSize));

                auto ext = urlToRetrieve.fromLastOccurrenceOf (".", false, false).toLowerCase();
                auto mime = getMimeForExtension (ext);

#if JUCE_DEBUG
                DBG ("Resource FOUND: " + urlToRetrieve + " (" + juce::String (dataSize) + " bytes, " + mime + ")");
#endif

                return juce::WebBrowserComponent::Resource { std::move (byteData), juce::String { mime } };
            }
        }
    }

#if JUCE_DEBUG
    DBG ("Resource NOT FOUND: " + urlToRetrieve);
#endif

    return std::nullopt;
}

const char* ModularRandomizerAudioProcessorEditor::getMimeForExtension (const juce::String& extension)
{
    static const std::unordered_map<juce::String, const char*> mimeMap =
    {
        { { "html" }, "text/html" },
        { { "css"  }, "text/css" },
        { { "js"   }, "text/javascript" },
        { { "json" }, "application/json" },
        { { "png"  }, "image/png" },
        { { "jpg"  }, "image/jpeg" },
        { { "svg"  }, "image/svg+xml" }
    };

    if (const auto it = mimeMap.find (extension.toLowerCase()); it != mimeMap.end())
        return it->second;

    return "text/plain";
}

void ModularRandomizerAudioProcessorEditor::openPluginEditorWindow (int pluginId)
{
    // Toggle: if already open, close it
    auto it = pluginEditorWindows.find (pluginId);
    if (it != pluginEditorWindows.end())
    {
        pluginEditorWindows.erase (it);
        return;
    }

    // Get the plugin instance
    auto* instance = audioProcessor.getHostedPluginInstance (pluginId);
    if (instance == nullptr)
    {
        DBG ("openPluginEditorWindow: plugin ID " + juce::String (pluginId) + " not found");
        return;
    }

    // Find the plugin name for the window title
    juce::String windowTitle = "Plugin Editor";
    auto pluginList = audioProcessor.getHostedPluginList();
    for (const auto& info : pluginList)
    {
        if (info.id == pluginId)
        {
            windowTitle = info.name;
            break;
        }
    }

    // Create the editor window
    pluginEditorWindows[pluginId] = std::make_unique<PluginEditorWindow> (
        windowTitle,
        instance,
        [this, pluginId]()
        {
            // Schedule removal to avoid deleting during callback
            juce::Component::SafePointer<ModularRandomizerAudioProcessorEditor> safeThis (this);
            juce::MessageManager::callAsync ([safeThis, pluginId]()
            {
                if (safeThis != nullptr)
                    safeThis->pluginEditorWindows.erase (pluginId);
            });
        }
    );
}
