﻿/*
  ==============================================================================

    PluginHosting.cpp
    VST3 plugin hosting: scan, load, remove, param access, proxy pool, glide API

  ==============================================================================
*/

#include "PluginProcessor.h"
//==============================================================================
// PLUGIN HOSTING API
//==============================================================================

std::vector<ScannedPlugin> ModularRandomizerAudioProcessor::scanForPlugins (
    const juce::StringArray& paths)
{
    std::vector<ScannedPlugin> results;
    juce::StringArray seen; // Track paths to avoid duplicates

    LOG_TO_FILE ("scanForPlugins: lightweight filesystem scan");

    for (const auto& scanDir : paths)
    {
        juce::File dir (scanDir);
        if (! dir.isDirectory())
        {
            LOG_TO_FILE ("  Skipping (not a directory): " << scanDir.toStdString());
            continue;
        }

        LOG_TO_FILE ("  Scanning directory: " << scanDir.toStdString());

        // Find all .vst3 items (files or bundle directories) recursively
        auto vst3Items = dir.findChildFiles (
            juce::File::findFilesAndDirectories, true, "*.vst3");

        for (const auto& item : vst3Items)
        {
            auto fullPath = item.getFullPathName();

            // Skip inner .vst3 inside a bundle's Contents directory
            if (fullPath.contains ("Contents"))
                continue;

            // Skip duplicates
            if (seen.contains (fullPath))
                continue;
            seen.add (fullPath);

            ScannedPlugin sp;
            sp.name = item.getFileNameWithoutExtension();
            sp.path = fullPath;
            sp.format = "VST3";
            sp.category = "fx"; // Default â€” we don't know until loaded
            sp.vendor = item.getParentDirectory().getFileName(); // Use parent folder as vendor hint

            // If the parent is the root scan dir, vendor is unknown
            if (sp.vendor == dir.getFileName())
                sp.vendor = "";

            results.push_back (sp);
        }
    }

    LOG_TO_FILE ("scanForPlugins complete: " << results.size() << " plugins found");
    return results;
}

int ModularRandomizerAudioProcessor::loadPlugin (const juce::String& pluginPath)
{
    LOG_TO_FILE ("loadPlugin: " << pluginPath.toStdString());

    // First check if we already know this plugin
    juce::PluginDescription desc;
    bool found = false;

    auto pluginFileName = juce::File (pluginPath).getFileNameWithoutExtension();

    for (const auto& d : knownPlugins.getTypes())
    {
        if (d.fileOrIdentifier == pluginPath || d.name == pluginPath
            || d.fileOrIdentifier.containsIgnoreCase (pluginFileName))
        {
            desc = d;
            found = true;
            break;
        }
    }

    // If not known yet, scan just this one file to get its description
    if (! found)
    {
        LOG_TO_FILE ("  Plugin not in known list, scanning single file...");

        for (int fi = 0; fi < formatManager.getNumFormats(); ++fi)
        {
            auto* format = formatManager.getFormat (fi);

            // Create a search path containing just the parent directory
            juce::File pluginFile (pluginPath);
            juce::FileSearchPath singlePath (pluginFile.getParentDirectory().getFullPathName());

            juce::PluginDirectoryScanner scanner (
                knownPlugins, *format, singlePath,
                false, // not recursive
                juce::File()
            );

            juce::String name;
            while (scanner.scanNextFile (true, name))
            {
                LOG_TO_FILE ("  Single-file scan: " << name.toStdString());
            }

            // Check if our target was found
            // VST3 fileOrIdentifier may differ from the bundle path
            for (const auto& d : knownPlugins.getTypes())
            {
                LOG_TO_FILE ("    Known: " << d.fileOrIdentifier.toStdString() << " name=" << d.name.toStdString());

                // Try exact match first
                if (d.fileOrIdentifier == pluginPath)
                {
                    desc = d;
                    found = true;
                    break;
                }
                // Try if fileOrIdentifier contains our path or vice versa
                if (d.fileOrIdentifier.containsIgnoreCase (pluginPath)
                    || pluginPath.containsIgnoreCase (d.fileOrIdentifier))
                {
                    desc = d;
                    found = true;
                    break;
                }
                // Try matching by plugin name (filename stem)
                if (d.fileOrIdentifier.containsIgnoreCase (pluginFileName))
                {
                    desc = d;
                    found = true;
                    break;
                }
            }

            if (found)
            {
                LOG_TO_FILE ("  Matched: " << desc.name.toStdString() << " via " << desc.fileOrIdentifier.toStdString());
                break;
            }
        }
    }

    if (! found)
    {
        LOG_TO_FILE ("  FAILED: Plugin description not found after scan");
        return -1;
    }

    // Load the plugin instance (crash-protected)
    juce::String errorMessage;
    std::unique_ptr<juce::AudioPluginInstance> instance;

    try
    {
        instance = formatManager.createPluginInstance (
            desc, currentSampleRate, currentBlockSize, errorMessage);
    }
    catch (...)
    {
        LOG_TO_FILE ("  CRASH during createPluginInstance for: " << desc.name.toStdString());
        return -1;
    }

    if (instance == nullptr)
    {
        LOG_TO_FILE ("  FAILED to create instance: " << errorMessage.toStdString());
        return -1;
    }

    // Configure the hosted plugin's bus layout to match our stereo I/O.
    // Without this, the plugin doesn't know our channel configuration and
    // processBlock will operate with mismatched channels → crackles/artifacts.
    try
    {
        // Try to set a stereo-in/stereo-out layout on the hosted plugin
        juce::AudioProcessor::BusesLayout stereoLayout;
        stereoLayout.inputBuses.add  (juce::AudioChannelSet::stereo());
        stereoLayout.outputBuses.add (juce::AudioChannelSet::stereo());

        if (! instance->setBusesLayout (stereoLayout))
        {
            // Plugin rejected our preferred layout — try mono fallback
            juce::AudioProcessor::BusesLayout monoLayout;
            monoLayout.inputBuses.add  (juce::AudioChannelSet::mono());
            monoLayout.outputBuses.add (juce::AudioChannelSet::mono());

            if (! instance->setBusesLayout (monoLayout))
            {
                // Use whatever the plugin defaults to, but make sure
                // channel counts are communicated via setPlayConfigDetails
                LOG_TO_FILE ("  Plugin rejected stereo and mono layouts, using default");
            }
        }

        // Tell the plugin instance exactly how many channels and what rate/blocksize
        int pluginIns  = instance->getTotalNumInputChannels();
        int pluginOuts = instance->getTotalNumOutputChannels();
        instance->setPlayConfigDetails (pluginIns, pluginOuts,
                                         currentSampleRate, currentBlockSize);

        LOG_TO_FILE ("  Configured plugin: " << pluginIns << " in, "
                     << pluginOuts << " out, "
                     << currentSampleRate << " Hz, "
                     << currentBlockSize << " samples");
    }
    catch (...)
    {
        LOG_TO_FILE ("  WARNING: exception during bus layout configuration");
    }

    // Prepare the instance (crash-protected)
    try
    {
        instance->prepareToPlay (currentSampleRate, currentBlockSize);
    }
    catch (...)
    {
        LOG_TO_FILE ("  CRASH during prepareToPlay for: " << desc.name.toStdString());
        return -1;
    }

    // Create hosted plugin entry
    auto hp = std::make_unique<HostedPlugin>();
    hp->id = ++nextPluginId;
    hp->name = desc.name;
    hp->path = desc.fileOrIdentifier;
    hp->description = desc;
    hp->instance = std::move (instance);
    hp->prepared = true;

    int id = hp->id;
    int paramCount = (int) hp->instance->getParameters().size();

    {
        std::lock_guard<std::mutex> lock (pluginMutex);
        hostedPlugins.push_back (std::move (hp));
        rebuildPluginSlots();
    }

    LOG_TO_FILE ("  Loaded plugin: " << desc.name.toStdString()
                 << " (ID: " << id << ", Params: " << paramCount << ")");

    // Assign proxy parameter slots for DAW automation
    assignProxySlotsForPlugin (id);

    return id;
}

void ModularRandomizerAudioProcessor::removePlugin (int pluginId)
{
    // This function must ALWAYS succeed — no exceptions, no crashes.
    try
    {
        // 1. Free proxy slots (safe, no mutex needed for proxy array)
        try { freeProxySlotsForPlugin (pluginId); } catch (...) {}

        // 2. Null the instance — audio thread will see nullptr and skip.
        //    Do NOT erase from the vector (audio thread may be iterating it).
        std::unique_ptr<juce::AudioPluginInstance> instanceToDestroy;
        {
            std::lock_guard<std::mutex> lock (pluginMutex);
            for (auto& hp : hostedPlugins)
            {
                if (hp->id == pluginId)
                {
                    // Take ownership — audio thread sees nullptr → skips
                    instanceToDestroy = std::move (hp->instance);
                    hp->prepared = false;
                    hp->crashed = true;
                    hp->id = -1; // tombstone marker
                    break;
                }
            }
            rebuildPluginSlots();

            // 3. Mark any active glides targeting this plugin as expired.
            // The audio thread owns glidePool — we don't erase from here.
            // Setting samplesLeft=0 causes the audio thread to remove them.
            for (int gi = 0; gi < numActiveGlides; ++gi)
            {
                if (glidePool[gi].pluginId == pluginId)
                    glidePool[gi].samplesLeft = 0;
            }
        }

        // 4. Release resources OUTSIDE the mutex (some plugins do blocking I/O)
        if (instanceToDestroy)
        {
            try { instanceToDestroy->releaseResources(); } catch (...) {}
            // instanceToDestroy destroyed here
        }

        DBG ("Removed plugin ID: " + juce::String (pluginId));
    }
    catch (...)
    {
        DBG ("removePlugin: exception caught and swallowed for plugin ID " + juce::String (pluginId));
    }
}

// Garbage-collect dead plugin entries (id == -1). Call from message thread only.
void ModularRandomizerAudioProcessor::purgeDeadPlugins()
{
    std::lock_guard<std::mutex> lock (pluginMutex);
    hostedPlugins.erase (
        std::remove_if (hostedPlugins.begin(), hostedPlugins.end(),
            [] (const std::unique_ptr<HostedPlugin>& hp) { return hp->id < 0; }),
        hostedPlugins.end());
    rebuildPluginSlots();
}

void ModularRandomizerAudioProcessor::reorderPlugins (const std::vector<int>& orderedIds)
{
    std::lock_guard<std::mutex> lock (pluginMutex);

    // In-place reorder using swaps — the vector's size and allocation never change,
    // so the audio thread's iteration remains safe (no iterator invalidation).
    for (size_t targetPos = 0; targetPos < orderedIds.size() && targetPos < hostedPlugins.size(); ++targetPos)
    {
        int wantedId = orderedIds[targetPos];

        // Find which position currently holds the wanted ID
        size_t foundPos = targetPos;
        for (size_t j = targetPos; j < hostedPlugins.size(); ++j)
        {
            if (hostedPlugins[j] && hostedPlugins[j]->id == wantedId)
            {
                foundPos = j;
                break;
            }
        }

        // Swap into correct position (std::swap on unique_ptr is just pointer swap)
        if (foundPos != targetPos)
            std::swap (hostedPlugins[targetPos], hostedPlugins[foundPos]);
    }
    rebuildPluginSlots();
}

std::vector<ModularRandomizerAudioProcessor::ParamInfo>
ModularRandomizerAudioProcessor::getHostedParams (int pluginId)
{
    std::vector<ParamInfo> result;
    std::lock_guard<std::mutex> lock (pluginMutex);

    for (auto& hp : hostedPlugins)
    {
        if (hp->id == pluginId && hp->instance != nullptr)
        {
            auto& params = hp->instance->getParameters();
            for (int i = 0; i < params.size(); ++i)
            {
                auto* p = params[i];

                // Skip non-automatable parameters
                if (! p->isAutomatable())
                    continue;

                // Skip VST3 internal MIDI CC / Aftertouch / Pitchbend parameters
                auto name = p->getName (64);
                if (name.startsWith ("MIDI CC")
                    || name.startsWith ("Aftertouch")
                    || name.startsWith ("Pitchbend"))
                    continue;

                ParamInfo info;
                info.index = i;
                info.name = name;
                info.value = p->getValue(); // normalised 0-1
                info.label = p->getLabel();
                info.displayText = p->getText (p->getValue(), 32);
                info.automatable = true;
                result.push_back (info);
            }
            break;
        }
    }
    return result;
}

void ModularRandomizerAudioProcessor::setHostedParam (int pluginId, int paramIndex, float normValue)
{
    // O(1) lookup via pluginSlots — no linear scan needed
    int slot = slotForId (pluginId);
    if (slot >= 0)
    {
        auto* hp = pluginSlots[slot];
        if (hp && hp->id == pluginId && hp->instance != nullptr)
        {
            auto& params = hp->instance->getParameters();
            if (paramIndex >= 0 && paramIndex < params.size())
            {
                params[paramIndex]->setValue (normValue);
                recordSelfWrite (pluginId, paramIndex);
            }
        }
    }
}

void ModularRandomizerAudioProcessor::startGlide (int pluginId, int paramIndex,
                                                    float targetValue, float durationMs)
{
    // Write to lock-free FIFO â€” safe to call from message thread
    GlideCommand cmd { pluginId, paramIndex, targetValue, durationMs };
    const auto scope = glideFifo.write (1);
    if (scope.blockSize1 > 0)
        glideRing[scope.startIndex1] = cmd;
    else if (scope.blockSize2 > 0)
        glideRing[scope.startIndex2] = cmd;
    // If FIFO is full, command is silently dropped (very unlikely with 512 slots)
}

//==============================================================================
// Proxy Parameter Pool â€” DAW automation bridge
//==============================================================================

void ModularRandomizerAudioProcessor::assignProxySlotsForPlugin (int pluginId)
{
    std::lock_guard<std::mutex> lock (pluginMutex);

    // Find the hosted plugin and assign proxy slots for each of its params
    HostedPlugin* target = nullptr;
    for (auto& hp : hostedPlugins)
    {
        if (hp->id == pluginId)
        {
            target = hp.get();
            break;
        }
    }
    if (target == nullptr || target->instance == nullptr) return;

    auto& hostedParams = target->instance->getParameters();
    int slot = 0;

    for (int pi = 0; pi < (int) hostedParams.size(); ++pi)
    {
        // Find next free proxy slot
        while (slot < proxyParamCount && proxyMap[slot].pluginId >= 0)
            ++slot;
        if (slot >= proxyParamCount) break; // pool exhausted

        proxyMap[slot].pluginId   = pluginId;
        proxyMap[slot].paramIndex = pi;

        // Set proxy value to match hosted param (suppress feedback)
        if (proxyParams[slot] != nullptr)
        {
            // Set dynamic name: "PluginName: ParamName"
            auto paramName = hostedParams[pi]->getName (128);
            proxyParams[slot]->setDynamicName (target->name + ": " + paramName);

            proxySyncActive.store (true);
            proxyParams[slot]->setValueNotifyingHost (hostedParams[pi]->getValue());
            proxySyncActive.store (false);
        }
        ++slot;
    }

    // Notify host that parameter info changed (name/value updates)
    updateHostDisplay (juce::AudioProcessor::ChangeDetails{}.withParameterInfoChanged (true));
}

void ModularRandomizerAudioProcessor::freeProxySlotsForPlugin (int pluginId)
{
    for (int i = 0; i < proxyParamCount; ++i)
    {
        if (proxyMap[i].pluginId == pluginId)
        {
            proxyMap[i].pluginId   = -1;
            proxyMap[i].paramIndex = -1;

            // Reset proxy value and name
            if (proxyParams[i] != nullptr)
            {
                proxyParams[i]->setDynamicName (juce::String ("Slot ") + juce::String (i + 1));
                proxySyncActive.store (true);
                proxyParams[i]->setValueNotifyingHost (0.0f);
                proxySyncActive.store (false);
            }
        }
    }

    updateHostDisplay (juce::AudioProcessor::ChangeDetails{}.withParameterInfoChanged (true));
}

void ModularRandomizerAudioProcessor::parameterChanged (const juce::String& parameterID, float newValue)
{
    // Ignore sync-back writes (processBlock â†’ proxy)
    if (proxySyncActive.load()) return;

    // Only handle proxy params (HP_NNN)
    if (! parameterID.startsWith ("HP_")) return;

    int slot = parameterID.substring (3).getIntValue();
    if (slot < 0 || slot >= proxyParamCount) return;

    auto& m = proxyMap[slot];
    if (m.pluginId < 0) return;

    // Forward to hosted plugin
    std::lock_guard<std::mutex> lock (pluginMutex);
    for (auto& hp : hostedPlugins)
    {
        if (hp->id == m.pluginId && hp->instance != nullptr)
        {
            auto& params = hp->instance->getParameters();
            if (m.paramIndex >= 0 && m.paramIndex < (int) params.size())
            {
                params[m.paramIndex]->setValue (newValue);
                recordSelfWrite (m.pluginId, m.paramIndex);
            }
            break;
        }
    }
}
