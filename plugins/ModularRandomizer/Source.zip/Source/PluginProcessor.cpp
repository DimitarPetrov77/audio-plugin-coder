﻿/*
  ==============================================================================

    Modular Randomizer - PluginProcessor
    VST3 Plugin Hosting Engine with parameter randomization

  ==============================================================================
*/

#include "PluginProcessor.h"
#include "PluginEditor.h"
#include "ParameterIDs.hpp"

//==============================================================================
// Enum parsers — called once per updateLogicBlocks (message thread), so processBlock
// uses integer comparisons instead of ~100 juce::String == "literal" per call (H4 fix).
//==============================================================================
using P = ModularRandomizerAudioProcessor;

P::BlockMode P::parseBlockMode (const juce::String& s) {
    if (s == "randomize")    return BlockMode::Randomize;
    if (s == "envelope")     return BlockMode::Envelope;
    if (s == "sample")       return BlockMode::Sample;
    if (s == "morph_pad")    return BlockMode::MorphPad;
    if (s == "shapes")       return BlockMode::Shapes;
    if (s == "shapes_range") return BlockMode::ShapesRange;
    if (s == "lane")         return BlockMode::Lane;
    return BlockMode::Unknown;
}
P::TriggerType P::parseTriggerType (const juce::String& s) {
    if (s == "tempo") return TriggerType::Tempo;
    if (s == "midi")  return TriggerType::Midi;
    if (s == "audio") return TriggerType::Audio;
    return TriggerType::Manual;
}
P::MidiTrigMode P::parseMidiTrigMode (const juce::String& s) {
    if (s == "specific_note") return MidiTrigMode::SpecificNote;
    if (s == "cc")            return MidiTrigMode::CC;
    return MidiTrigMode::AnyNote;
}
P::AudioSource P::parseAudioSource (const juce::String& s) {
    if (s == "sidechain") return AudioSource::Sidechain;
    return AudioSource::Main;
}
P::RangeMode P::parseRangeMode (const juce::String& s) {
    if (s == "relative") return RangeMode::Relative;
    return RangeMode::Absolute;
}
P::Movement P::parseMovement (const juce::String& s) {
    if (s == "glide") return Movement::Glide;
    return Movement::Instant;
}
P::Polarity P::parsePolarity (const juce::String& s) {
    if (s == "up")       return Polarity::Up;
    if (s == "down")     return Polarity::Down;
    if (s == "unipolar") return Polarity::Unipolar;
    return Polarity::Bipolar;
}
P::ClockSource P::parseClockSource (const juce::String& s) {
    if (s == "internal") return ClockSource::Internal;
    return ClockSource::Daw;
}
P::LoopMode P::parseLoopMode (const juce::String& s) {
    if (s == "loop")     return LoopMode::Loop;
    if (s == "pingpong") return LoopMode::Pingpong;
    return LoopMode::Oneshot;
}
P::JumpMode P::parseJumpMode (const juce::String& s) {
    if (s == "random") return JumpMode::Random;
    return JumpMode::Restart;
}
P::MorphMode P::parseMorphMode (const juce::String& s) {
    if (s == "auto")    return MorphMode::Auto;
    if (s == "trigger") return MorphMode::Trigger;
    return MorphMode::Manual;
}
P::ExploreMode P::parseExploreMode (const juce::String& s) {
    if (s == "bounce") return ExploreMode::Bounce;
    if (s == "shapes") return ExploreMode::Shapes;
    if (s == "orbit")  return ExploreMode::Orbit;
    if (s == "path")   return ExploreMode::Path;
    return ExploreMode::Wander;
}
P::LfoShape P::parseLfoShape (const juce::String& s) {
    if (s == "figure8")    return LfoShape::Figure8;
    if (s == "sweepX")     return LfoShape::SweepX;
    if (s == "sweepY")     return LfoShape::SweepY;
    if (s == "triangle")   return LfoShape::Triangle;
    if (s == "square")     return LfoShape::Square;
    if (s == "hexagon")    return LfoShape::Hexagon;
    if (s == "pentagram")  return LfoShape::Pentagram;
    if (s == "hexagram")   return LfoShape::Hexagram;
    if (s == "rose4")      return LfoShape::Rose4;
    if (s == "lissajous")  return LfoShape::Lissajous;
    if (s == "spiral")     return LfoShape::Spiral;
    return LfoShape::Circle;
}
P::MorphAction P::parseMorphAction (const juce::String& s) {
    if (s == "step") return MorphAction::Step;
    return MorphAction::Jump;
}
P::StepOrder P::parseStepOrder (const juce::String& s) {
    if (s == "random") return StepOrder::Random;
    return StepOrder::Cycle;
}
P::ShapeTracking P::parseShapeTracking (const juce::String& s) {
    if (s == "vertical") return ShapeTracking::Vertical;
    if (s == "distance") return ShapeTracking::Distance;
    return ShapeTracking::Horizontal;
}
P::ShapeTrigger P::parseShapeTrigger (const juce::String& s) {
    if (s == "midi") return ShapeTrigger::Midi;
    return ShapeTrigger::Free;
}
P::LaneInterp P::parseLaneInterp (const juce::String& s) {
    if (s == "step")   return LaneInterp::Step;
    if (s == "linear") return LaneInterp::Linear;
    return LaneInterp::Smooth;
}
P::LanePlayMode P::parseLanePlayMode (const juce::String& s) {
    if (s == "reverse")  return LanePlayMode::Reverse;
    if (s == "pingpong") return LanePlayMode::Pingpong;
    if (s == "random")   return LanePlayMode::Random;
    return LanePlayMode::Forward;
}
float P::parseBeatsPerDiv (const juce::String& div) {
    if (div == "8"   || div == "8/1")  return 32.0f;
    if (div == "4"   || div == "4/1")  return 16.0f;
    if (div == "2"   || div == "2/1")  return 8.0f;
    if (div == "1/1")  return 4.0f;
    if (div == "1/2")  return 2.0f;
    if (div == "1/4")  return 1.0f;
    if (div == "1/8")  return 0.5f;
    if (div == "1/16") return 0.25f;
    if (div == "1/32") return 0.125f;
    if (div == "1/64") return 0.0625f;
    if (div == "1/2.")  return 3.0f;
    if (div == "1/4.")  return 1.5f;
    if (div == "1/8.")  return 0.75f;
    if (div == "1/16.") return 0.375f;
    if (div == "1/2T")  return 4.0f / 3.0f;
    if (div == "1/4T")  return 2.0f / 3.0f;
    if (div == "1/8T")  return 1.0f / 3.0f;
    if (div == "1/16T") return 0.5f / 3.0f;
    return 1.0f;
}

//==============================================================================
ModularRandomizerAudioProcessor::ModularRandomizerAudioProcessor()
#ifndef JucePlugin_PreferredChannelConfigurations
     : AudioProcessor (BusesProperties()
                     #if ! JucePlugin_IsMidiEffect
                      #if ! JucePlugin_IsSynth
                       .withInput  ("Input",  juce::AudioChannelSet::stereo(), true)
                      #endif
                       .withOutput ("Output", juce::AudioChannelSet::stereo(), true)
                     #endif
                       .withInput  ("Sidechain", juce::AudioChannelSet::stereo(), false)
                       ),
#else
     :
#endif
       apvts (*this, nullptr, "ModularRandomizer", createParameterLayout())
{
    // Register VST3 format for plugin scanning/hosting
    formatManager.addFormat (new juce::VST3PluginFormat());

    // Register audio file formats for sample modulator
    audioFileFormatManager.registerBasicFormats();

    // Initialize flat param tracking arrays (zero heap allocations on audio thread)
    for (int s = 0; s < kMaxPlugins; ++s)
        for (int p = 0; p < kMaxParams; ++p)
        {
            paramWritten[s][p] = -1.0f;  // sentinel: never written
            paramTouched[s][p].store (false, std::memory_order_relaxed);
        }

    // Pre-allocate hosted plugin vector so push_back never reallocates
    // while the audio thread iterates (audio thread doesn't hold pluginMutex)
    hostedPlugins.reserve (32);

    // Look up proxy raw pointers from APVTS
    for (int i = 0; i < proxyParamCount; ++i)
    {
        auto id = juce::String ("HP_") + juce::String (i).paddedLeft ('0', 3);
        proxyParams[i] = dynamic_cast<ProxyParameter*> (apvts.getParameter (id));
        apvts.addParameterListener (id, this);
    }
}


ModularRandomizerAudioProcessor::~ModularRandomizerAudioProcessor()
{
    // Unregister proxy listeners
    for (int i = 0; i < proxyParamCount; ++i)
    {
        auto id = juce::String ("HP_") + juce::String (i).paddedLeft ('0', 3);
        apvts.removeParameterListener (id, this);
    }

    // Release all hosted plugins
    std::lock_guard<std::mutex> lock (pluginMutex);
    hostedPlugins.clear();
}

//==============================================================================
juce::AudioProcessorValueTreeState::ParameterLayout ModularRandomizerAudioProcessor::createParameterLayout()
{
    std::vector<std::unique_ptr<juce::RangedAudioParameter>> params;

    params.push_back (std::make_unique<juce::AudioParameterFloat> (
        juce::ParameterID { ParameterIDs::MIX, 1 },
        "Mix",
        juce::NormalisableRange<float> (0.0f, 100.0f, 0.1f),
        100.0f,
        juce::String(),
        juce::AudioProcessorParameter::genericParameter,
        [](float value, int) { return juce::String (value, 0) + "%"; }
    ));

    params.push_back (std::make_unique<juce::AudioParameterBool> (
        juce::ParameterID { ParameterIDs::BYPASS, 1 },
        "Bypass",
        false
    ));

    // Proxy parameter pool â€” 256 slots for hosted plugin params exposed to DAW
    for (int i = 0; i < proxyParamCount; ++i)
    {
        auto id = juce::String ("HP_") + juce::String (i).paddedLeft ('0', 3);
        auto name = juce::String ("Slot ") + juce::String (i + 1);
        params.push_back (std::make_unique<ProxyParameter> (
            juce::ParameterID { id, 1 },
            name,
            juce::NormalisableRange<float> (0.0f, 1.0f, 0.0f),
            0.0f
        ));
    }

    return { params.begin(), params.end() };
}

//==============================================================================
void ModularRandomizerAudioProcessor::prepareToPlay (double sampleRate, int samplesPerBlock)
{
    currentSampleRate = sampleRate;
    currentBlockSize = samplesPerBlock;

    // Reset glide pool (fixed-size array, no allocation needed)
    numActiveGlides = 0;

    // Pre-allocate parallel bus buffers (sized for max channels + block size)
    int numCh = getTotalNumOutputChannels();
    for (int i = 0; i < maxBuses; ++i)
        busBuffers[i].setSize (numCh, samplesPerBlock, false, false, true);

    // Pre-allocate dry buffer for wet/dry mix (avoids heap alloc in processBlock)
    dryBuffer.setSize (numCh, samplesPerBlock, false, false, true);

    // Pre-allocate MIDI trigger event buffer
    blockMidiEvents.reserve (kMaxBlockMidi);

    // Initialize proxy value cache sentinels (-999.0f = no pending update)
    for (int i = 0; i < proxyParamCount; ++i)
        proxyValueCache[i].store (-999.0f, std::memory_order_relaxed);
    proxyDirty.store (false);

    // Purge dead plugin entries (safe: processBlock is not running during prepareToPlay)
    purgeDeadPlugins();

    // Prepare all hosted plugins (reconfigure on rate/blocksize change)
    std::lock_guard<std::mutex> lock (pluginMutex);
    for (auto& hp : hostedPlugins)
    {
        if (hp->instance != nullptr)
        {
            // Always reconfigure — sample rate or block size may have changed
            int pluginIns  = hp->instance->getTotalNumInputChannels();
            int pluginOuts = hp->instance->getTotalNumOutputChannels();
            hp->instance->setPlayConfigDetails (pluginIns, pluginOuts,
                                                 sampleRate, samplesPerBlock);
            hp->instance->prepareToPlay (sampleRate, samplesPerBlock);
            hp->prepared = true;
        }
    }
}

void ModularRandomizerAudioProcessor::syncProxyCacheToHost()
{
    // Drain proxy value cache from audio thread → call setValueNotifyingHost on message thread.
    // Audio thread writes float values into proxyValueCache atomics; this method reads them.
    if (! proxyDirty.exchange (false, std::memory_order_acquire))
        return;

    proxySyncActive.store (true);
    for (int i = 0; i < proxyParamCount; ++i)
    {
        float cached = proxyValueCache[i].exchange (-999.0f, std::memory_order_relaxed);
        if (cached > -998.0f && proxyParams[i] != nullptr)
        {
            if (std::abs (cached - proxyParams[i]->get()) > 0.0001f)
                proxyParams[i]->setValueNotifyingHost (cached);
        }
    }
    proxySyncActive.store (false);
}

void ModularRandomizerAudioProcessor::releaseResources()
{
    std::lock_guard<std::mutex> lock (pluginMutex);
    for (auto& hp : hostedPlugins)
    {
        if (hp->instance != nullptr && hp->prepared)
        {
            hp->instance->releaseResources();
            hp->prepared = false;
        }
    }
}

#ifndef JucePlugin_PreferredChannelConfigurations
bool ModularRandomizerAudioProcessor::isBusesLayoutSupported (const BusesLayout& layouts) const
{
  #if JucePlugin_IsMidiEffect
    juce::ignoreUnused (layouts);
    return true;
  #else
    if (layouts.getMainOutputChannelSet() != juce::AudioChannelSet::mono()
     && layouts.getMainOutputChannelSet() != juce::AudioChannelSet::stereo())
        return false;

   #if ! JucePlugin_IsSynth
    if (layouts.getMainOutputChannelSet() != layouts.getMainInputChannelSet())
        return false;
   #endif

    // Sidechain: accept disabled, mono, or stereo
    auto scLayout = layouts.getChannelSet (true, 1);
    if (! scLayout.isDisabled()
        && scLayout != juce::AudioChannelSet::mono()
        && scLayout != juce::AudioChannelSet::stereo())
        return false;

    return true;
  #endif
}
#endif




void ModularRandomizerAudioProcessor::updateLogicBlocks (const juce::String& jsonData)
{
    auto parsed = juce::JSON::parse (jsonData);
    if (! parsed.isArray()) return;

    std::vector<LogicBlock> newBlocks;
    newBlocks.reserve ((size_t) parsed.size());

    for (int i = 0; i < parsed.size(); ++i)
    {
        auto* obj = parsed[i].getDynamicObject();
        if (obj == nullptr) continue;

        LogicBlock lb;
        lb.id       = (int) obj->getProperty ("id");
        lb.mode     = obj->getProperty ("mode").toString();
        lb.enabled  = obj->hasProperty ("enabled") ? (bool) obj->getProperty ("enabled") : true;
        lb.trigger  = obj->getProperty ("trigger").toString();
        lb.beatDiv  = obj->getProperty ("beatDiv").toString();
        lb.midiMode = obj->getProperty ("midiMode").toString();
        lb.midiNote = (int) obj->getProperty ("midiNote");
        lb.midiCC   = (int) obj->getProperty ("midiCC");
        lb.midiCh   = (int) obj->getProperty ("midiCh");
        lb.threshold = (float) (double) obj->getProperty ("threshold");
        lb.audioSrc  = obj->getProperty ("audioSrc").toString();
        lb.rMin      = (float) (double) obj->getProperty ("rMin");
        lb.rMax      = (float) (double) obj->getProperty ("rMax");
        lb.rangeMode = obj->getProperty ("rangeMode").toString();
        lb.quantize  = (bool) obj->getProperty ("quantize");
        lb.qSteps    = (int) obj->getProperty ("qSteps");
        lb.movement  = obj->getProperty ("movement").toString();
        lb.glideMs   = (float) (double) obj->getProperty ("glideMs");
        lb.envAtk    = (float) (double) obj->getProperty ("envAtk");
        lb.envRel    = (float) (double) obj->getProperty ("envRel");
        lb.envSens   = (float) (double) obj->getProperty ("envSens");
        lb.envInvert = (bool) obj->getProperty ("envInvert");

        // Polarity control (relative mode: bipolar, up, down)
        lb.polarity  = obj->getProperty ("polarity").toString();
        if (lb.polarity.isEmpty()) lb.polarity = "bipolar";

        // Clock source: "daw" or "internal"
        lb.clockSource  = obj->getProperty ("clockSource").toString();
        if (lb.clockSource.isEmpty()) lb.clockSource = "daw";
        lb.internalBpm  = (float) (double) obj->getProperty ("internalBpm");
        if (lb.internalBpm <= 0.0f) lb.internalBpm = 120.0f;

        // Sample modulator settings
        lb.loopMode      = obj->getProperty ("loopMode").toString();
        lb.sampleSpeed   = (float) (double) obj->getProperty ("sampleSpeed");
        lb.sampleReverse = (bool) obj->getProperty ("sampleReverse");
        lb.jumpMode      = obj->getProperty ("jumpMode").toString();

        // Defaults for missing values
        if (lb.loopMode.isEmpty()) lb.loopMode = "loop";
        if (lb.sampleSpeed <= 0.0f) lb.sampleSpeed = 1.0f;
        if (lb.jumpMode.isEmpty()) lb.jumpMode = "restart";

        // Morph Pad settings
        lb.morphMode    = obj->getProperty("morphMode").toString();
        lb.exploreMode  = obj->getProperty("exploreMode").toString();
        lb.lfoShape     = obj->getProperty("lfoShape").toString();
        lb.lfoDepth     = obj->hasProperty("lfoDepth") ? (float)(double) obj->getProperty("lfoDepth") : 0.8f;
        lb.lfoRotation  = obj->hasProperty("lfoRotation") ? (float)(double) obj->getProperty("lfoRotation") : 0.0f;
        lb.morphSpeed   = (float)(double) obj->getProperty("morphSpeed");
        lb.morphAction  = obj->getProperty("morphAction").toString();
        lb.stepOrder    = obj->getProperty("stepOrder").toString();
        lb.morphSource  = obj->getProperty("morphSource").toString();
        lb.playheadX    = (float)(double) obj->getProperty("playheadX");
        lb.playheadY    = (float)(double) obj->getProperty("playheadY");
        // Circular clamp â€” ensure playhead is inside the pad (r=0.45)
        { float pdx = lb.playheadX - 0.5f, pdy = lb.playheadY - 0.5f;
          float pd = std::sqrt (pdx * pdx + pdy * pdy);
          if (pd > 0.45f) { float ps = 0.45f / pd; lb.playheadX = 0.5f + pdx * ps; lb.playheadY = 0.5f + pdy * ps; } }
        lb.jitter       = (float)(double) obj->getProperty("jitter");
        lb.morphGlide   = (float)(double) obj->getProperty("morphGlide");
        lb.morphTempoSync = (bool) obj->getProperty("morphTempoSync");
        lb.morphSyncDiv   = obj->getProperty("morphSyncDiv").toString();
        lb.snapRadius     = (float)(double) obj->getProperty("snapRadius");

        // Defaults
        if (lb.morphMode.isEmpty())   lb.morphMode = "manual";
        if (lb.exploreMode.isEmpty()) lb.exploreMode = "wander";
        if (lb.exploreMode == "lfo")  lb.exploreMode = "shapes"; // backward compat
        if (lb.lfoShape.isEmpty())    lb.lfoShape = "circle";
        if (lb.morphAction.isEmpty()) lb.morphAction = "jump";
        if (lb.stepOrder.isEmpty())   lb.stepOrder = "cycle";
        if (lb.morphSource.isEmpty()) lb.morphSource = "midi";
        if (lb.morphGlide <= 0.0f)    lb.morphGlide = 200.0f;
        if (lb.morphSyncDiv.isEmpty()) lb.morphSyncDiv = "1/4";
        if (lb.snapRadius <= 0.0f)    lb.snapRadius = 1.0f;

        // â”€â”€ Shapes Block fields â”€â”€
        lb.shapeType      = obj->getProperty("shapeType").toString();
        lb.shapeTracking  = obj->getProperty("shapeTracking").toString();
        lb.shapeSize      = (float)(double) obj->getProperty("shapeSize");
        lb.shapeSpin      = (float)(double) obj->getProperty("shapeSpin");
        lb.shapeSpeed     = (float)(double) obj->getProperty("shapeSpeed");
        lb.shapeDepth     = (float)(double) obj->getProperty("shapeDepth");
        lb.shapeRange     = obj->getProperty("shapeRange").toString();
        lb.shapePolarity  = obj->getProperty("shapePolarity").toString();
        lb.shapeTempoSync = (bool) obj->getProperty("shapeTempoSync");
        lb.shapeSyncDiv   = obj->getProperty("shapeSyncDiv").toString();
        lb.shapeTrigger   = obj->getProperty("shapeTrigger").toString();
        if (lb.shapeType.isEmpty())     lb.shapeType = "circle";
        if (lb.shapeTracking.isEmpty()) lb.shapeTracking = "horizontal";
        if (lb.shapeRange.isEmpty())    lb.shapeRange = "relative";
        if (lb.shapePolarity.isEmpty()) lb.shapePolarity = "bipolar";
        if (lb.shapeSyncDiv.isEmpty())  lb.shapeSyncDiv = "1/4";
        if (lb.shapeTrigger.isEmpty())  lb.shapeTrigger = "free";

        // Per-param ranges for shapes_range mode
        auto rangesVar = obj->getProperty("targetRanges");
        if (rangesVar.isArray())
        {
            for (int ri = 0; ri < rangesVar.size(); ++ri)
                lb.targetRangeValues.push_back((float)(double) rangesVar[ri]);
        }
        // Per-param base values (anchor positions) for shapes_range mode
        auto rangeBasesVar = obj->getProperty("targetRangeBases");
        if (rangeBasesVar.isArray())
        {
            for (int ri = 0; ri < rangeBasesVar.size(); ++ri)
                lb.targetRangeBaseValues.push_back((float)(double) rangeBasesVar[ri]);
        }

        // ── Lane clips ──
        auto lanesVar = obj->getProperty("lanes");
        if (lanesVar.isArray())
        {
            for (int li = 0; li < lanesVar.size(); ++li)
            {
                if (auto* lObj = lanesVar[li].getDynamicObject())
                {
                    LogicBlock::LaneClip lc;
                    // Parse lane targets (multi-param per lane)
                    auto laneTargetsVar = lObj->getProperty("targets");
                    if (laneTargetsVar.isArray())
                    {
                        for (int lt = 0; lt < laneTargetsVar.size(); ++lt)
                        {
                            if (auto* ltObj = laneTargetsVar[lt].getDynamicObject())
                            {
                                LogicBlock::LaneClip::LaneTarget tgt;
                                tgt.pluginId   = (int) ltObj->getProperty("pluginId");
                                tgt.paramIndex = (int) ltObj->getProperty("paramIndex");
                                lc.targets.push_back(tgt);
                            }
                        }
                    }
                    else
                    {
                        // Backwards compat: single pluginId/paramIndex
                        LogicBlock::LaneClip::LaneTarget tgt;
                        tgt.pluginId   = (int) lObj->getProperty("pluginId");
                        tgt.paramIndex = (int) lObj->getProperty("paramIndex");
                        lc.targets.push_back(tgt);
                    }
                    lc.loopLen    = lObj->getProperty("loopLen").toString();
                    lc.phase      = (float)(double) lObj->getProperty("phase");
                    lc.depth      = (float)(double) lObj->getProperty("depth");
                    lc.slew       = (float)(double) lObj->getProperty("slew") / 50.0f;  // -1..+1
                    lc.warp       = (float)(double) lObj->getProperty("warp") / 50.0f;   // -1..+1
                    lc.interp     = lObj->getProperty("interp").toString();
                    lc.synced     = (bool) lObj->getProperty("synced");
                    lc.muted      = (bool) lObj->getProperty("muted");
                    lc.playMode   = lObj->getProperty("playMode").toString();
                    lc.freeSecs   = (float)(double) lObj->getProperty("freeSecs");
                    if (lc.loopLen.isEmpty()) lc.loopLen = "1/1";
                    if (lc.interp.isEmpty())  lc.interp = "smooth";
                    if (lc.playMode.isEmpty()) lc.playMode = "forward";
                    if (lc.freeSecs <= 0.0f) lc.freeSecs = 4.0f;

                    auto ptsVar = lObj->getProperty("pts");
                    if (ptsVar.isArray())
                    {
                        for (int pi = 0; pi < ptsVar.size(); ++pi)
                        {
                            if (auto* ptObj = ptsVar[pi].getDynamicObject())
                            {
                                LogicBlock::LaneClip::Point pt;
                                pt.x = (float)(double) ptObj->getProperty("x");
                                pt.y = (float)(double) ptObj->getProperty("y");
                                lc.pts.push_back(pt);
                            }
                        }
                    }
                    lb.laneClips.push_back(std::move(lc));
                }
            }
        }

        // Parse snapshots array
        auto snapsVar = obj->getProperty("snapshots");
        if (snapsVar.isArray()) {
            for (int si = 0; si < snapsVar.size() && si < 12; ++si) {
                if (auto* sObj = snapsVar[si].getDynamicObject()) {
                    LogicBlock::MorphSnapshot snap;
                    snap.x = (float)(double) sObj->getProperty("x");
                    snap.y = (float)(double) sObj->getProperty("y");
                    auto valsVar = sObj->getProperty("targetValues");
                    if (valsVar.isArray()) {
                        for (int vi = 0; vi < valsVar.size(); ++vi)
                            snap.targetValues.push_back((float)(double) valsVar[vi]);
                    }
                    lb.snapshots.push_back(snap);
                }
            }
        }

        // Parse targets array: [{hostId, paramIndex}, ...]
        auto targetsVar = obj->getProperty ("targets");
        if (targetsVar.isArray())
        {
            for (int t = 0; t < targetsVar.size(); ++t)
            {
                if (auto* tObj = targetsVar[t].getDynamicObject())
                {
                    ParamTarget pt;
                    pt.pluginId   = (int) tObj->getProperty ("hostId");
                    pt.paramIndex = (int) tObj->getProperty ("paramIndex");
                    lb.targets.push_back (pt);
                }
            }
        }

        // Parse targetBases array (base values captured at assignment time in JS)
        auto basesVar = obj->getProperty ("targetBases");
        if (basesVar.isArray())
        {
            lb.targetBaseValues.resize (lb.targets.size(), 0.5f);
            lb.targetLastWritten.resize (lb.targets.size(), 0.5f);
            for (int t = 0; t < basesVar.size() && t < (int) lb.targets.size(); ++t)
            {
                float base = (float)(double) basesVar[t];
                lb.targetBaseValues[t] = base;
                lb.targetLastWritten[t] = base;
            }
        }

        // Preserve runtime state from existing blocks with matching ID
        for (const auto& existing : logicBlocks)
        {
            if (existing.id == lb.id)
            {
                lb.currentEnvValue     = existing.currentEnvValue;
                lb.lastBeat            = existing.lastBeat;
                lb.lastAudioTrigSample = existing.lastAudioTrigSample;

                // Preserve sample data and playback state
                lb.sampleData      = existing.sampleData;
                lb.samplePlayhead  = existing.samplePlayhead;
                lb.sampleDirection = existing.sampleDirection;

                // Preserve relative-mode base values if mode and targets unchanged
                // Covers both randomize/sample (rangeMode) and shapes (shapeRange)
                bool newRelative = (lb.rangeMode == "relative" || lb.shapeRange == "relative");
                bool oldRelative = (existing.rangeMode == "relative" || existing.shapeRange == "relative");
                if (newRelative && oldRelative
                    && lb.targets.size() == existing.targets.size())
                {
                    // Carry over base values and last-written state smoothly
                    // Polarity changes only affect the formula, no need to reset params
                    lb.targetBaseValues = existing.targetBaseValues;
                    lb.targetLastWritten = existing.targetLastWritten;
                }

                // Preserve morph runtime state
                lb.morphVelX      = existing.morphVelX;
                lb.morphVelY      = existing.morphVelY;
                lb.morphAngle     = existing.morphAngle;
                lb.morphLfoPhase  = existing.morphLfoPhase;
                lb.morphStepIndex = existing.morphStepIndex;
                lb.morphSmoothX   = existing.morphSmoothX;
                lb.morphSmoothY   = existing.morphSmoothY;
                lb.prevAppliedX   = existing.prevAppliedX;
                lb.prevAppliedY   = existing.prevAppliedY;
                lb.morphNoisePhaseX = existing.morphNoisePhaseX;
                lb.morphNoisePhaseY = existing.morphNoisePhaseY;
                lb.morphOrbitPhase  = existing.morphOrbitPhase;
                lb.morphOrbitTarget = existing.morphOrbitTarget;
                lb.morphPathProgress = existing.morphPathProgress;
                lb.morphPathIndex   = existing.morphPathIndex;
                lb.lfoRotAngle      = existing.lfoRotAngle;

                // Preserve shapes runtime state
                lb.shapePhase    = existing.shapePhase;
                lb.shapeRotAngle = existing.shapeRotAngle;
                lb.smoothedRangeValues = existing.smoothedRangeValues;
                lb.smoothedShapeDepth = existing.smoothedShapeDepth;

                // Preserve lane playhead positions
                if (lb.laneClips.size() == existing.laneClips.size())
                {
                    for (size_t li = 0; li < lb.laneClips.size(); ++li)
                    {
                        lb.laneClips[li].playhead = existing.laneClips[li].playhead;
                        lb.laneClips[li].direction = existing.laneClips[li].direction;
                        lb.laneClips[li].slewState = existing.laneClips[li].slewState;
                    }
                }

                // Force prevApplied to match morphSmooth so the block rebuild
                // doesn't trigger a spurious IDW re-application (which would
                // overwrite any manual parameter tweaks the user has made).
                lb.prevAppliedX = lb.morphSmoothX;
                lb.prevAppliedY = lb.morphSmoothY;

                break;
            }
        }
        // H4 fix: parse string fields → enum mirrors + pre-compute beat divisions
        // Called once on message thread so processBlock uses integer comparisons.
        lb.modeE          = parseBlockMode (lb.mode);
        lb.triggerE       = parseTriggerType (lb.trigger);
        lb.midiModeE      = parseMidiTrigMode (lb.midiMode);
        lb.audioSrcE      = parseAudioSource (lb.audioSrc);
        lb.rangeModeE     = parseRangeMode (lb.rangeMode);
        lb.movementE      = parseMovement (lb.movement);
        lb.polarityE      = parsePolarity (lb.polarity);
        lb.clockSourceE   = parseClockSource (lb.clockSource);
        lb.loopModeE      = parseLoopMode (lb.loopMode);
        lb.jumpModeE      = parseJumpMode (lb.jumpMode);
        lb.morphModeE     = parseMorphMode (lb.morphMode);
        lb.exploreModeE   = parseExploreMode (lb.exploreMode);
        lb.lfoShapeE      = parseLfoShape (lb.lfoShape);
        lb.morphActionE   = parseMorphAction (lb.morphAction);
        lb.stepOrderE     = parseStepOrder (lb.stepOrder);
        lb.shapeTypeE     = parseLfoShape (lb.shapeType);
        lb.shapeTrackingE = parseShapeTracking (lb.shapeTracking);
        lb.shapeRangeE    = parseRangeMode (lb.shapeRange);
        lb.shapePolarityE = parsePolarity (lb.shapePolarity);
        lb.shapeTriggerE  = parseShapeTrigger (lb.shapeTrigger);
        lb.beatDivBeats     = parseBeatsPerDiv (lb.beatDiv);
        lb.morphSyncDivBeats = parseBeatsPerDiv (lb.morphSyncDiv);
        lb.shapeSyncDivBeats = parseBeatsPerDiv (lb.shapeSyncDiv);

        // Pre-compute lane clip enums + beat division floats
        for (auto& lc : lb.laneClips)
        {
            lc.interpE   = parseLaneInterp (lc.interp);
            lc.playModeE = parseLanePlayMode (lc.playMode);
            lc.loopLenFree = (lc.loopLen == "free");
            lc.loopLenBeats = lc.loopLenFree ? 0.0f : parseBeatsPerDiv (lc.loopLen);
        }

        // H3 fix: Pre-allocate vectors that processBlock uses, so the audio thread
        // never needs to call resize() (which can heap-allocate).
        auto n = lb.targets.size();
        if (lb.targetBaseValues.size() != n)
        {
            lb.targetBaseValues.resize (n, 0.5f);
            lb.targetLastWritten.resize (n, -1.0f);
        }
        // smoothedRangeValues for shapes_range mode
        if (lb.modeE == BlockMode::ShapesRange && lb.smoothedRangeValues.size() < n)
            lb.smoothedRangeValues.resize (n, 0.0f);

        newBlocks.push_back (std::move (lb));
    }

    std::lock_guard<std::mutex> lock (blockMutex);

    // Restore base values for blocks that transitioned enabledâ†’disabled
    // or lost targets (proper modulation recall behavior)
    for (const auto& old : logicBlocks)
    {
        if (!old.enabled || old.targetBaseValues.empty()) continue;

        // Find matching new block
        const LogicBlock* newLb = nullptr;
        for (const auto& nb : newBlocks)
        {
            if (nb.id == old.id) { newLb = &nb; break; }
        }

        bool wasModulating = old.enabled && !old.targets.empty()
            && (old.modeE == BlockMode::Envelope || old.modeE == BlockMode::Shapes || old.modeE == BlockMode::ShapesRange
                || old.modeE == BlockMode::MorphPad || old.modeE == BlockMode::Sample || old.modeE == BlockMode::Lane);

        if (!wasModulating) continue;

        // Block removed, disabled, or targets cleared â†’ restore bases
        bool shouldRestore = (newLb == nullptr)
            || (!newLb->enabled)
            || (newLb->targets.empty());

        if (shouldRestore)
        {
            for (size_t ti = 0; ti < old.targets.size() && ti < old.targetBaseValues.size(); ++ti)
            {
                setHostedParam (old.targets[ti].pluginId, old.targets[ti].paramIndex,
                                old.targetBaseValues[ti]);
                int slot = slotForId (old.targets[ti].pluginId);
                if (slot >= 0 && old.targets[ti].paramIndex < kMaxParams)
                    paramWritten[slot][old.targets[ti].paramIndex] = -1.0f;
            }
        }
        else if (newLb != nullptr)
        {
            // Check for specific targets that were removed
            for (size_t ti = 0; ti < old.targets.size() && ti < old.targetBaseValues.size(); ++ti)
            {
                bool stillPresent = false;
                for (const auto& nt : newLb->targets)
                {
                    if (nt.pluginId == old.targets[ti].pluginId && nt.paramIndex == old.targets[ti].paramIndex)
                    { stillPresent = true; break; }
                }
                if (!stillPresent)
                {
                    setHostedParam (old.targets[ti].pluginId, old.targets[ti].paramIndex,
                                    old.targetBaseValues[ti]);
                    int slot = slotForId (old.targets[ti].pluginId);
                    if (slot >= 0 && old.targets[ti].paramIndex < kMaxParams)
                        paramWritten[slot][old.targets[ti].paramIndex] = -1.0f;
                }
            }
        }
    }

    logicBlocks = std::move (newBlocks);
}

void ModularRandomizerAudioProcessor::updateMorphPlayhead (int blockId, float x, float y)
{
    std::lock_guard<std::mutex> lock (blockMutex);
    for (auto& lb : logicBlocks)
    {
        if (lb.id == blockId && lb.mode == "morph_pad")
        {
            // Circular clamp (r=0.45) before storing
            float dx = x - 0.5f, dy = y - 0.5f;
            float d = std::sqrt (dx * dx + dy * dy);
            if (d > 0.45f) { float s = 0.45f / d; x = 0.5f + dx * s; y = 0.5f + dy * s; }
            lb.playheadX = x;
            lb.playheadY = y;
            break;
        }
    }
}

int ModularRandomizerAudioProcessor::slotForId (int pluginId) const
{
    // Use pluginId directly as the array slot (modulo kMaxPlugins).
    // pluginIds are unique and monotonically increasing, so no collisions
    // occur as long as we don't exceed kMaxPlugins simultaneous plugins.
    if (pluginId < 0) return -1;
    return pluginId % kMaxPlugins;
}

void ModularRandomizerAudioProcessor::rebuildPluginSlots()
{
    // Called from message thread whenever plugins are added/removed/reordered.
    // Populates O(1) lookup table used by audio thread hot path.
    std::memset (pluginSlots, 0, sizeof (pluginSlots));
    for (auto& hp : hostedPlugins)
    {
        if (hp)
        {
            int slot = slotForId (hp->id);
            if (slot >= 0)
                pluginSlots[slot] = hp.get();
        }
    }
}

void ModularRandomizerAudioProcessor::setParamDirect (int pluginId, int paramIndex, float value)
{
    // Skip if user is currently grabbing this param (lock-free atomic read)
    int slot = slotForId (pluginId);
    if (slot < 0) return;

    if (paramIndex >= 0 && paramIndex < kMaxParams
        && paramTouched[slot][paramIndex].load (std::memory_order_acquire))
        return;

    // O(1) lookup via pluginSlots — no linear scan
    auto* hp = pluginSlots[slot];
    if (hp && hp->id == pluginId && hp->instance)
    {
        auto& params = hp->instance->getParameters();
        if (paramIndex >= 0 && paramIndex < params.size())
        {
            params[paramIndex]->setValue (value);
            recordSelfWrite (pluginId, paramIndex);
        }
    }
}

float ModularRandomizerAudioProcessor::getParamValue (int pluginId, int paramIndex) const
{
    int slot = slotForId (pluginId);
    if (slot >= 0)
    {
        auto* hp = pluginSlots[slot];
        if (hp && hp->id == pluginId && hp->instance)
        {
            auto& params = hp->instance->getParameters();
            if (paramIndex >= 0 && paramIndex < params.size())
                return params[paramIndex]->getValue();
        }
    }
    return 0.5f; // safe default center
}

void ModularRandomizerAudioProcessor::randomizeParams (int pluginId,
                                                        const std::vector<int>& paramIndices,
                                                        float minVal, float maxVal)
{
    // Persistent RNG — avoids identical sequences when called rapidly (M2 fix)
    static juce::Random messageThreadRng;

    // No mutex needed — hostedPlugins is structurally stable, setValue() is atomic
    for (auto& hp : hostedPlugins)
    {
        if (hp->id == pluginId && hp->instance != nullptr)
        {
            auto& params = hp->instance->getParameters();

            for (int idx : paramIndices)
            {
                if (idx >= 0 && idx < params.size())
                {
                    float val = minVal + messageThreadRng.nextFloat() * (maxVal - minVal);
                    params[idx]->setValue (juce::jlimit (0.0f, 1.0f, val));
                    recordSelfWrite (pluginId, idx);
                }
            }
            break;
        }
    }
}

void ModularRandomizerAudioProcessor::applyParamBatch (const juce::String& jsonBatch)
{
    // Batch param apply — sets N params in a single call.
    // JSON format: [{"p":pluginId,"i":paramIndex,"v":value}, ...]
    // No lock needed: hostedPlugins is structurally stable, setValue() is atomic.
    auto parsed = juce::JSON::parse (jsonBatch);
    if (! parsed.isArray()) return;

    for (int k = 0; k < parsed.size(); ++k)
    {
        auto* obj = parsed[k].getDynamicObject();
        if (obj == nullptr) continue;

        int pluginId   = (int) obj->getProperty ("p");
        int paramIndex = (int) obj->getProperty ("i");
        float value    = (float) (double) obj->getProperty ("v");

        for (auto& hp : hostedPlugins)
        {
            if (hp->id == pluginId && hp->instance != nullptr)
            {
                auto& params = hp->instance->getParameters();
                if (paramIndex >= 0 && paramIndex < params.size())
                {
                    params[paramIndex]->setValue (juce::jlimit (0.0f, 1.0f, value));
                    recordSelfWrite (pluginId, paramIndex);
                }
                break;
            }
        }
    }
}

std::vector<ModularRandomizerAudioProcessor::HostedPluginInfo>
ModularRandomizerAudioProcessor::getHostedPluginList()
{
    std::vector<HostedPluginInfo> result;
    std::lock_guard<std::mutex> lock (pluginMutex);

    for (auto& hp : hostedPlugins)
    {
        if (hp->id < 0) continue; // skip tombstoned entries
        HostedPluginInfo info;
        info.id = hp->id;
        info.name = hp->name;
        info.path = hp->path;
        info.numParams = hp->instance ? (int) hp->instance->getParameters().size() : 0;
        info.busId = hp->busId;
        result.push_back (info);
    }
    return result;
}

juce::AudioPluginInstance* ModularRandomizerAudioProcessor::getHostedPluginInstance (int pluginId)
{
    std::lock_guard<std::mutex> lock (pluginMutex);

    for (auto& hp : hostedPlugins)
    {
        if (hp->id == pluginId && hp->instance != nullptr)
            return hp->instance.get();
    }
    return nullptr;
}

void ModularRandomizerAudioProcessor::setPluginBusId (int pluginId, int busId)
{
    std::lock_guard<std::mutex> lock (pluginMutex);
    for (auto& hp : hostedPlugins)
    {
        if (hp->id == pluginId)
        {
            hp->busId = juce::jlimit (0, maxBuses - 2, busId);
            break;
        }
    }
}

void ModularRandomizerAudioProcessor::setBusVolume (int bus, float vol)
{
    if (bus >= 0 && bus < maxBuses)
        busVolume[bus].store (juce::jlimit (0.0f, 2.0f, vol));
}

void ModularRandomizerAudioProcessor::setBusMute (int bus, bool m)
{
    if (bus >= 0 && bus < maxBuses)
        busMute[bus].store (m);
}

void ModularRandomizerAudioProcessor::setBusSolo (int bus, bool s)
{
    if (bus >= 0 && bus < maxBuses)
        busSolo[bus].store (s);
}

//==============================================================================
//==============================================================================
void ModularRandomizerAudioProcessor::setUiState (const juce::String& json)
{
    std::lock_guard<std::mutex> lock (uiStateMutex);
    uiStateJson = json;
}

juce::String ModularRandomizerAudioProcessor::getUiState() const
{
    std::lock_guard<std::mutex> lock (uiStateMutex);
    return uiStateJson;
}

//==============================================================================
// Sample Modulator API
//==============================================================================

bool ModularRandomizerAudioProcessor::loadSampleForBlock (int blockId, const juce::String& filePath)
{
    juce::File file (filePath);
    if (! file.existsAsFile())
    {
        LOG_TO_FILE ("loadSampleForBlock: file not found: " << filePath.toStdString());
        return false;
    }

    std::unique_ptr<juce::AudioFormatReader> reader (audioFileFormatManager.createReaderFor (file));
    if (reader == nullptr)
    {
        LOG_TO_FILE ("loadSampleForBlock: unsupported format: " << filePath.toStdString());
        return false;
    }

    // Read audio, convert to mono
    juce::AudioBuffer<float> rawBuffer ((int) reader->numChannels, (int) reader->lengthInSamples);
    reader->read (&rawBuffer, 0, (int) reader->lengthInSamples, 0, true, true);

    // Mix to mono
    juce::AudioBuffer<float> monoBuffer (1, (int) reader->lengthInSamples);
    monoBuffer.clear();
    for (int ch = 0; ch < rawBuffer.getNumChannels(); ++ch)
        monoBuffer.addFrom (0, 0, rawBuffer, ch, 0, rawBuffer.getNumSamples(),
                            1.0f / (float) rawBuffer.getNumChannels());

    // Generate waveform peaks for UI (~200 points)
    int numPeaks = 200;
    int samplesPerPeak = juce::jmax (1, (int) reader->lengthInSamples / numPeaks);
    std::vector<float> peaks;
    peaks.reserve ((size_t) numPeaks);
    const float* mono = monoBuffer.getReadPointer (0);
    for (int p = 0; p < numPeaks && p * samplesPerPeak < monoBuffer.getNumSamples(); ++p)
    {
        float peak = 0.0f;
        int start = p * samplesPerPeak;
        int end = juce::jmin (start + samplesPerPeak, monoBuffer.getNumSamples());
        for (int s = start; s < end; ++s)
            peak = juce::jmax (peak, std::abs (mono[s]));
        peaks.push_back (peak);
    }

    // Build SampleData
    auto sd = std::make_shared<SampleData>();
    sd->buffer = std::move (monoBuffer);
    sd->sampleRate = reader->sampleRate;
    sd->filePath = filePath;
    sd->fileName = file.getFileName();
    sd->waveformPeaks = std::move (peaks);
    sd->durationSeconds = (float) reader->lengthInSamples / (float) reader->sampleRate;

    // Assign to the matching logic block
    std::lock_guard<std::mutex> lock (blockMutex);
    for (auto& lb : logicBlocks)
    {
        if (lb.id == blockId)
        {
            lb.sampleData = sd;
            lb.samplePlayhead = 0.0;
            lb.sampleDirection = lb.sampleReverse ? -1 : 1;
            LOG_TO_FILE ("loadSampleForBlock: loaded " << sd->fileName.toStdString()
                         << " (" << sd->durationSeconds << "s, " << sd->buffer.getNumSamples() << " samples)");
            return true;
        }
    }

    LOG_TO_FILE ("loadSampleForBlock: block ID " << blockId << " not found");
    return false;
}

std::vector<float> ModularRandomizerAudioProcessor::getSampleWaveform (int blockId)
{
    std::lock_guard<std::mutex> lock (blockMutex);
    for (const auto& lb : logicBlocks)
    {
        if (lb.id == blockId && lb.sampleData != nullptr)
            return lb.sampleData->waveformPeaks;
    }
    return {};
}

juce::String ModularRandomizerAudioProcessor::getSampleFileName (int blockId)
{
    std::lock_guard<std::mutex> lock (blockMutex);
    for (const auto& lb : logicBlocks)
    {
        if (lb.id == blockId && lb.sampleData != nullptr)
            return lb.sampleData->fileName;
    }
    return {};
}

//==============================================================================
juce::AudioProcessorEditor* ModularRandomizerAudioProcessor::createEditor()
{
    return new ModularRandomizerAudioProcessorEditor (*this);
}

bool ModularRandomizerAudioProcessor::hasEditor() const
{
    return true;
}

//==============================================================================
const juce::String ModularRandomizerAudioProcessor::getName() const           { return JucePlugin_Name; }
bool ModularRandomizerAudioProcessor::acceptsMidi() const                     { return true; }
bool ModularRandomizerAudioProcessor::producesMidi() const                    { return false; }
bool ModularRandomizerAudioProcessor::isMidiEffect() const                    { return false; }
double ModularRandomizerAudioProcessor::getTailLengthSeconds() const          { return 0.0; }
int ModularRandomizerAudioProcessor::getNumPrograms()                         { return 1; }
int ModularRandomizerAudioProcessor::getCurrentProgram()                      { return 0; }
void ModularRandomizerAudioProcessor::setCurrentProgram (int)                 {}
const juce::String ModularRandomizerAudioProcessor::getProgramName (int)      { return {}; }
void ModularRandomizerAudioProcessor::changeProgramName (int, const juce::String&) {}

//==============================================================================
void ModularRandomizerAudioProcessor::getStateInformation (juce::MemoryBlock& destData)
{
    auto state = apvts.copyState();
    std::unique_ptr<juce::XmlElement> xml (state.createXml());

    // Save hosted plugins
    {
        std::lock_guard<std::mutex> lock (pluginMutex);
        auto* pluginsXml = xml->createNewChildElement ("HOSTED_PLUGINS");
        for (auto& hp : hostedPlugins)
        {
            if (hp->id < 0) continue; // skip dead entries
            auto* plugEl = pluginsXml->createNewChildElement ("PLUGIN");
            plugEl->setAttribute ("id", hp->id);
            plugEl->setAttribute ("name", hp->name);
            plugEl->setAttribute ("path", hp->path);
            plugEl->setAttribute ("busId", hp->busId);

            // Save all parameter values
            if (hp->instance)
            {
                auto& params = hp->instance->getParameters();
                auto* paramsEl = plugEl->createNewChildElement ("PARAMS");
                for (int i = 0; i < (int) params.size(); ++i)
                {
                    auto* pEl = paramsEl->createNewChildElement ("P");
                    pEl->setAttribute ("i", i);
                    pEl->setAttribute ("v", (double) params[i]->getValue());
                }
            }
        }
        pluginsXml->setAttribute ("nextId", nextPluginId);
        pluginsXml->setAttribute ("routingMode", routingMode.load());
    }

    // Save UI state (blocks, mappings, locks)
    {
        std::lock_guard<std::mutex> lock (uiStateMutex);
        if (uiStateJson.isNotEmpty())
            xml->createNewChildElement ("UI_STATE")->addTextElement (uiStateJson);
    }

    copyXmlToBinary (*xml, destData);
}

void ModularRandomizerAudioProcessor::setStateInformation (const void* data, int sizeInBytes)
{
    std::unique_ptr<juce::XmlElement> xmlState (getXmlFromBinary (data, sizeInBytes));
    if (xmlState == nullptr) return;

    // Restore APVTS
    if (xmlState->hasTagName (apvts.state.getType()))
        apvts.replaceState (juce::ValueTree::fromXml (*xmlState));

    // Restore hosted plugins
    auto* pluginsXml = xmlState->getChildByName ("HOSTED_PLUGINS");
    if (pluginsXml != nullptr)
    {
        int restoredNextId = pluginsXml->getIntAttribute ("nextId", 0);
        routingMode.store (pluginsXml->getIntAttribute ("routingMode", 0));

        // Clear existing plugins safely — audio thread doesn't hold pluginMutex
        // Phase 1: Null all instances (audio thread checks for nullptr → skips)
        {
            std::lock_guard<std::mutex> lock (pluginMutex);
            for (auto& hp : hostedPlugins)
            {
                if (hp->instance && hp->prepared)
                    hp->instance->releaseResources();
                hp->instance.reset();  // audio thread sees nullptr → skips
                hp->prepared = false;
            }
        }
        // Phase 2: Clear the vector (safe — all instances are null, audio thread
        // won't access any plugin data even if it's mid-iteration)
        {
            std::lock_guard<std::mutex> lock (pluginMutex);
            hostedPlugins.clear();
            hostedPlugins.reserve (32);  // maintain pre-reserved capacity
        }

        // Reset flat param tracking arrays
        for (int s = 0; s < kMaxPlugins; ++s)
            for (int p = 0; p < kMaxParams; ++p)
            {
                paramWritten[s][p] = -1.0f;
                paramTouched[s][p].store (false, std::memory_order_relaxed);
            }
        numActiveGlides = 0;

        // Clear proxy mappings
        for (int i = 0; i < proxyParamCount; ++i)
        {
            proxyMap[i].pluginId   = -1;
            proxyMap[i].paramIndex = -1;
        }

        // Reload each plugin from its saved path
        for (auto* plugEl : pluginsXml->getChildIterator())
        {
            if (plugEl->getTagName() != "PLUGIN") continue;

            int savedId      = plugEl->getIntAttribute ("id", 0);
            auto savedPath   = plugEl->getStringAttribute ("path");

            if (savedPath.isEmpty()) continue;

            // Load the plugin (this handles scanning + instantiation)
            int newId = loadPlugin (savedPath);
            if (newId < 0)
            {
                DBG ("State restore: failed to reload plugin from " + savedPath);
                continue;
            }

            // Patch the plugin ID to match saved ID (preserves block target refs)
            {
                std::lock_guard<std::mutex> lock (pluginMutex);
                for (auto& hp : hostedPlugins)
                {
                    if (hp->id == newId)
                    {
                        hp->id = savedId;

                        // Restore parameter values
                        auto* paramsEl = plugEl->getChildByName ("PARAMS");
                        if (paramsEl != nullptr && hp->instance)
                        {
                            auto& params = hp->instance->getParameters();
                            for (auto* pEl : paramsEl->getChildIterator())
                            {
                                int idx = pEl->getIntAttribute ("i", -1);
                                float val = (float) pEl->getDoubleAttribute ("v", 0.0);
                                if (idx >= 0 && idx < (int) params.size())
                                    params[idx]->setValue (val);
                            }
                        }

                        // Patch proxy map entries to match new ID
                        for (int pi = 0; pi < proxyParamCount; ++pi)
                        {
                            if (proxyMap[pi].pluginId == newId)
                                proxyMap[pi].pluginId = savedId;
                        }

                        // Restore bus ID for parallel routing
                        hp->busId = plugEl->getIntAttribute ("busId", 0);

                        break;
                    }
                }
            }
        }

        // Restore nextPluginId to avoid ID collisions
        nextPluginId = juce::jmax (nextPluginId, restoredNextId);
    }

    // Restore UI state
    auto* uiStateXml = xmlState->getChildByName ("UI_STATE");
    if (uiStateXml != nullptr)
    {
        std::lock_guard<std::mutex> lock (uiStateMutex);
        uiStateJson = uiStateXml->getAllSubText().trim();
    }
}

//==============================================================================
void ModularRandomizerAudioProcessor::setPluginBypass (int pluginId, bool bypass)
{
    std::lock_guard<std::mutex> lock (pluginMutex);
    for (auto& hp : hostedPlugins)
    {
        if (hp->id == pluginId)
        {
            hp->bypassed = bypass;
            break;
        }
    }
}

void ModularRandomizerAudioProcessor::resetPluginCrash (int pluginId)
{
    std::lock_guard<std::mutex> lock (pluginMutex);
    for (auto& hp : hostedPlugins)
    {
        if (hp->id == pluginId && hp->crashed)
        {
            // Re-prepare the plugin before allowing it to process again
            if (hp->instance != nullptr)
            {
                try
                {
                    hp->instance->prepareToPlay (currentSampleRate, currentBlockSize);
                    hp->crashed = false;
                    hp->prepared = true;
                    LOG_TO_FILE ("resetPluginCrash: Re-enabled plugin '"
                                 << hp->name.toStdString() << "' (ID: " << pluginId << ")");
                }
                catch (...)
                {
                    LOG_TO_FILE ("resetPluginCrash: Plugin '"
                                 << hp->name.toStdString() << "' crashed again during prepareToPlay");
                    // Leave crashed = true
                }
            }
            break;
        }
    }
}

//==============================================================================
juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new ModularRandomizerAudioProcessor();
}
