#pragma once

#include "PluginProcessor.h"
#include <juce_gui_extra/juce_gui_extra.h>
#include <map>
#include <unordered_map>
#include <unordered_set>

//==============================================================================
/**
 * Window that hosts a VST3 plugin's native editor GUI.
 * Opens as a separate floating window on top of the main plugin window.
 */
class PluginEditorWindow : public juce::DocumentWindow
{
public:
    PluginEditorWindow (const juce::String& name,
                        juce::AudioPluginInstance* pluginInstance,
                        std::function<void()> onCloseCallback)
        : DocumentWindow (name, juce::Colours::darkgrey, DocumentWindow::closeButton),
          closeCallback (std::move (onCloseCallback))
    {
        if (pluginInstance != nullptr)
        {
            if (auto* editor = pluginInstance->createEditor())
            {
                setContentOwned (editor, true);
            }
            else
            {
                // Plugin has no GUI — show placeholder
                auto* label = new juce::Label ({}, "No GUI available");
                label->setSize (300, 100);
                label->setJustificationType (juce::Justification::centred);
                setContentOwned (label, true);
            }
        }

        setUsingNativeTitleBar (true);
        setResizable (true, false);
        setAlwaysOnTop (true);
        centreWithSize (getWidth(), getHeight());
        setVisible (true);
    }

    void closeButtonPressed() override
    {
        if (closeCallback)
            closeCallback();
    }

private:
    std::function<void()> closeCallback;
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (PluginEditorWindow)
};

//==============================================================================
/**
 * ModularRandomizer Editor — WebView2-based UI
 *
 * ⚠️ CRITICAL: Member declaration order prevents DAW crashes on unload.
 *    Destruction order = reverse of declaration.
 *    Order: Relays → WebView → Attachments
 */
class ModularRandomizerAudioProcessorEditor : public juce::AudioProcessorEditor,
                                               private juce::Timer
{
public:
    ModularRandomizerAudioProcessorEditor (ModularRandomizerAudioProcessor&);
    ~ModularRandomizerAudioProcessorEditor() override;

    //==============================================================================
    void paint (juce::Graphics&) override;
    void resized() override;

private:
    void timerCallback() override;

    // Resource provider for WebView
    std::optional<juce::WebBrowserComponent::Resource> getResource (const juce::String& url);
    static const char* getMimeForExtension (const juce::String& extension);

    // Open/close a hosted plugin's editor window
    void openPluginEditorWindow (int pluginId);

    ModularRandomizerAudioProcessor& audioProcessor;

    // ═══════════════════════════════════════════════════════════════
    // CRITICAL: Destruction Order = Reverse of Declaration
    // Order: Relays → WebView → Attachments
    // ═══════════════════════════════════════════════════════════════

    // 1. RELAYS FIRST (destroyed last)
    juce::WebSliderRelay mixRelay       { "MIX" };
    juce::WebToggleButtonRelay bypassRelay  { "BYPASS" };

    // 2. WEBVIEW SECOND (destroyed middle)
    std::unique_ptr<juce::WebBrowserComponent> webView;

    // 3. ATTACHMENTS LAST (destroyed first)
    std::unique_ptr<juce::WebSliderParameterAttachment>       mixAttachment;
    std::unique_ptr<juce::WebToggleButtonParameterAttachment> bypassAttachment;

    // Hosted plugin editor windows (keyed by plugin ID)
    std::map<int, std::unique_ptr<PluginEditorWindow>> pluginEditorWindows;

    // Timer tick counter for throttled polling
    int timerTickCount = 0;

    // Auto-locate: track which param was last touched in hosted plugin UI
    std::unordered_map<std::string, float> lastParamValues;
    juce::String touchedParamId;

    // Two-tier polling: modulated params polled frequently, idle params polled lazily
    std::unordered_set<std::string> modulatedParamKeys;  // refreshed periodically

    // Params that recently changed (from hosted plugin UI) — promoted to tier 1 temporarily
    // Value = TTL in timer ticks (decremented each tick, removed when 0)
    std::unordered_map<std::string, int> recentlyChangedKeys;

    // Per-param identity cache: key → {pluginId, paramIndex} for fast value reads
    struct ParamIdent { int pluginId; int paramIndex; };
    std::unordered_map<std::string, ParamIdent> paramIdentCache;

    // Visibility culling: only poll params from expanded (visible) plugins
    // Updated by JS via setExpandedPlugins native function
    std::unordered_set<int> expandedPluginIds;

    //==============================================================================
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (ModularRandomizerAudioProcessorEditor)
};
