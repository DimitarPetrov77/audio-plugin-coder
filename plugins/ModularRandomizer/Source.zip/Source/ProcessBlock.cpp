/*
  ==============================================================================

    ProcessBlock.cpp
    Audio processing pipeline: processBlock, SEH crash guard, glide engine

  ==============================================================================
*/

#include "PluginProcessor.h"
#include "ParameterIDs.hpp"
//==============================================================================
// SEH-guarded processBlock wrapper (Windows only)
// Isolated as a free function because __try/__except cannot coexist
// with C++ objects that have destructors in the same function scope.
//==============================================================================
#ifdef _WIN32
bool sehGuardedProcessBlock (juce::AudioPluginInstance* instance,
                             juce::AudioBuffer<float>& buffer,
                             juce::MidiBuffer& midi)
{
    __try
    {
        instance->processBlock (buffer, midi);
        return true;  // success
    }
    __except (EXCEPTION_EXECUTE_HANDLER)
    {
        return false; // hardware fault caught
    }
}
#else
// Non-Windows: no SEH available, just call directly (C++ try/catch wraps this)
bool sehGuardedProcessBlock (juce::AudioPluginInstance* instance,
                             juce::AudioBuffer<float>& buffer,
                             juce::MidiBuffer& midi)
{
    instance->processBlock (buffer, midi);
    return true;
}
#endif

void ModularRandomizerAudioProcessor::processBlock (juce::AudioBuffer<float>& buffer,
                                                     juce::MidiBuffer& midiMessages)
{
    juce::ScopedNoDenormals noDenormals;

    // Clear any output channels that don't have corresponding inputs
    // (standard JUCE boilerplate — prevents garbage in unused channels)
    auto totalNumInputChannels  = getTotalNumInputChannels();
    auto totalNumOutputChannels = getTotalNumOutputChannels();
    for (auto i = totalNumInputChannels; i < totalNumOutputChannels; ++i)
        buffer.clear (i, 0, buffer.getNumSamples());

    // Determine main bus channel count (exclude sidechain channels)
    int mainBusChannels = (getBus (true, 0) != nullptr)
                        ? getBus (true, 0)->getNumberOfChannels() : buffer.getNumChannels();
    mainBusChannels = juce::jmin (mainBusChannels, buffer.getNumChannels());

    // â”€â”€ Capture real-time data for UI â”€â”€

    // Audio RMS level (from main input, before processing)
    {
        int scStart = getBus (true, 1) != nullptr && getBus (true, 1)->isEnabled()
                      ? getBus (true, 0)->getNumberOfChannels() : -1;

        float rms = 0.0f;
        float scRms = 0.0f;
        for (int ch = 0; ch < buffer.getNumChannels(); ++ch)
        {
            float chRms = buffer.getRMSLevel (ch, 0, buffer.getNumSamples());
            if (scStart >= 0 && ch >= scStart)
                scRms = juce::jmax (scRms, chRms);
            else
                rms = juce::jmax (rms, chRms);
        }
        currentRmsLevel.store (rms);
        sidechainRmsLevel.store (scRms);
    }

    // MIDI events for UI triggers (lock-free FIFO write)
    for (const auto metadata : midiMessages)
    {
        auto msg = metadata.getMessage();
        MidiEvent ev;
        if (msg.isNoteOn())
        {
            ev = { msg.getNoteNumber(), msg.getVelocity(), msg.getChannel(), false };
        }
        else if (msg.isController())
        {
            ev = { msg.getControllerNumber(), msg.getControllerValue(), msg.getChannel(), true };
        }
        else
        {
            continue;
        }

        const auto scope = midiFifo.write (1);
        if (scope.blockSize1 > 0)
            midiRing[scope.startIndex1] = ev;
        else if (scope.blockSize2 > 0)
            midiRing[scope.startIndex2] = ev;
        // If FIFO is full, event is silently dropped (acceptable for UI triggers)
    }

    // DAW transport info
    if (auto* playHead = getPlayHead())
    {
        if (auto pos = playHead->getPosition())
        {
            if (auto bpm = pos->getBpm())
                currentBpm.store (*bpm);
            isPlaying.store (pos->getIsPlaying());
            if (auto ppq = pos->getPpqPosition())
                ppqPosition.store (*ppq);
        }
    }

    // â”€â”€ Audio processing â”€â”€

    auto bypass = apvts.getRawParameterValue (ParameterIDs::BYPASS)->load();
    if (bypass > 0.5f)
        return; // Bypass: audio passes through unmodified

    auto mixPercent = apvts.getRawParameterValue (ParameterIDs::MIX)->load();
    float wet = mixPercent / 100.0f;

    // No pluginMutex lock on the audio thread! â€” a single block of unprocessed audio is
    // inaudible, whereas blocking would cause priority inversion and clicks.
    // NOTE: No pluginMutex lock on the audio thread!
    // hostedPlugins is structurally stable: removePlugin() only nulls instances
    // (never erases), purgeDeadPlugins() only runs from prepareToPlay().
    // processOnePlugin() checks for null instance. The old try_lock caused
    // crackles because UI parameter polling blocked the mutex, making the
    // audio thread skip processing for entire buffers.
    if (hostedPlugins.empty() || wet < 0.001f)
        return;

    // Save dry signal (use pre-allocated member buffer — no heap alloc)
    bool needsDryMix = wet < 0.999f;
    if (needsDryMix)
    {
        int dryChannels = juce::jmin (mainBusChannels, dryBuffer.getNumChannels());
        int drySamples  = juce::jmin (buffer.getNumSamples(),  dryBuffer.getNumSamples());
        for (int ch = 0; ch < dryChannels; ++ch)
            dryBuffer.copyFrom (ch, 0, buffer, ch, 0, drySamples);
    }

    // Advance monotonic sample counter (for trigger cooldowns)
    sampleCounter += buffer.getNumSamples();

    // â”€â”€ Logic Block Engine: triggers + envelope followers â”€â”€
    {
        std::unique_lock<std::mutex> blockLock (blockMutex, std::try_to_lock);
        if (blockLock.owns_lock() && ! logicBlocks.empty())
        {
            float mainRms = currentRmsLevel.load();
            float scRms   = sidechainRmsLevel.load();
            double ppq    = ppqPosition.load();
            bool   playing = isPlaying.load();
            int    numSamples = buffer.getNumSamples();
            float  bufferRate = (float) (currentSampleRate / numSamples);  // Hz

            // Collect MIDI events from this buffer for trigger matching
            // Uses pre-allocated member vector — no per-buffer allocation
            blockMidiEvents.clear();
            for (const auto metadata : midiMessages)
            {
                auto msg = metadata.getMessage();
                if (msg.isNoteOn())
                    blockMidiEvents.push_back ({ msg.getNoteNumber(), msg.getVelocity(), msg.getChannel(), false });
                else if (msg.isController())
                    blockMidiEvents.push_back ({ msg.getControllerNumber(), msg.getControllerValue(), msg.getChannel(), true });
            }

            // Beat divisions are now pre-computed as floats in updateLogicBlocks (H4 fix)

            int envIdx = 0;
            int smpIdx = 0;
            int morphIdx = 0;
            numActiveLanes.store(0);

            for (auto& lb : logicBlocks)
            {
                if (lb.targets.empty() || ! lb.enabled) continue;

                // ===== RANDOMIZE MODE =====
                if (lb.modeE == BlockMode::Randomize)
                {
                    bool shouldFire = false;

                    // --- MIDI trigger ---
                    if (lb.triggerE == TriggerType::Midi && ! blockMidiEvents.empty())
                    {
                        for (const auto& ev : blockMidiEvents)
                        {
                            if (lb.midiCh > 0 && ev.ch != lb.midiCh) continue;
                            if (lb.midiModeE == MidiTrigMode::AnyNote && ! ev.isCC)       { shouldFire = true; break; }
                            if (lb.midiModeE == MidiTrigMode::SpecificNote && ! ev.isCC && ev.note == lb.midiNote) { shouldFire = true; break; }
                            if (lb.midiModeE == MidiTrigMode::CC && ev.isCC && ev.note == lb.midiCC) { shouldFire = true; break; }
                        }
                    }

                    // --- Tempo trigger ---
                    if (lb.triggerE == TriggerType::Tempo && playing)
                    {
                        float bpt = lb.beatDivBeats;
                        int currentBeat = (int) std::floor (ppq / bpt);
                        if (lb.lastBeat < 0) lb.lastBeat = currentBeat;
                        if (currentBeat != lb.lastBeat)
                        {
                            lb.lastBeat = currentBeat;
                            shouldFire = true;
                        }
                    }

                    // --- Audio trigger ---
                    if (lb.triggerE == TriggerType::Audio)
                    {
                        float audioLvl = (lb.audioSrcE == AudioSource::Sidechain) ? scRms : mainRms;
                        float threshLin = std::pow (10.0f, lb.threshold / 20.0f);
                        double cooldownSamples = currentSampleRate * 0.1; // 100ms
                        if (audioLvl > threshLin && (sampleCounter - lb.lastAudioTrigSample) > cooldownSamples)
                        {
                            lb.lastAudioTrigSample = sampleCounter;
                            shouldFire = true;
                        }
                    }

                    // --- FIRE: generate random values and apply ---
                    if (shouldFire)
                    {
                        for (const auto& tgt : lb.targets)
                        {
                            float newVal;
                            if (lb.rangeModeE == RangeMode::Relative)
                            {
                                // Get current value — O(1) lookup
                                float cur = getParamValue (tgt.pluginId, tgt.paramIndex);
                                newVal = cur + (audioRandom.nextFloat() * 2.0f - 1.0f) * lb.rMax;
                            }
                            else
                            {
                                newVal = lb.rMin + audioRandom.nextFloat() * (lb.rMax - lb.rMin);
                            }

                            if (lb.quantize && lb.qSteps > 1)
                                newVal = std::round (newVal * (lb.qSteps - 1)) / (float) (lb.qSteps - 1);

                            newVal = juce::jlimit (0.0f, 1.0f, newVal);

                            if (lb.movementE == Movement::Glide && lb.glideMs > 0.0f)
                            {
                                // Push directly to glidePool (already on audio thread)
                                float cur = getParamValue (tgt.pluginId, tgt.paramIndex);
                                int total = juce::jmax (1, (int) (lb.glideMs * 0.001 * currentSampleRate));
                                // Update existing glide or create new
                                bool found = false;
                                for (int gi = 0; gi < numActiveGlides; ++gi)
                                {
                                    auto& g = glidePool[gi];
                                    if (g.pluginId == tgt.pluginId && g.paramIndex == tgt.paramIndex)
                                    {
                                        g.targetVal = newVal;
                                        g.increment = (newVal - g.currentVal) / (float) total;
                                        g.samplesLeft = total;
                                        found = true;
                                        break;
                                    }
                                }
                                if (! found && numActiveGlides < kMaxGlides)
                                {
                                    glidePool[numActiveGlides++] = { tgt.pluginId, tgt.paramIndex, cur, newVal,
                                                              (newVal - cur) / (float) total, total };
                                }
                            }
                            else
                            {
                                setParamDirect (tgt.pluginId, tgt.paramIndex, newVal);
                            }
                        }

                        // Notify UI of trigger fire (lock-free FIFO)
                        const auto tScope = triggerFifo.write (1);
                        if (tScope.blockSize1 > 0)      triggerRing[tScope.startIndex1] = lb.id;
                        else if (tScope.blockSize2 > 0) triggerRing[tScope.startIndex2] = lb.id;
                    }
                }

                // ===== ENVELOPE MODE =====
                else if (lb.modeE == BlockMode::Envelope)
                {
                    float audioLvl = (lb.audioSrcE == AudioSource::Sidechain) ? scRms : mainRms;
                    float raw = audioLvl * (lb.envSens / 50.0f);

                    // Per-buffer attack/release smoothing
                    float ac = std::exp (-1.0f / std::max (1.0f, lb.envAtk * 0.001f * bufferRate));
                    float rc = std::exp (-1.0f / std::max (1.0f, lb.envRel * 0.001f * bufferRate));

                    if (raw > lb.currentEnvValue)
                        lb.currentEnvValue = ac * lb.currentEnvValue + (1.0f - ac) * raw;
                    else
                        lb.currentEnvValue = rc * lb.currentEnvValue + (1.0f - rc) * raw;

                    float cl = juce::jlimit (0.0f, 1.0f, lb.currentEnvValue);
                    float mp = lb.envInvert ? (1.0f - cl) : cl;

                    if (lb.rangeModeE == RangeMode::Relative)
                    {
                        // Relative mode: offset ±depth from the parameter's resting value
                        auto n = lb.targets.size();
                        if (lb.targetBaseValues.size() != n)
                        {
                            lb.targetBaseValues.resize (n);
                            lb.targetLastWritten.resize (n, -1.0f);
                            for (size_t ti = 0; ti < n; ++ti)
                                lb.targetBaseValues[ti] = getParamValue (lb.targets[ti].pluginId, lb.targets[ti].paramIndex);
                        }

                        float depth = lb.rMax;
                        bool envIdle = cl < 0.005f; // envelope is essentially zero → not modulating

                        for (size_t ti = 0; ti < n; ++ti)
                        {
                            // Only update base when the envelope is idle (not modulating).
                            // During attack/release, the base must stay frozen so the param
                            // returns to its original position when the envelope releases to 0.
                            if (envIdle)
                            {
                                float cur = getParamValue (lb.targets[ti].pluginId, lb.targets[ti].paramIndex);
                                int _sl = slotForId (lb.targets[ti].pluginId);
                                float _pw = (_sl >= 0 && lb.targets[ti].paramIndex < kMaxParams) ? paramWritten[_sl][lb.targets[ti].paramIndex] : -1.0f;
                                // If current value differs from what we last wrote, the user moved it → adopt
                                if (_pw > -0.5f && std::abs (cur - _pw) > 0.005f)
                                    lb.targetBaseValues[ti] = cur;
                                else if (_pw < -0.5f && lb.targetLastWritten[ti] >= 0.0f && std::abs (cur - lb.targetLastWritten[ti]) > 0.005f)
                                    lb.targetBaseValues[ti] = cur;
                            }

                            float base = lb.targetBaseValues[ti];

                            // Compute offset based on polarity setting
                            // Envelope is a unipolar source (0=silent, 1=loud)
                            float offset;
                            if (lb.polarityE == Polarity::Up)
                                offset = mp * depth;                    // 0..+depth
                            else if (lb.polarityE == Polarity::Down)
                                offset = -mp * depth;                   // 0..-depth
                            else
                                offset = (mp * 2.0f - 1.0f) * depth;    // bipolar: -depth..+depth

                            float mapped = juce::jlimit (0.0f, 1.0f, base + offset);
                            setParamDirect (lb.targets[ti].pluginId, lb.targets[ti].paramIndex, mapped);
                            lb.targetLastWritten[ti] = mapped;
                            { int _s = slotForId (lb.targets[ti].pluginId); if (_s >= 0 && lb.targets[ti].paramIndex < kMaxParams) paramWritten[_s][lb.targets[ti].paramIndex] = mapped; }
                        }
                    }
                    else
                    {
                        // Absolute mode: envelope maps directly to [rMin, rMax]
                        float mapped = lb.rMin + mp * (lb.rMax - lb.rMin);
                        for (const auto& tgt : lb.targets)
                            setParamDirect (tgt.pluginId, tgt.paramIndex, juce::jlimit (0.0f, 1.0f, mapped));
                    }

                    // Write envelope level for UI readback
                    if (envIdx < maxEnvReadback)
                    {
                        envReadback[envIdx].blockId.store (lb.id);
                        envReadback[envIdx].level.store (cl);
                        envIdx++;
                    }
                }

                // ===== SAMPLE MODULATOR MODE =====
                else if (lb.modeE == BlockMode::Sample && lb.sampleData != nullptr)
                {
                    auto sd = lb.sampleData;  // shared_ptr copy (safe)
                    int totalSamp = sd->buffer.getNumSamples();
                    if (totalSamp < 2) continue;

                    // --- Check for jump triggers (same system as randomize) ---
                    bool shouldJump = false;

                    if (lb.triggerE == TriggerType::Midi && ! blockMidiEvents.empty())
                    {
                        for (const auto& ev : blockMidiEvents)
                        {
                            if (lb.midiCh > 0 && ev.ch != lb.midiCh) continue;
                            if (lb.midiModeE == MidiTrigMode::AnyNote && ! ev.isCC)       { shouldJump = true; break; }
                            if (lb.midiModeE == MidiTrigMode::SpecificNote && ! ev.isCC && ev.note == lb.midiNote) { shouldJump = true; break; }
                            if (lb.midiModeE == MidiTrigMode::CC && ev.isCC && ev.note == lb.midiCC) { shouldJump = true; break; }
                        }
                    }

                    if (lb.triggerE == TriggerType::Tempo && playing)
                    {
                        float bpt = lb.beatDivBeats;
                        int currentBeat = (int) std::floor (ppq / bpt);
                        if (lb.lastBeat < 0) lb.lastBeat = currentBeat;
                        if (currentBeat != lb.lastBeat)
                        {
                            lb.lastBeat = currentBeat;
                            shouldJump = true;
                        }
                    }

                    if (lb.triggerE == TriggerType::Audio)
                    {
                        float audioLvl = (lb.audioSrcE == AudioSource::Sidechain) ? scRms : mainRms;
                        float threshLin = std::pow (10.0f, lb.threshold / 20.0f);
                        double cooldownSamples = currentSampleRate * 0.1;
                        if (audioLvl > threshLin && (sampleCounter - lb.lastAudioTrigSample) > cooldownSamples)
                        {
                            lb.lastAudioTrigSample = sampleCounter;
                            shouldJump = true;
                        }
                    }

                    // Apply jump
                    if (shouldJump)
                    {
                        if (lb.jumpModeE == JumpMode::Random)
                            lb.samplePlayhead = audioRandom.nextDouble() * (double) (totalSamp - 1);
                        else // "restart"
                            lb.samplePlayhead = lb.sampleReverse ? (double) (totalSamp - 1) : 0.0;
                        lb.sampleDirection = lb.sampleReverse ? -1 : 1;

                        // Notify UI of trigger fire
                        const auto tScope = triggerFifo.write (1);
                        if (tScope.blockSize1 > 0)      triggerRing[tScope.startIndex1] = lb.id;
                        else if (tScope.blockSize2 > 0) triggerRing[tScope.startIndex2] = lb.id;
                    }

                    // --- Advance playhead ---
                    double playbackRate = (sd->sampleRate / currentSampleRate) * (double) lb.sampleSpeed;
                    double advance = playbackRate * (double) numSamples;
                    if (lb.sampleReverse) advance = -advance;
                    if (lb.sampleDirection < 0) advance = -advance;

                    lb.samplePlayhead += advance;

                    // Handle loop modes
                    if (lb.loopModeE == LoopMode::Loop)
                    {
                        lb.samplePlayhead = std::fmod (lb.samplePlayhead, (double) totalSamp);
                        if (lb.samplePlayhead < 0.0) lb.samplePlayhead += (double) totalSamp;
                    }
                    else if (lb.loopModeE == LoopMode::Pingpong)
                    {
                        if (lb.samplePlayhead >= (double) totalSamp)
                        {
                            lb.samplePlayhead = (double) (totalSamp - 1) - (lb.samplePlayhead - (double) totalSamp);
                            lb.sampleDirection *= -1;
                        }
                        if (lb.samplePlayhead < 0.0)
                        {
                            lb.samplePlayhead = -lb.samplePlayhead;
                            lb.sampleDirection *= -1;
                        }
                        lb.samplePlayhead = juce::jlimit (0.0, (double) (totalSamp - 1), lb.samplePlayhead);
                    }
                    else // "oneshot"
                    {
                        lb.samplePlayhead = juce::jlimit (0.0, (double) (totalSamp - 1), lb.samplePlayhead);
                    }

                    // --- Get amplitude at playhead (linear interpolation) ---
                    int pos = (int) lb.samplePlayhead;
                    float frac = (float) (lb.samplePlayhead - (double) pos);
                    int pos1 = juce::jlimit (0, totalSamp - 1, pos + 1);
                    pos = juce::jlimit (0, totalSamp - 1, pos);
                    float s0 = sd->buffer.getSample (0, pos);
                    float s1 = sd->buffer.getSample (0, pos1);
                    float raw = std::abs (s0 + frac * (s1 - s0)) * (lb.envSens / 50.0f);

                    // --- Attack/release envelope smoothing ---
                    float ac = std::exp (-1.0f / std::max (1.0f, lb.envAtk * 0.001f * bufferRate));
                    float rc = std::exp (-1.0f / std::max (1.0f, lb.envRel * 0.001f * bufferRate));
                    if (raw > lb.currentEnvValue)
                        lb.currentEnvValue = ac * lb.currentEnvValue + (1.0f - ac) * raw;
                    else
                        lb.currentEnvValue = rc * lb.currentEnvValue + (1.0f - rc) * raw;

                    float cl = juce::jlimit (0.0f, 1.0f, lb.currentEnvValue);
                    float mp = lb.envInvert ? (1.0f - cl) : cl;

                    if (lb.rangeModeE == RangeMode::Relative)
                    {
                        // Relative mode: offset from the parameter's resting value
                        auto n = lb.targets.size();
                        if (lb.targetBaseValues.size() != n)
                        {
                            lb.targetBaseValues.resize (n);
                            lb.targetLastWritten.resize (n, -1.0f);
                            for (size_t ti = 0; ti < n; ++ti)
                                lb.targetBaseValues[ti] = getParamValue (lb.targets[ti].pluginId, lb.targets[ti].paramIndex);
                        }

                        float depth = lb.rMax;
                        bool envIdle = cl < 0.005f;

                        for (size_t ti = 0; ti < n; ++ti)
                        {
                            // Only update base when envelope is idle
                            if (envIdle)
                            {
                                float cur = getParamValue (lb.targets[ti].pluginId, lb.targets[ti].paramIndex);
                                int _sl = slotForId (lb.targets[ti].pluginId);
                                float _pw = (_sl >= 0 && lb.targets[ti].paramIndex < kMaxParams) ? paramWritten[_sl][lb.targets[ti].paramIndex] : -1.0f;
                                if (_pw > -0.5f && std::abs (cur - _pw) > 0.005f)
                                    lb.targetBaseValues[ti] = cur;
                                else if (_pw < -0.5f && lb.targetLastWritten[ti] >= 0.0f && std::abs (cur - lb.targetLastWritten[ti]) > 0.005f)
                                    lb.targetBaseValues[ti] = cur;
                            }

                            float base = lb.targetBaseValues[ti];

                            // Compute offset based on polarity setting
                            // Sample is a unipolar source (0..1)
                            float offset;
                            if (lb.polarityE == Polarity::Up)
                                offset = mp * depth;                    // 0..+depth
                            else if (lb.polarityE == Polarity::Down)
                                offset = -mp * depth;                   // 0..-depth
                            else
                                offset = (mp * 2.0f - 1.0f) * depth;    // bipolar: -depth..+depth

                            float mapped = juce::jlimit (0.0f, 1.0f, base + offset);
                            setParamDirect (lb.targets[ti].pluginId, lb.targets[ti].paramIndex, mapped);
                            lb.targetLastWritten[ti] = mapped;
                            { int _s = slotForId (lb.targets[ti].pluginId); if (_s >= 0 && lb.targets[ti].paramIndex < kMaxParams) paramWritten[_s][lb.targets[ti].paramIndex] = mapped; }
                        }
                    }
                    else
                    {
                        // Absolute mode: amplitude maps directly to [rMin, rMax]
                        float mapped = lb.rMin + mp * (lb.rMax - lb.rMin);
                        for (const auto& tgt : lb.targets)
                            setParamDirect (tgt.pluginId, tgt.paramIndex, juce::jlimit (0.0f, 1.0f, mapped));
                    }

                    // Write envelope level for UI readback (shares env readback)
                    if (envIdx < maxEnvReadback)
                    {
                        envReadback[envIdx].blockId.store (lb.id);
                        envReadback[envIdx].level.store (cl);
                        envIdx++;
                    }

                    // Write playhead position for UI
                    if (smpIdx < maxSampleReadback)
                    {
                        sampleReadback[smpIdx].blockId.store (lb.id);
                        sampleReadback[smpIdx].playhead.store ((float) (lb.samplePlayhead / (double) totalSamp));
                        smpIdx++;
                    }
                }

                // ===== MORPH PAD MODE =====
                else if (lb.modeE == BlockMode::MorphPad && !lb.snapshots.empty() && lb.enabled)
                {
                    float targetX = lb.playheadX;
                    float targetY = lb.playheadY;

                    // -- Trigger detection (for trigger mode) --
                    bool shouldTrigger = false;
                    if (lb.morphModeE == MorphMode::Trigger)
                    {
                        juce::String src = lb.morphSource;

                        if (src == "midi" && ! blockMidiEvents.empty()) {
                            for (const auto& ev : blockMidiEvents) {
                                if (lb.midiCh > 0 && ev.ch != lb.midiCh) continue;
                                if (lb.midiModeE == MidiTrigMode::AnyNote && ! ev.isCC) { shouldTrigger = true; break; }
                                if (lb.midiModeE == MidiTrigMode::SpecificNote && ! ev.isCC && ev.note == lb.midiNote) { shouldTrigger = true; break; }
                                if (lb.midiModeE == MidiTrigMode::CC && ev.isCC && ev.note == lb.midiCC) { shouldTrigger = true; break; }
                            }
                        }
                        if (src == "tempo" && playing) {
                            float bpt = lb.beatDivBeats;
                            int currentBeat = (int) std::floor (ppq / bpt);
                            if (lb.lastBeat < 0) lb.lastBeat = currentBeat;
                            if (currentBeat != lb.lastBeat) { lb.lastBeat = currentBeat; shouldTrigger = true; }
                        }
                        if (src == "audio") {
                            float audioLvl = (lb.audioSrcE == AudioSource::Sidechain) ? scRms : mainRms;
                            float threshLin = std::pow (10.0f, lb.threshold / 20.0f);
                            double cooldownSamples = currentSampleRate * 0.1;
                            if (audioLvl > threshLin && (sampleCounter - lb.lastAudioTrigSample) > cooldownSamples) {
                                lb.lastAudioTrigSample = sampleCounter;
                                shouldTrigger = true;
                            }
                        }
                    }

                    // -- Auto-Explore mode --
                    if (lb.morphModeE == MorphMode::Auto)
                    {
                        int numSnaps = (int) lb.snapshots.size();

                        // -- CORRECT time computation --
                        // secsPerBuffer = actual wall-clock seconds this buffer covers
                        float secsPerBuffer = (float) numSamples / (float) currentSampleRate;
                        float cyclesPerSec;

                        if (lb.morphTempoSync)
                        {
                            double bpm = (lb.clockSourceE == ClockSource::Internal) ? (double) lb.internalBpm : currentBpm.load();
                            if (bpm > 0.0)
                            {
                                float divBeats = lb.morphSyncDivBeats;
                                double beatsPerSec = bpm / 60.0;
                                cyclesPerSec = (float) (beatsPerSec / divBeats);
                            }
                            else
                            {
                                cyclesPerSec = 0.5f; // fallback if no BPM
                            }
                        }
                        else
                        {
                            // morphSpeed 0..1 â†’ 0.02 Hz .. 4 Hz
                            float sp = lb.morphSpeed;
                            cyclesPerSec = 0.02f + sp * sp * 4.0f;
                        }

                        // Phase delta per buffer (radians) â€” cap at Ï€ to avoid aliasing
                        float rawPhaseDelta = juce::MathConstants<float>::twoPi * cyclesPerSec * secsPerBuffer;
                        float phaseDelta = std::min (rawPhaseDelta, juce::MathConstants<float>::pi);
                        // Linear speed: pad-diameters per second â†’ distance this buffer
                        float linearDelta = cyclesPerSec * secsPerBuffer;

                        // Unified linear speed matching LFO circle tangential velocity:
                        // LFO circle radius = 0.4, tangential speed = 2Ï€ * r * cps
                        float padSpeed = juce::MathConstants<float>::twoPi * 0.4f * cyclesPerSec; // pad-units/sec
                        float distThisBuffer = padSpeed * secsPerBuffer; // distance to travel this buffer

                        if (lb.exploreModeE == ExploreMode::Wander) {
                            // â”€â”€ Brownian random walk â”€â”€
                            // Acceleration drives direction changes; scaled to padSpeed
                            float accelMag = padSpeed * 6.0f * secsPerBuffer;
                            lb.morphVelX += (audioRandom.nextFloat() - 0.5f) * accelMag;
                            lb.morphVelY += (audioRandom.nextFloat() - 0.5f) * accelMag;

                            // Drag â€” smooth curves with gradual direction changes
                            float drag = std::exp (-3.0f * secsPerBuffer);
                            lb.morphVelX *= drag;
                            lb.morphVelY *= drag;

                            // Clamp velocity to padSpeed (same linear speed as LFO)
                            float velMag = std::sqrt (lb.morphVelX * lb.morphVelX + lb.morphVelY * lb.morphVelY);
                            if (velMag > padSpeed && velMag > 0.0f) {
                                float sc = padSpeed / velMag;
                                lb.morphVelX *= sc;
                                lb.morphVelY *= sc;
                            }

                            // Integrate position
                            targetX = lb.playheadX + lb.morphVelX * secsPerBuffer;
                            targetY = lb.playheadY + lb.morphVelY * secsPerBuffer;

                            // Bounce off circle boundary (radius 0.44)
                            float cdx = targetX - 0.5f, cdy = targetY - 0.5f;
                            float cdist = std::sqrt (cdx * cdx + cdy * cdy);
                            if (cdist > 0.44f && cdist > 0.0f) {
                                float nx = cdx / cdist, ny = cdy / cdist;
                                float dot = lb.morphVelX * nx + lb.morphVelY * ny;
                                if (dot > 0.0f) {
                                    lb.morphVelX -= 2.0f * dot * nx;
                                    lb.morphVelY -= 2.0f * dot * ny;
                                }
                                targetX = 0.5f + nx * 0.43f;
                                targetY = 0.5f + ny * 0.43f;
                            }
                        }
                        else if (lb.exploreModeE == ExploreMode::Bounce) {
                            // â”€â”€ Billiard ball â€” same speed as LFO circle â”€â”€
                            float bdx = std::cos (lb.morphAngle) * distThisBuffer;
                            float bdy = std::sin (lb.morphAngle) * distThisBuffer;
                            targetX = lb.playheadX + bdx;
                            targetY = lb.playheadY + bdy;

                            // Circular boundary reflection
                            float cdx = targetX - 0.5f, cdy = targetY - 0.5f;
                            float cdist = std::sqrt (cdx * cdx + cdy * cdy);
                            if (cdist > 0.44f && cdist > 0.0f) {
                                float bnx = cdx / cdist, bny = cdy / cdist;
                                float dot = std::cos (lb.morphAngle) * bnx + std::sin (lb.morphAngle) * bny;
                                lb.morphAngle = std::atan2 (std::sin (lb.morphAngle) - 2.0f * dot * bny,
                                                            std::cos (lb.morphAngle) - 2.0f * dot * bnx);
                                lb.morphAngle += (audioRandom.nextFloat() - 0.5f) * 0.25f;
                                targetX = 0.5f + bnx * 0.43f;
                                targetY = 0.5f + bny * 0.43f;
                            }
                        }
                        else if (lb.exploreModeE == ExploreMode::Shapes) {
                            lb.morphLfoPhase += phaseDelta;
                            while (lb.morphLfoPhase > juce::MathConstants<float>::twoPi)
                                lb.morphLfoPhase -= juce::MathConstants<float>::twoPi;

                            // Accumulate shape rotation (lfoRotation: -1..+1 â†’ Â±2 rev/sec)
                            float rotSpeed = lb.lfoRotation * 2.0f * juce::MathConstants<float>::twoPi;
                            lb.lfoRotAngle += rotSpeed * secsPerBuffer;
                            while (lb.lfoRotAngle > juce::MathConstants<float>::twoPi)
                                lb.lfoRotAngle -= juce::MathConstants<float>::twoPi;
                            while (lb.lfoRotAngle < -juce::MathConstants<float>::twoPi)
                                lb.lfoRotAngle += juce::MathConstants<float>::twoPi;

                            float t = lb.morphLfoPhase;
                            float twoPi = juce::MathConstants<float>::twoPi;
                            float halfPi = juce::MathConstants<float>::halfPi;
                            // Depth controls shape radius: 0..1 â†’ 0..0.45
                            float R = lb.lfoDepth * 0.45f;

                            // Compute shape position relative to center (dx, dy)
                            float dx = 0.0f, dy = 0.0f;

                            if (lb.lfoShapeE == LfoShape::Circle) {
                                dx = R * std::cos (t);
                                dy = R * std::sin (t);
                            }
                            else if (lb.lfoShapeE == LfoShape::Figure8) {
                                dx = R * std::sin (t);
                                dy = R * std::sin (t * 2.0f);
                            }
                            else if (lb.lfoShapeE == LfoShape::SweepX) {
                                dx = R * std::sin (t);
                                dy = lb.playheadY - 0.5f;
                            }
                            else if (lb.lfoShapeE == LfoShape::SweepY) {
                                dx = lb.playheadX - 0.5f;
                                dy = R * std::sin (t);
                            }
                            // â”€â”€ Geometry â”€â”€
                            else if (lb.lfoShapeE == LfoShape::Triangle || lb.lfoShapeE == LfoShape::Square
                                  || lb.lfoShapeE == LfoShape::Hexagon) {
                                int n = 3;
                                if (lb.lfoShapeE == LfoShape::Square)  n = 4;
                                if (lb.lfoShapeE == LfoShape::Hexagon) n = 6;
                                float segF = t * (float) n / twoPi;
                                int seg = ((int) segF) % n;
                                float segT = segF - std::floor (segF);
                                float a0 = twoPi * seg / (float) n - halfPi;
                                float a1 = twoPi * ((seg + 1) % n) / (float) n - halfPi;
                                dx = R * (std::cos (a0) + segT * (std::cos (a1) - std::cos (a0)));
                                dy = R * (std::sin (a0) + segT * (std::sin (a1) - std::sin (a0)));
                            }
                            else if (lb.lfoShapeE == LfoShape::Pentagram) {
                                constexpr int n = 5;
                                constexpr int order[5] = { 0, 2, 4, 1, 3 };
                                float segF = t * (float) n / twoPi;
                                int seg = ((int) segF) % n;
                                float segT = segF - std::floor (segF);
                                int from = order[seg], to = order[(seg + 1) % n];
                                float a0 = twoPi * from / (float) n - halfPi;
                                float a1 = twoPi * to / (float) n - halfPi;
                                dx = R * (std::cos (a0) + segT * (std::cos (a1) - std::cos (a0)));
                                dy = R * (std::sin (a0) + segT * (std::sin (a1) - std::sin (a0)));
                            }
                            else if (lb.lfoShapeE == LfoShape::Hexagram) {
                                // Star of David: two overlapping triangles
                                constexpr int hexOrder[6] = {0,3,1,4,2,5};
                                float segF = t * 6.0f / twoPi;
                                int seg = ((int) segF) % 6;
                                float segT = segF - std::floor (segF);
                                int fromIdx = hexOrder[seg], toIdx = hexOrder[(seg+1)%6];
                                float aFrom = twoPi * fromIdx / 6.0f - halfPi;
                                float aTo   = twoPi * toIdx   / 6.0f - halfPi;
                                dx = R * (std::cos (aFrom) + segT * (std::cos (aTo) - std::cos (aFrom)));
                                dy = R * (std::sin (aFrom) + segT * (std::sin (aTo) - std::sin (aFrom)));
                            }
                            else if (lb.lfoShapeE == LfoShape::Rose4) {
                                float r = R * std::abs (std::cos (2.0f * t));
                                dx = r * std::cos (t);
                                dy = r * std::sin (t);
                            }
                            else if (lb.lfoShapeE == LfoShape::Lissajous) {
                                dx = R * std::sin (3.0f * t);
                                dy = R * std::sin (2.0f * t);
                            }
                            else if (lb.lfoShapeE == LfoShape::Spiral) {
                                float progress = t / twoPi;
                                float rNorm = (progress < 0.5f)
                                    ? progress * 2.0f
                                    : (1.0f - progress) * 2.0f;
                                float spiralR = R * (0.05f + 0.95f * rNorm);
                                float spiralAngle = t * 3.0f;
                                dx = spiralR * std::cos (spiralAngle);
                                dy = spiralR * std::sin (spiralAngle);
                            }
                            else {
                                dx = R * std::cos (t);
                                dy = R * std::sin (t);
                            }

                            // Apply shape rotation (rotate dx,dy around center)
                            if (std::abs (lb.lfoRotAngle) > 0.0001f) {
                                float cosR = std::cos (lb.lfoRotAngle);
                                float sinR = std::sin (lb.lfoRotAngle);
                                float rx = dx * cosR - dy * sinR;
                                float ry = dx * sinR + dy * cosR;
                                dx = rx;
                                dy = ry;
                            }

                            targetX = 0.5f + dx;
                            targetY = 0.5f + dy;
                        }
                        else if (lb.exploreModeE == ExploreMode::Orbit && numSnaps > 0) {
                            lb.morphOrbitPhase += phaseDelta;
                            while (lb.morphOrbitPhase > juce::MathConstants<float>::twoPi) {
                                lb.morphOrbitPhase -= juce::MathConstants<float>::twoPi;
                                lb.morphOrbitTarget = (lb.morphOrbitTarget + 1) % numSnaps;
                            }
                            int ot = lb.morphOrbitTarget % numSnaps;
                            float orbitR = 0.12f;
                            targetX = lb.snapshots[ot].x + orbitR * std::cos (lb.morphOrbitPhase);
                            targetY = lb.snapshots[ot].y + orbitR * std::sin (lb.morphOrbitPhase);
                        }
                        else if (lb.exploreModeE == ExploreMode::Path && numSnaps > 1) {
                            // Path speed: traverse one segment in the same time
                            // as one LFO revolution
                            lb.morphPathProgress += cyclesPerSec * secsPerBuffer;
                            if (lb.morphPathProgress >= 1.0f) {
                                lb.morphPathProgress -= 1.0f;
                                lb.morphPathIndex = (lb.morphPathIndex + 1) % numSnaps;
                            }
                            int curr = lb.morphPathIndex % numSnaps;
                            int next = (lb.morphPathIndex + 1) % numSnaps;
                            float t = lb.morphPathProgress;
                            t = t * t * (3.0f - 2.0f * t); // smoothstep
                            targetX = lb.snapshots[curr].x + t * (lb.snapshots[next].x - lb.snapshots[curr].x);
                            targetY = lb.snapshots[curr].y + t * (lb.snapshots[next].y - lb.snapshots[curr].y);
                        }

                        // Final circular clamp (all explore modes)
                        float fcx = targetX - 0.5f, fcy = targetY - 0.5f;
                        float fcd = std::sqrt (fcx * fcx + fcy * fcy);
                        if (fcd > 0.45f) { float s = 0.45f / fcd; targetX = 0.5f + fcx * s; targetY = 0.5f + fcy * s; }

                        lb.playheadX = targetX;
                        lb.playheadY = targetY;
                    }

                    // -- Trigger mode: apply jump/step on trigger --
                    if (lb.morphModeE == MorphMode::Trigger && shouldTrigger)
                    {
                        int numSnaps = (int) lb.snapshots.size();
                        if (lb.morphActionE == MorphAction::Jump) {
                            int ri = audioRandom.nextInt (numSnaps);
                            targetX = lb.snapshots[ri].x;
                            targetY = lb.snapshots[ri].y;
                        } else if (lb.morphActionE == MorphAction::Step) {
                            if (lb.stepOrderE == StepOrder::Cycle)
                                lb.morphStepIndex = (lb.morphStepIndex + 1) % numSnaps;
                            else
                                lb.morphStepIndex = audioRandom.nextInt (numSnaps);
                            targetX = lb.snapshots[lb.morphStepIndex].x;
                            targetY = lb.snapshots[lb.morphStepIndex].y;
                        }
                        lb.playheadX = targetX;
                        lb.playheadY = targetY;

                        // Fire trigger notification to UI
                        const auto tScope = triggerFifo.write (1);
                        if (tScope.blockSize1 > 0)      triggerRing[tScope.startIndex1] = lb.id;
                        else if (tScope.blockSize2 > 0) triggerRing[tScope.startIndex2] = lb.id;
                    }

                    // -- Apply jitter --
                    float finalX = lb.playheadX;
                    float finalY = lb.playheadY;
                    if (lb.jitter > 0.001f) {
                        finalX += (audioRandom.nextFloat() - 0.5f) * lb.jitter * 0.2f;
                        finalY += (audioRandom.nextFloat() - 0.5f) * lb.jitter * 0.2f;
                        // Circular clamp
                        float jdx = finalX - 0.5f, jdy = finalY - 0.5f;
                        float jd = std::sqrt (jdx * jdx + jdy * jdy);
                        if (jd > 0.45f) { float js = 0.45f / jd; finalX = 0.5f + jdx * js; finalY = 0.5f + jdy * js; }
                    }

                    // -- Smooth playhead (glide) --
                    // Auto-explore modes produce continuous motion â€” pass through directly.
                    // Only trigger/manual modes need glide smoothing (discrete jumps).
                    if (lb.morphModeE == MorphMode::Auto) {
                        lb.morphSmoothX = finalX;
                        lb.morphSmoothY = finalY;
                    } else {
                        float glideTimeSec = std::max (0.001f, lb.morphGlide * 0.001f);
                        float secsThisBuffer = (float) numSamples / (float) currentSampleRate;
                        float glideCoeff = std::exp (-secsThisBuffer / glideTimeSec);
                        lb.morphSmoothX = glideCoeff * lb.morphSmoothX + (1.0f - glideCoeff) * finalX;
                        lb.morphSmoothY = glideCoeff * lb.morphSmoothY + (1.0f - glideCoeff) * finalY;
                    }

                    // Snap to target when close enough â€” prevents asymptotic residual
                    // from keeping IDW firing indefinitely
                    if (std::abs (lb.morphSmoothX - finalX) < 1e-5f) lb.morphSmoothX = finalX;
                    if (std::abs (lb.morphSmoothY - finalY) < 1e-5f) lb.morphSmoothY = finalY;

                    // -- Only apply IDW when the smoothed playhead has actually moved --
                    // This prevents constant parameter overwrites when the dot is stationary,
                    // allowing the user to manually tweak hosted plugin parameters.
                    float dsx = lb.morphSmoothX - lb.prevAppliedX;
                    float dsy = lb.morphSmoothY - lb.prevAppliedY;
                    if (dsx * dsx + dsy * dsy > 1e-6f)
                    {
                        lb.prevAppliedX = lb.morphSmoothX;
                        lb.prevAppliedY = lb.morphSmoothY;

                        // -- IDW Interpolation with exact radius boundary --
                        // snapRadius is the actual distance (0.05..1.0) in pad coordinates.
                        // Weight = (1 - dist/radius)^2 â€” drops to exactly zero at boundary.
                        float radius = lb.snapRadius;
                        float weights[12] = {};
                        int numSnaps = juce::jmin ((int) lb.snapshots.size(), 12);
                        float totalWeight = 0.0f;
                        for (int si = 0; si < numSnaps; ++si) {
                            float dx = lb.morphSmoothX - lb.snapshots[si].x;
                            float dy = lb.morphSmoothY - lb.snapshots[si].y;
                            float dist = std::sqrt (dx * dx + dy * dy);
                            float w = 0.0f;
                            if (dist < radius) {
                                float t = 1.0f - dist / radius;
                                w = t * t;  // quadratic: smooth at center, zero at boundary
                            }
                            weights[si] = w;
                            totalWeight += w;
                        }
                        if (totalWeight > 0.0f)
                        {
                            for (int si = 0; si < numSnaps; ++si) weights[si] /= totalWeight;

                            // -- Mix target values and apply --
                            for (size_t ti = 0; ti < lb.targets.size(); ++ti) {
                                float mixed = 0.0f;
                                for (int si = 0; si < numSnaps; ++si) {
                                    if (ti < lb.snapshots[si].targetValues.size())
                                        mixed += weights[si] * lb.snapshots[si].targetValues[ti];
                                }
                                mixed = juce::jlimit (0.0f, 1.0f, mixed);
                                setParamDirect (lb.targets[ti].pluginId, lb.targets[ti].paramIndex, mixed);
                            }
                        }
                    }

                    // -- Write playhead readback for UI --
                    if (morphIdx < maxMorphReadback) {
                        // Circular clamp before sending to UI (r=0.45)
                        float rbX = lb.morphSmoothX, rbY = lb.morphSmoothY;
                        float rbdx = rbX - 0.5f, rbdy = rbY - 0.5f;
                        float rbd = std::sqrt (rbdx * rbdx + rbdy * rbdy);
                        if (rbd > 0.45f) { float rbs = 0.45f / rbd; rbX = 0.5f + rbdx * rbs; rbY = 0.5f + rbdy * rbs; }
                        morphReadback[morphIdx].blockId.store (lb.id);
                        morphReadback[morphIdx].headX.store (rbX);
                        morphReadback[morphIdx].headY.store (rbY);
                        morphReadback[morphIdx].rotAngle.store (lb.lfoRotAngle);
                        morphIdx++;
                    }
                }

                // ===== SHAPES BLOCK (including shapes_range) =====
                else if ((lb.modeE == BlockMode::Shapes || lb.modeE == BlockMode::ShapesRange) && lb.enabled && !lb.targets.empty())
                {
                    float twoPi = juce::MathConstants<float>::twoPi;
                    float halfPi = juce::MathConstants<float>::halfPi;
                    float secsPerBuffer = (float) numSamples / (float) currentSampleRate;
                    // MIDI retrigger: reset phase on note-on
                    if (lb.shapeTriggerE == ShapeTrigger::Midi && ! blockMidiEvents.empty())
                    {
                        for (const auto& ev : blockMidiEvents)
                        {
                            if (! ev.isCC) { lb.shapePhase = 0.0f; break; }
                        }
                    }

                    // Advance phase based on speed
                    float speedHz;
                    // Determine effective BPM from chosen clock source
                    float effectiveBpm = (lb.clockSourceE == ClockSource::Internal) ? lb.internalBpm : (float) currentBpm.load();
                    if (lb.shapeTempoSync && effectiveBpm > 0.0f)
                    {
                        float beatsPerCycle = lb.shapeSyncDivBeats;
                        float secsPerCycle = beatsPerCycle * 60.0f / effectiveBpm;
                        speedHz = 1.0f / std::max(0.001f, secsPerCycle);
                    }
                    else
                    {
                        speedHz = 0.02f + lb.shapeSpeed * lb.shapeSpeed * lb.shapeSpeed * 4.98f; // exponential: 0.02â€“5 Hz, most range in slow end
                    }
                    float phaseDelta = speedHz * twoPi * secsPerBuffer;
                    lb.shapePhase += phaseDelta;
                    while (lb.shapePhase > twoPi) lb.shapePhase -= twoPi;

                    // Accumulate spin (exponential: gentle near center, fast at extremes)
                    float spinNorm = lb.shapeSpin; // -1..+1
                    float spinExp = spinNorm * spinNorm * (spinNorm > 0 ? 1.0f : -1.0f); // preserve sign, square magnitude
                    float spinSpeed = spinExp * 2.0f * twoPi;
                    lb.shapeRotAngle += spinSpeed * secsPerBuffer;
                    while (lb.shapeRotAngle > twoPi) lb.shapeRotAngle -= twoPi;
                    while (lb.shapeRotAngle < -twoPi) lb.shapeRotAngle += twoPi;

                    float t = lb.shapePhase;
                    // shapes_range always uses max size
                    float effectiveSize = (lb.modeE == BlockMode::ShapesRange) ? 1.0f : lb.shapeSize;
                    float R = effectiveSize * 0.48f;
                    float dx = 0.0f, dy = 0.0f;

                    // â”€â”€ Shape computation (same math as morph pad shapes engine) â”€â”€
                    if (lb.shapeTypeE == LfoShape::Circle) {
                        dx = R * std::cos(t); dy = R * std::sin(t);
                    } else if (lb.shapeTypeE == LfoShape::Figure8) {
                        dx = R * std::sin(t); dy = R * std::sin(t * 2.0f);
                    } else if (lb.shapeTypeE == LfoShape::SweepX) {
                        dx = R * std::sin(t); dy = 0.0f;
                    } else if (lb.shapeTypeE == LfoShape::SweepY) {
                        dx = 0.0f; dy = R * std::sin(t);
                    } else if (lb.shapeTypeE == LfoShape::Triangle || lb.shapeTypeE == LfoShape::Square || lb.shapeTypeE == LfoShape::Hexagon) {
                        int n = (lb.shapeTypeE == LfoShape::Triangle) ? 3 : (lb.shapeTypeE == LfoShape::Square) ? 4 : 6;
                        float segF = t * (float)n / twoPi;
                        int seg = ((int)segF) % n;
                        float segT = segF - std::floor(segF);
                        float a0 = twoPi * seg / (float)n - halfPi;
                        float a1 = twoPi * ((seg + 1) % n) / (float)n - halfPi;
                        dx = R * (std::cos(a0) + segT * (std::cos(a1) - std::cos(a0)));
                        dy = R * (std::sin(a0) + segT * (std::sin(a1) - std::sin(a0)));
                    } else if (lb.shapeTypeE == LfoShape::Pentagram) {
                        constexpr int order[5] = {0,2,4,1,3};
                        float segF = t * 5.0f / twoPi;
                        int seg = ((int)segF) % 5;
                        float segT = segF - std::floor(segF);
                        int from = order[seg], to = order[(seg+1)%5];
                        float a0 = twoPi * from / 5.0f - halfPi;
                        float a1 = twoPi * to / 5.0f - halfPi;
                        dx = R * (std::cos(a0) + segT * (std::cos(a1) - std::cos(a0)));
                        dy = R * (std::sin(a0) + segT * (std::sin(a1) - std::sin(a0)));
                    } else if (lb.shapeTypeE == LfoShape::Hexagram) {
                        // Star of David: two overlapping triangles
                        // 6 vertices evenly spaced, traced in order 0,3,1,4,2,5
                        constexpr int hexOrder[6] = {0,3,1,4,2,5};
                        float segF = t * 6.0f / twoPi;
                        int seg = ((int)segF) % 6;
                        float segT = segF - std::floor(segF);
                        int fromIdx = hexOrder[seg], toIdx = hexOrder[(seg+1)%6];
                        float aFrom = twoPi * fromIdx / 6.0f - halfPi;
                        float aTo   = twoPi * toIdx   / 6.0f - halfPi;
                        dx = R * (std::cos(aFrom) + segT * (std::cos(aTo) - std::cos(aFrom)));
                        dy = R * (std::sin(aFrom) + segT * (std::sin(aTo) - std::sin(aFrom)));
                    } else if (lb.shapeTypeE == LfoShape::Rose4) {
                        float r = R * std::abs(std::cos(2.0f * t));
                        dx = r * std::cos(t); dy = r * std::sin(t);
                    } else if (lb.shapeTypeE == LfoShape::Lissajous) {
                        dx = R * std::sin(3.0f * t); dy = R * std::sin(2.0f * t);
                    } else if (lb.shapeTypeE == LfoShape::Spiral) {
                        float progress = t / twoPi;
                        float rNorm = progress < 0.5f ? progress * 2.0f : (1.0f - progress) * 2.0f;
                        float sR = R * (0.05f + 0.95f * rNorm);
                        float sA = t * 3.0f;
                        dx = sR * std::cos(sA); dy = sR * std::sin(sA);
                    } else {
                        dx = R * std::cos(t); dy = R * std::sin(t);
                    }

                    // Apply spin rotation
                    if (std::abs(lb.shapeRotAngle) > 0.0001f) {
                        float cosR = std::cos(lb.shapeRotAngle);
                        float sinR = std::sin(lb.shapeRotAngle);
                        float rx = dx * cosR - dy * sinR;
                        float ry = dx * sinR + dy * cosR;
                        dx = rx; dy = ry;
                    }

                    // â”€â”€ Tracking: reduce 2D â†’ 1D â”€â”€
                    float normR = std::max(R, 0.001f);
                    float output = 0.0f;
                    if (lb.shapeTrackingE == ShapeTracking::Horizontal) {
                        output = dx / normR; // -1..+1
                    } else if (lb.shapeTrackingE == ShapeTracking::Vertical) {
                        output = dy / normR; // -1..+1
                    } else { // "distance"
                        output = std::sqrt(dx*dx + dy*dy) / normR; // 0..+1
                    }

                    // Apply polarity â€” compute modVal per-target for shapes_range
                    bool isShapesRange = (lb.modeE == BlockMode::ShapesRange);

                    // â”€â”€ Apply to targets â”€â”€
                    auto n = lb.targets.size();
                    if (lb.targetBaseValues.size() != n)
                    {
                        lb.targetBaseValues.resize (n);
                        lb.targetLastWritten.resize (n, -1.0f);
                        for (size_t ti = 0; ti < n; ++ti)
                        {
                            // shapes_range: use JS-supplied base values (anchor positions)
                            if (isShapesRange && ti < lb.targetRangeBaseValues.size())
                                lb.targetBaseValues[ti] = lb.targetRangeBaseValues[ti];
                            else
                                lb.targetBaseValues[ti] = getParamValue (lb.targets[ti].pluginId, lb.targets[ti].paramIndex);
                        }
                    }

                    // Rate-correct smoothing coefficient for ~80ms ramp
                    float rampCoeff = 1.0f - std::exp (-secsPerBuffer / 0.08f);

                    for (size_t ti = 0; ti < n; ++ti)
                    {
                        // Per-param depth: use targetRangeValues for shapes_range, else global shapeDepth
                        float targetDepth = isShapesRange
                            ? (ti < lb.targetRangeValues.size() ? lb.targetRangeValues[ti] : 0.0f)
                            : lb.shapeDepth;

                        // Soft-engage: smoothly ramp effective depth to prevent jumps
                        float depth;
                        if (isShapesRange)
                        {
                            if (lb.smoothedRangeValues.size() <= ti)
                                lb.smoothedRangeValues.resize (ti + 1, 0.0f);

                            float prevSmoothed = lb.smoothedRangeValues[ti];
                            lb.smoothedRangeValues[ti] += rampCoeff * (targetDepth - lb.smoothedRangeValues[ti]);
                            depth = lb.smoothedRangeValues[ti];

                            // Recapture base when modulation first engages (0 → non-zero)
                            if (std::abs (prevSmoothed) < 0.001f && std::abs (depth) >= 0.001f)
                                lb.targetBaseValues[ti] = getParamValue (lb.targets[ti].pluginId, lb.targets[ti].paramIndex);
                        }
                        else
                        {
                            // Regular shapes: ramp shapeDepth with soft-engage
                            float prevSD = lb.smoothedShapeDepth;
                            lb.smoothedShapeDepth += rampCoeff * (targetDepth - lb.smoothedShapeDepth);
                            depth = lb.smoothedShapeDepth;

                            // Recapture base when modulation first engages
                            if (ti == 0 && std::abs (prevSD) < 0.001f && std::abs (depth) >= 0.001f)
                            {
                                for (size_t ri = 0; ri < n; ++ri)
                                    lb.targetBaseValues[ri] = getParamValue (lb.targets[ri].pluginId, lb.targets[ri].paramIndex);
                            }
                        }

                        float modVal = 0.0f;
                        if (lb.shapePolarityE == Polarity::Bipolar) {
                            modVal = output * std::abs(depth);
                        } else if (lb.shapePolarityE == Polarity::Unipolar) {
                            float norm = (lb.shapeTrackingE == ShapeTracking::Distance) ? output : (output + 1.0f) * 0.5f;
                            modVal = norm * depth;
                        } else if (lb.shapePolarityE == Polarity::Up) {
                            float norm = (lb.shapeTrackingE == ShapeTracking::Distance) ? output : (output + 1.0f) * 0.5f;
                            modVal = norm * std::abs(depth);
                        } else { // "down"
                            float norm = (lb.shapeTrackingE == ShapeTracking::Distance) ? output : (output + 1.0f) * 0.5f;
                            modVal = -norm * std::abs(depth);
                        }
                        float newVal;
                        if (lb.shapeRangeE == RangeMode::Relative)
                        {
                            // For shapes_range, JS tracks the base explicitly — don't recapture
                            if (!isShapesRange)
                            {
                                float cur = getParamValue (lb.targets[ti].pluginId, lb.targets[ti].paramIndex);
                                int _sl = slotForId (lb.targets[ti].pluginId);
                                float _pw = (_sl >= 0 && lb.targets[ti].paramIndex < kMaxParams) ? paramWritten[_sl][lb.targets[ti].paramIndex] : -1.0f;
                                if (_pw > -0.5f && std::abs (cur - _pw) > 0.02f)
                                    lb.targetBaseValues[ti] = cur;
                                else if (_pw < -0.5f && lb.targetLastWritten[ti] >= 0.0f && std::abs (cur - lb.targetLastWritten[ti]) > 0.02f)
                                    lb.targetBaseValues[ti] = cur;
                            }

                            float base = lb.targetBaseValues[ti];
                            newVal = juce::jlimit (0.0f, 1.0f, base + modVal);
                        }
                        else
                        {
                            newVal = juce::jlimit (0.0f, 1.0f, 0.5f + modVal);
                        }

                        setParamDirect (lb.targets[ti].pluginId, lb.targets[ti].paramIndex, newVal);
                        lb.targetLastWritten[ti] = newVal;
                        { int _s = slotForId (lb.targets[ti].pluginId); if (_s >= 0 && lb.targets[ti].paramIndex < kMaxParams) paramWritten[_s][lb.targets[ti].paramIndex] = newVal; }
                    }

                    // -- Write dot readback for UI --
                    if (morphIdx < maxMorphReadback) {
                        float dotX = 0.5f + dx, dotY = 0.5f + dy;
                        morphReadback[morphIdx].blockId.store(lb.id);
                        morphReadback[morphIdx].headX.store(dotX);
                        morphReadback[morphIdx].headY.store(dotY);
                        morphReadback[morphIdx].rotAngle.store(lb.shapeRotAngle);
                        morphIdx++;
                    }
                }
                // ===== LANE CLIPS =====
                else if (lb.modeE == BlockMode::Lane && lb.enabled && !lb.laneClips.empty())
                {
                    float secsPerBuffer = (float) numSamples / (float) currentSampleRate;
                    int laneIdx = 0;

                    for (auto& lc : lb.laneClips)
                    {
                        if (lc.muted || lc.pts.empty()) continue;

                        // Calculate loop duration in seconds
                        float loopSecs;
                        if (lc.loopLenFree)
                        {
                            loopSecs = std::max(0.1f, lc.freeSecs);
                        }
                        else
                        {
                            float loopBeats = 4.0f;
                            loopBeats = lc.loopLenBeats;

                            float bpm = (lc.synced && lb.clockSourceE != ClockSource::Internal)
                                ? (float) currentBpm.load()
                                : lb.internalBpm;
                            if (bpm <= 0.0f) bpm = 120.0f;
                            loopSecs = loopBeats * 60.0f / bpm;
                        }

                        float playDelta = secsPerBuffer / std::max(0.001f, loopSecs);

                        // Playhead modes
                        if (lc.playModeE == LanePlayMode::Reverse)
                        {
                            lc.playhead -= playDelta;
                            while (lc.playhead < 0.0) lc.playhead += 1.0;
                        }
                        else if (lc.playModeE == LanePlayMode::Pingpong)
                        {
                            lc.playhead += playDelta * lc.direction;
                            if (lc.playhead >= 1.0) { lc.playhead = 2.0 - lc.playhead; lc.direction = -1; }
                            if (lc.playhead <= 0.0) { lc.playhead = -lc.playhead; lc.direction = 1; }
                            lc.playhead = juce::jlimit(0.0, 1.0, lc.playhead);
                        }
                        else if (lc.playModeE == LanePlayMode::Random)
                        {
                            lc.playhead += playDelta;
                            if (lc.playhead >= 1.0) { lc.playhead = audioRandom.nextFloat(); }
                        }
                        else // "forward"
                        {
                            lc.playhead += playDelta;
                            while (lc.playhead >= 1.0) lc.playhead -= 1.0;
                        }

                        // Apply phase offset only (slew is now output smoothing, not position shift)
                        float pos = (float) lc.playhead + lc.phase;
                        while (pos >= 1.0f) pos -= 1.0f;
                        while (pos < 0.0f) pos += 1.0f;

                        // Evaluate curve at position
                        float value = 0.5f;
                        auto& pts = lc.pts;
                        int n = (int) pts.size();

                        if (n == 1)
                        {
                            value = pts[0].y;
                        }
                        else if (pos <= pts[0].x)
                        {
                            value = pts[0].y;
                        }
                        else if (pos >= pts[n - 1].x)
                        {
                            value = pts[n - 1].y;
                        }
                        else
                        {
                            int seg = 0;
                            for (int si = 0; si < n - 1; ++si)
                            {
                                if (pos >= pts[si].x && pos < pts[si + 1].x)
                                { seg = si; break; }
                            }
                            float x0 = pts[seg].x, x1 = pts[seg + 1].x;
                            float y0 = pts[seg].y, y1 = pts[seg + 1].y;
                            float t = (x1 > x0) ? (pos - x0) / (x1 - x0) : 0.0f;

                            if (lc.interpE == LaneInterp::Step)
                                value = y0;
                            else if (lc.interpE == LaneInterp::Smooth)
                            {
                                float ts = t * t * (3.0f - 2.0f * t);
                                value = y0 + (y1 - y0) * ts;
                            }
                            else
                                value = y0 + (y1 - y0) * t;
                        }

                        // y=0 top → param=1, y=1 bottom → param=0
                        float paramVal = 1.0f - value;

                        // Depth: scale toward center (0.5)
                        paramVal = 0.5f + (paramVal - 0.5f) * lc.depth;

                        // Warp: S-curve contrast (tanh waveshaping), bipolar
                        if (std::abs(lc.warp) > 0.001f)
                        {
                            float k = 1.0f + std::abs(lc.warp) * 8.0f;
                            float centered = (paramVal - 0.5f) * 2.0f;
                            float shaped = std::tanh(centered * k) / std::tanh(k);
                            float warped = shaped * 0.5f + 0.5f;
                            if (lc.warp > 0.0f)
                                paramVal = warped;
                            else
                                paramVal = paramVal + (0.5f - paramVal) * std::abs(lc.warp);
                        }

                        paramVal = juce::jlimit(0.0f, 1.0f, paramVal);

                        // Slew: directional one-pole smoothing
                        // Positive (+): smooths rising transitions (attack lag)
                        // Negative (-): smooths falling transitions (release lag)
                        // slew is -1..+1 from knob
                        float slewAmt = std::abs(lc.slew);
                        if (slewAmt > 0.001f)
                        {
                            // Exponential mapping: 0→instant, 1→~2s time constant
                            float slewTimeSec = slewAmt * slewAmt * 2.0f;
                            float slewCoeff = std::exp(-secsPerBuffer / std::max(0.001f, slewTimeSec));

                            bool isRising = paramVal > lc.slewState;
                            bool shouldSmooth = (lc.slew > 0.0f) ? isRising : !isRising;

                            if (shouldSmooth)
                                lc.slewState = slewCoeff * lc.slewState + (1.0f - slewCoeff) * paramVal;
                            else
                                lc.slewState = paramVal; // instant in the non-smoothed direction

                            paramVal = juce::jlimit(0.0f, 1.0f, lc.slewState);
                        }
                        else
                        {
                            lc.slewState = paramVal; // track current value for when slew is enabled
                        }

                        for (const auto& tgt : lc.targets)
                        {
                            setParamDirect(tgt.pluginId, tgt.paramIndex, paramVal);
                            { int _s = slotForId(tgt.pluginId); if (_s >= 0 && tgt.paramIndex < kMaxParams) paramWritten[_s][tgt.paramIndex] = paramVal; }
                        }

                        // Write readback for UI
                        int rbIdx = numActiveLanes.load();
                        if (rbIdx < maxLaneReadback)
                        {
                            laneReadback[rbIdx].blockId.store(lb.id);
                            laneReadback[rbIdx].laneIdx.store(laneIdx);
                            laneReadback[rbIdx].playhead.store((float) lc.playhead);
                            laneReadback[rbIdx].value.store(paramVal);
                            numActiveLanes.store(rbIdx + 1);
                        }
                        laneIdx++;
                    }
                }
            }
            numActiveEnvBlocks.store (envIdx);
            numActiveSampleBlocks.store (smpIdx);
            numActiveMorphBlocks.store (morphIdx);
        }
    }

    // â”€â”€ Drain glide command FIFO (lock-free read) â”€â”€
    {
        const auto scope = glideFifo.read (glideFifo.getNumReady());

        auto applyCmd = [this] (const GlideCommand& cmd)
        {
            // O(1) lookup via pluginSlots
            float currentVal = getParamValue (cmd.pluginId, cmd.paramIndex);

            int totalSamples = juce::jmax (1, (int) (cmd.durationMs * 0.001 * currentSampleRate));

            // Check if a glide already exists for this param — update in-place
            for (int gi = 0; gi < numActiveGlides; ++gi)
            {
                auto& g = glidePool[gi];
                if (g.pluginId == cmd.pluginId && g.paramIndex == cmd.paramIndex)
                {
                    g.targetVal  = cmd.targetVal;
                    g.increment  = (cmd.targetVal - g.currentVal) / (float) totalSamples;
                    g.samplesLeft = totalSamples;
                    return;
                }
            }

            // New glide (fixed-size pool, no allocation)
            if (numActiveGlides < kMaxGlides)
            {
                glidePool[numActiveGlides++] = {
                    cmd.pluginId, cmd.paramIndex,
                    currentVal, cmd.targetVal,
                    (cmd.targetVal - currentVal) / (float) totalSamples,
                    totalSamples
                };
            }
        };

        for (int i = 0; i < scope.blockSize1; ++i)
            applyCmd (glideRing[scope.startIndex1 + i]);
        for (int i = 0; i < scope.blockSize2; ++i)
            applyCmd (glideRing[scope.startIndex2 + i]);
    }

    // â”€â”€ Advance active glides (per-buffer interpolation) â”€â”€
    {
        int numSamples = buffer.getNumSamples();

        // Swap-to-end removal: O(1) per removal, no shifting
        for (int gi = 0; gi < numActiveGlides; )
        {
            auto& g = glidePool[gi];
            int advance = juce::jmin (numSamples, g.samplesLeft);
            g.currentVal += g.increment * (float) advance;
            g.samplesLeft -= advance;

            // Snap to target when done
            if (g.samplesLeft <= 0)
                g.currentVal = g.targetVal;

            // Apply to hosted plugin parameter — O(1) slot lookup
            int gSlot = slotForId (g.pluginId);
            if (gSlot >= 0)
            {
                auto* hp = pluginSlots[gSlot];
                if (hp && hp->id == g.pluginId && hp->instance)
                {
                    auto& params = hp->instance->getParameters();
                    if (g.paramIndex >= 0 && g.paramIndex < params.size())
                    {
                        params[g.paramIndex]->setValue (juce::jlimit (0.0f, 1.0f, g.currentVal));
                        recordSelfWrite (g.pluginId, g.paramIndex);
                    }
                }
            }

            if (g.samplesLeft <= 0)
            {
                // Swap with last element and decrement count (O(1) removal)
                glidePool[gi] = glidePool[--numActiveGlides];
                // Don't increment gi — re-check the swapped-in element
            }
            else
            {
                ++gi;
            }
        }
    }

    // ── Crash-protected single-plugin processing (shared by both modes) ──
    // Creates a stereo-only alias buffer so hosted plugins never see sidechain channels.
    auto processOnePlugin = [this, &midiMessages, mainBusChannels] (HostedPlugin& hp, juce::AudioBuffer<float>& buf) -> bool
    {
        if (hp.instance == nullptr || ! hp.prepared || hp.bypassed || hp.crashed)
            return true; // skip = success

        // Create a channel-limited alias (no allocation — just pointers into the existing buffer)
        int pluginChannels = juce::jmin (mainBusChannels, buf.getNumChannels());
        int pluginSamples  = buf.getNumSamples();

        // Build an alias AudioBuffer that references only the main bus channels
        float* channelPtrs[8] = {};
        for (int ch = 0; ch < juce::jmin (pluginChannels, 8); ++ch)
            channelPtrs[ch] = buf.getWritePointer (ch);

        juce::AudioBuffer<float> pluginBuf (channelPtrs, pluginChannels, pluginSamples);

        // Use last bus buffer as scratch for crash rollback (never allocated here)
        auto& rollback = busBuffers[maxBuses - 1];
        int numCh = juce::jmin (pluginChannels, rollback.getNumChannels());
        int numSmp = juce::jmin (pluginSamples, rollback.getNumSamples());
        for (int ch = 0; ch < numCh; ++ch)
            rollback.copyFrom (ch, 0, pluginBuf, ch, 0, numSmp);

        bool ok = false;
        try { ok = sehGuardedProcessBlock (hp.instance.get(), pluginBuf, midiMessages); }
        catch (...) { ok = false; }

        if (! ok)
        {
            hp.crashed = true;
            hp.crashCount++;
            for (int ch = 0; ch < numCh; ++ch)
                pluginBuf.copyFrom (ch, 0, rollback, ch, 0, numSmp);

            CrashEvent ce;
            ce.pluginId = hp.id;
            auto nameStd = hp.name.toStdString();
            std::strncpy (ce.pluginName, nameStd.c_str(), sizeof (ce.pluginName) - 1);
            std::strncpy (ce.reason, "Plugin crashed during audio processing",
                          sizeof (ce.reason) - 1);
            const auto scope = crashFifo.write (1);
            if (scope.blockSize1 > 0) crashRing[scope.startIndex1] = ce;
            else if (scope.blockSize2 > 0) crashRing[scope.startIndex2] = ce;

            // NOTE: LOG_TO_FILE removed — it does disk I/O which blocks the audio thread.
            // The crash FIFO carries the info; the editor drains it and can log if needed.
            return false;
        }

        // NaN/Inf sanitization
        for (int ch = 0; ch < pluginChannels; ++ch)
        {
            auto* data = pluginBuf.getWritePointer (ch);
            for (int s = 0; s < pluginSamples; ++s)
            {
                if (std::isnan (data[s]) || std::isinf (data[s]))
                    data[s] = 0.0f;
            }
        }
        return true;
    };

    // ── Route audio through hosted plugins ──
    // NO LOCK here — removePlugin only nulls the instance (never erases),
    // so the vector is stable. processOnePlugin checks for null instance.
    if (routingMode.load() == 0)
    {
        // SEQUENTIAL: process all plugins in order through the main buffer
        for (auto& hp : hostedPlugins)
            processOnePlugin (*hp, buffer);
    }
    else
    {
        // PARALLEL: group by busId, process each bus independently, sum outputs
        int numChannels = buffer.getNumChannels();
        int numSamples  = buffer.getNumSamples();

        // Discover which buses are active (have at least one non-skipped plugin)
        bool busActive[maxBuses] = {};
        for (auto& hp : hostedPlugins)
        {
            int b = juce::jlimit (0, maxBuses - 2, hp->busId); // clamp, reserve last for rollback
            if (hp->instance && hp->prepared && !hp->bypassed && !hp->crashed)
                busActive[b] = true;
        }

        // Check if any bus has solo enabled
        bool anySolo = false;
        for (int i = 0; i < maxBuses - 1; ++i)
            if (busActive[i] && busSolo[i].load()) anySolo = true;

        // Count effective buses (after mute/solo filtering)
        int effectiveBusCount = 0;
        for (int i = 0; i < maxBuses - 1; ++i)
        {
            if (! busActive[i]) continue;
            if (busMute[i].load()) continue;
            if (anySolo && ! busSolo[i].load()) continue;
            effectiveBusCount++;
        }

        if (effectiveBusCount <= 1)
        {
            // Only one effective bus (or none) — process sequentially, no split/sum overhead
            for (auto& hp : hostedPlugins)
            {
                int b = juce::jlimit (0, maxBuses - 2, hp->busId);
                if (busMute[b].load()) continue;
                if (anySolo && ! busSolo[b].load()) continue;
                processOnePlugin (*hp, buffer);
            }
            // Apply bus volume for the single active bus
            if (effectiveBusCount == 1)
            {
                for (int i = 0; i < maxBuses - 1; ++i)
                {
                    if (! busActive[i]) continue;
                    if (busMute[i].load()) continue;
                    if (anySolo && ! busSolo[i].load()) continue;
                    float vol = busVolume[i].load();
                    if (std::abs (vol - 1.0f) > 0.001f)
                        buffer.applyGain (vol);
                    break;
                }
            }
        }
        else
        {
            // Copy input to each active bus buffer
            for (int b = 0; b < maxBuses - 1; ++b)
            {
                if (! busActive[b]) continue;
                if (busMute[b].load()) continue;
                if (anySolo && ! busSolo[b].load()) continue;
                for (int ch = 0; ch < juce::jmin (numChannels, busBuffers[b].getNumChannels()); ++ch)
                    busBuffers[b].copyFrom (ch, 0, buffer, ch, 0, numSamples);
            }

            // Process each bus's plugin chain
            for (auto& hp : hostedPlugins)
            {
                int b = juce::jlimit (0, maxBuses - 2, hp->busId);
                if (busMute[b].load()) continue;
                if (anySolo && ! busSolo[b].load()) continue;
                processOnePlugin (*hp, busBuffers[b]);
            }

            // Sum all active bus outputs into main buffer — UNITY GAIN
            // Each bus applies its own volume. No automatic gain compensation.
            buffer.clear();
            for (int b = 0; b < maxBuses - 1; ++b)
            {
                if (! busActive[b]) continue;
                if (busMute[b].load()) continue;
                if (anySolo && ! busSolo[b].load()) continue;
                float vol = busVolume[b].load();
                for (int ch = 0; ch < numChannels; ++ch)
                    buffer.addFrom (ch, 0, busBuffers[b], ch, 0, numSamples, vol);
            }
        }
    }

    // ── Snapshot hosted param values → proxy cache (lock-free atomic writes) ──
    // Audio thread writes to atomic cache; message thread timer reads + calls setValueNotifyingHost.
    // This avoids calling setValueNotifyingHost on the audio thread (Rule 6).
    if (++proxySyncCounter >= 4)
    {
        proxySyncCounter = 0;
        bool anyDirty = false;
        for (int i = 0; i < proxyParamCount; ++i)
        {
            auto& m = proxyMap[i];
            if (m.pluginId < 0 || proxyParams[i] == nullptr) continue;

            for (auto& hp : hostedPlugins)
            {
                if (hp->id == m.pluginId && hp->instance)
                {
                    auto& params = hp->instance->getParameters();
                    if (m.paramIndex >= 0 && m.paramIndex < (int) params.size())
                    {
                        float hosted = params[m.paramIndex]->getValue();
                        if (std::abs (hosted - proxyParams[i]->get()) > 0.0001f)
                        {
                            proxyValueCache[i].store (hosted, std::memory_order_relaxed);
                            anyDirty = true;
                        }
                    }
                    break;
                }
            }
        }
        if (anyDirty)
            proxyDirty.store (true, std::memory_order_release);
    }

    // Apply dry/wet mix
    if (needsDryMix)
    {
        float dry = 1.0f - wet;
        int mixChannels = juce::jmin (mainBusChannels, dryBuffer.getNumChannels());
        int mixSamples  = juce::jmin (buffer.getNumSamples(),  dryBuffer.getNumSamples());
        for (int ch = 0; ch < mixChannels; ++ch)
        {
            auto* wetData = buffer.getWritePointer (ch);
            auto* dryData = dryBuffer.getReadPointer (ch);
            for (int s = 0; s < mixSamples; ++s)
                wetData[s] = dryData[s] * dry + wetData[s] * wet;
        }
    }
}
